/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ViewBeans;

import HibernateUtils.HibernateUtil;
import daos.DaoLoClientes;
import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.primefaces.context.RequestContext;
import pojos.LoClientes;
import pojos.LoClientesId;
import utilityclass.HtmlObjContext;

/**
 *
 * @author Carlos
 */
@ManagedBean
@Named(value = "mbVCliente")
@ViewScoped
public class MbVCliente implements Serializable {

    private Session session;
    private Transaction transaction;
    
    private LoClientes cliente;
    private LoClientesId clientepk;
    private List<LoClientes> listadoClientes;
    private List<LoClientes> listaClientesFiltrados;
    String nombreCompleto;
    private HttpSession sessionActiva;
    private String validarEmpresaActiva;
    private int empresaActiva;
    private String filtroLista;
    /**
     * Creates a new instance of mbClientes
     */
    
    public MbVCliente(){
        this.cliente=new LoClientes();
        this.clientepk=new LoClientesId();
        this.cliente.setId(clientepk);
        this.cliente.getId().setClIdcliente("");
        this.cliente.getId().setClIdempresa(1);
        this.cliente.setClEstado(true);
        this.nombreCompleto="";
        this.filtroLista="T";
        this.sessionActiva=(HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
      this.validarEmpresaActiva=String.valueOf(sessionActiva.getAttribute("empresa"));
        if(!this.validarEmpresaActiva.equals("null")){
            this.empresaActiva=Integer.parseInt(sessionActiva.getAttribute("empresa").toString());
            this.cliente.getId().setClIdempresa(this.empresaActiva);
      }
        
    }
    
    public void registerCliente()
    {
        try
        {
           this.session=null;
           this.transaction=null;
           this.session=HibernateUtil.getSessionFactory().openSession();
           this.transaction=session.beginTransaction();
           
           DaoLoClientes daoLoClientes=new DaoLoClientes();
           if(daoLoClientes.getByIDs(this.session,this.cliente.getId().getClIdempresa(),this.cliente.getClNumDocumento(),this.cliente.getClNit())!=null){
               FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_ERROR,"Error :","Ya Existe Cliente Registrado con esos Documentos"));
               return;
           }
           this.nombreCompleto=this.cliente.getClPNombre()+" "+this.cliente.getClSNombre()+" "+this.cliente.getClPApellido()+" "+this.cliente.getClSApellido();
           this.cliente.setClNombrecompleto(nombreCompleto);
           
           daoLoClientes.register(this.session, this.cliente);
           this.transaction.commit();
           FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO,"Correcto :","Cliente Registrado Correctamente"));
           
           this.cliente=new LoClientes();
           this.clientepk=new LoClientesId();
 
        }
        catch(Exception ex)
        {
           FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL,"Error Fatal:","Por Favor Contactar al Administrador"+ex.getMessage()));
           if(this.transaction!=null){
               this.transaction.rollback();
           }
        }
        finally
        {
            if(this.session!=null){
                this.session.close();
            }
        }
    }
    public void updateCliente(){
        this.session=null;
        this.transaction=null;
        try{
            this.session=HibernateUtil.getSessionFactory().openSession();
            this.transaction=session.beginTransaction();
            DaoLoClientes daoLoCliente=new DaoLoClientes();
            
            if(daoLoCliente.getByIDsDiff(this.session,this.cliente.getId().getClIdempresa(),this.cliente.getId().getClIdcliente(),this.cliente.getClNumDocumento(),this.cliente.getClNit())!=null){
                FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_ERROR,"Error :","No Documento o Nit ya Asociados a otro Cliente"));
                return;
            }
            
            daoLoCliente.update(session, this.cliente);
            this.transaction.commit();
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO,"Correcto :","Cliente Actualizado Correctamente"));
            
        }catch(Exception ex){
            if(this.transaction!=null){
                this.transaction.rollback();
                FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL,"Error :","Error en Actualización, Favor Contactar al Admin"+ex.getMessage()));
            }
        }finally{
            if(this.session!=null){
                this.session.close();
            }
            
        }
    }
    
    public void removeCliente(){
        this.session=null;
        this.transaction=null;
        try{
            this.session=HibernateUtil.getSessionFactory().openSession();
            this.transaction=session.beginTransaction();
            DaoLoClientes daoLoCliente=new DaoLoClientes();
            
            daoLoCliente.delete(session, this.cliente);
            this.transaction.commit();
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO,"Correcto :","Cliente Eliminado Correctamente"));
            
        }catch(Exception ex){
            if(this.transaction!=null){
                this.transaction.rollback();
                FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL,"Error :","Error en Actualización, Favor Contactar al Admin"+ex.getMessage()));
            }
        }finally{
            if(this.session!=null){
                this.session.close();
            }
            
        }
    }
            
    
    public List<LoClientes> getAll()
    {
     this.session=null;
     this.transaction=null;
     try{
         this.session=HibernateUtil.getSessionFactory().openSession();
         this.transaction=session.beginTransaction();
         
         DaoLoClientes daoLoClientes=new DaoLoClientes();
         this.listadoClientes=daoLoClientes.getAll(this.session,this.empresaActiva,this.filtroLista);
         this.transaction.commit();
         
         return listadoClientes;
         
     }
     catch(Exception ex){
         FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL,"Error Fatal:","Por Favor Contactar al Administrador"+ex.getMessage()));
         if(this.transaction!=null){
             this.transaction.rollback();
         }
         return null;
         
     }
     finally
     {
        if(this.session!=null){
            this.session.close();
        } 
     }
     
    }
    
    public void cargarCliente(String idCliente, int contexto){
     this.session=null;
     this.transaction=null;
     try{
         this.session=HibernateUtil.getSessionFactory().openSession();
         this.transaction=session.beginTransaction();
       if(!idCliente.equals("")){  
         DaoLoClientes daoLoClientes=new DaoLoClientes();
         this.cliente=daoLoClientes.getByidCliente(this.session,this.empresaActiva,idCliente);
         this.transaction.commit();
       }else{
           this.cliente=new LoClientes();
        this.clientepk=new LoClientesId();
        this.cliente.setId(clientepk);
        this.cliente.getId().setClIdcliente("");
        this.cliente.getId().setClIdempresa(this.empresaActiva);
        this.cliente.setClEstado(true);
        this.nombreCompleto="";
       } 
         switch(contexto){
             case 1:
                 RequestContext.getCurrentInstance().update("frmListaCliente:panelDetalleCliente");
                 RequestContext.getCurrentInstance().execute("PF('dialogoDetalleCliente').show()");
                 break;
             case 2:
                 RequestContext.getCurrentInstance().update("frmDatosCliente:panelEditarCliente");
                 RequestContext.getCurrentInstance().execute("PF('dialogoEditarCliente').show()");
                 break;
             case 3:
                 RequestContext.getCurrentInstance().update("frmAgregarCliente:panelAgregarCliente");
                 RequestContext.getCurrentInstance().execute("PF('dialogoAgregarCliente').show()");
                 break;
             
         }
         
         
        }catch(Exception ex){
            if(this.transaction!=null){
             this.transaction.rollback();
             FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL,"Error Fatal:","Por Favor Contactar al Administrador"));
         }
        }finally{
           if(this.session!=null){
            this.session.close();
           } 
        }
    }
    
    public LoClientes getCliente() {
        return cliente;
    }

    public void setCliente(LoClientes cliente) {
        this.cliente = cliente;
    }

    public List<LoClientes> getListadoClientes() {
        return listadoClientes;
    }

    public void setListadoClientes(List<LoClientes> listadoClientes) {
        this.listadoClientes = listadoClientes;
    }

    public List<LoClientes> getListaClientesFiltrados() {
        return listaClientesFiltrados;
    }

    public void setListaClientesFiltrados(List<LoClientes> listaClientesFiltrados) {
        this.listaClientesFiltrados = listaClientesFiltrados;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getFiltroLista() {
        return filtroLista;
    }

    public void setFiltroLista(String filtroLista) {
        this.filtroLista = filtroLista;
    }

    public LoClientesId getClientepk() {
        return clientepk;
    }

    public void setClientepk(LoClientesId clientepk) {
        this.clientepk = clientepk;
    }

    public HttpSession getSessionActiva() {
        return sessionActiva;
    }

    public void setSessionActiva(HttpSession sessionActiva) {
        this.sessionActiva = sessionActiva;
    }

    public String getValidarEmpresaActiva() {
        return validarEmpresaActiva;
    }

    public void setValidarEmpresaActiva(String validarEmpresaActiva) {
        this.validarEmpresaActiva = validarEmpresaActiva;
    }

    public int getEmpresaActiva() {
        return empresaActiva;
    }

    public void setEmpresaActiva(int empresaActiva) {
        this.empresaActiva = empresaActiva;
    }
    
    
}
