/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ViewBeans;

import HibernateUtils.HibernateUtil;
import daos.DaoLoEmpresa;
import daos.DaoLoFuncionario;
import daos.DaoLoUsuarios;
import java.io.Serializable;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import org.hibernate.Session;
import org.hibernate.Transaction;
import pojos.LoEmpresa;
import pojos.LoEmpresaId;
import pojos.LoFuncionarios;
import pojos.LoFuncionariosId;
import pojos.LoUsuarios;
import utilityclass.Encriptar;
import utilityclass.HtmlObjContext;



/**
 *
 * @author Carlos
 */
@ManagedBean
@ViewScoped
public class MbVRegistro implements Serializable {

    private LoEmpresa empresa;
    private LoEmpresaId pkEmpresa;

    private LoFuncionarios funcionario;
    private LoFuncionariosId pkFuncionario;

    private LoUsuarios usuario;

    private Session session;
    private Transaction transaction;

    private HtmlObjContext htmlObjContext;

    private String txtrPassword;
    private int codigoEmpresa;
    private String codigoFuncionario;
    private String txtDireccion;

    /**
     * Creates a new instance of MbVRegistro
     */
    public MbVRegistro() {
        this.empresa = new LoEmpresa();
        this.pkEmpresa = new LoEmpresaId();
        this.pkEmpresa.setEmNombre("");
        this.empresa.setId(this.pkEmpresa);
        this.empresa.setEmEstado(true);
        this.empresa.setEmCodigoverificacion("");

        this.funcionario = new LoFuncionarios();
        this.pkFuncionario = new LoFuncionariosId();
        this.funcionario.setId(this.pkFuncionario);
        this.funcionario.getId().setFuIdfuncionario("");
        this.funcionario.setFuEstado(true);

        this.usuario = new LoUsuarios();
        this.usuario.setUsCodigousuario("");
        this.usuario.setUsEstado(true);

        this.htmlObjContext = new HtmlObjContext();
    }


    public String registroInicial() {
        this.session = null;
        this.transaction = null;
        try {
            if (!this.usuario.getUsPassword().equals(this.txtrPassword)) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Password no Coincide"));
                return null;
            }

            this.session = HibernateUtil.getSessionFactory().openSession();
            this.transaction = session.beginTransaction();
            DaoLoEmpresa daoLoEmpresa = new DaoLoEmpresa();
            DaoLoFuncionario daoLoFuncionario = new DaoLoFuncionario();
            DaoLoUsuarios daoLoUsuarios = new DaoLoUsuarios();

            if (daoLoEmpresa.getByNombre(this.session, this.empresa.getId().getEmNombre()) != null) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Existe una Empresa Registrada \n con el Nombre Ingresado"));
                return null;
            }

            if (daoLoEmpresa.register(this.session, this.empresa)) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto :", "Creación Empresa"));

                this.empresa = daoLoEmpresa.getByNombre(this.session, this.empresa.getId().getEmNombre());
                this.codigoEmpresa = this.empresa.getId().getEmIdempresa();
                this.funcionario.getId().setFuEmpresa(this.codigoEmpresa);

                if (daoLoFuncionario.register(this.session, this.funcionario)) {
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto :", "Creación Usuario"));
                    this.funcionario = daoLoFuncionario.getByEmail(this.session, this.funcionario.getFuEmail(), this.codigoEmpresa);
                    this.codigoFuncionario = this.funcionario.getId().getFuIdfuncionario();

                    this.usuario.setUsCodigousuario(this.codigoFuncionario);
                    this.usuario.setUsRol(1);
                    this.usuario.setUsPassword(Encriptar.sha512(this.usuario.getUsPassword()));

                    daoLoUsuarios.register(this.session, this.usuario);
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto :", "Creación Login"));
                    this.transaction.commit();
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto :", "Registro Inicial Completo"));

                    this.empresa = new LoEmpresa();
                    this.pkEmpresa = new LoEmpresaId();
                    this.pkEmpresa.setEmNombre("");
                    this.empresa.setId(this.pkEmpresa);
                    this.empresa.setEmEstado(true);
                    this.empresa.setEmCodigoverificacion("");

                    this.funcionario = new LoFuncionarios();
                    this.pkFuncionario = new LoFuncionariosId();
                    this.funcionario.setId(this.pkFuncionario);
                    this.funcionario.getId().setFuIdfuncionario("");
                    this.funcionario.setFuEstado(true);

                    this.usuario = new LoUsuarios();
                    this.usuario.setUsCodigousuario("");
                    this.usuario.setUsEstado(true);

                    return "faces/index";

                } else {
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Error en Registro de Funcionario"));
                    return null;
                }
            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Error en Creación de Empresa"));
                return null;
            }

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Error en el Registro Inicial de Empresa \n Intente Nuevamente o Contacte al Administrador"));
            if (this.transaction != null) {
                this.transaction.rollback();
            }
            return null;
        } finally {
            if (this.session != null) {
                this.session.close();
            }

        }
    }

    public String cargarRegistroEmpresa() {
        this.session = null;
        this.transaction = null;
        try {
            this.empresa = new LoEmpresa();
            this.pkEmpresa = new LoEmpresaId();
            this.pkEmpresa.setEmNombre("");
            this.empresa.setId(this.pkEmpresa);
            this.empresa.setEmEstado(true);
            this.empresa.setEmCodigoverificacion("");

            this.funcionario = new LoFuncionarios();
            this.pkFuncionario = new LoFuncionariosId();
            this.funcionario.setId(this.pkFuncionario);
            this.funcionario.getId().setFuIdfuncionario("");
            this.funcionario.setFuEstado(true);

            this.usuario = new LoUsuarios();
            this.usuario.setUsCodigousuario("");
            this.usuario.setUsEstado(true);

            return "registroinicial";
            /*RequestContext.getCurrentInstance().update("frmLogin:panelRegistrarEmpresa");
             RequestContext.getCurrentInstance().execute("PF('dialogoRegistrarEmpresa').show()");*/

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Favor Contactar al Administrador del Sistema"));
            if (this.transaction != null) {
                this.transaction.rollback();
            }
            return null;
        } finally {
            if (this.session != null) {
                this.session.close();
            }
        }

    }

    public LoEmpresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(LoEmpresa empresa) {
        this.empresa = empresa;
    }

    public LoEmpresaId getPkEmpresa() {
        return pkEmpresa;
    }

    public void setPkEmpresa(LoEmpresaId pkEmpresa) {
        this.pkEmpresa = pkEmpresa;
    }

    public LoFuncionarios getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(LoFuncionarios funcionario) {
        this.funcionario = funcionario;
    }

    public LoFuncionariosId getPkFuncionario() {
        return pkFuncionario;
    }

    public void setPkFuncionario(LoFuncionariosId pkFuncionario) {
        this.pkFuncionario = pkFuncionario;
    }

    public LoUsuarios getUsuario() {
        return usuario;
    }

    public void setUsuario(LoUsuarios usuario) {
        this.usuario = usuario;
    }

    public HtmlObjContext getHtmlObjContext() {
        return htmlObjContext;
    }

    public void setHtmlObjContext(HtmlObjContext htmlObjContext) {
        this.htmlObjContext = htmlObjContext;
    }

    public String getTxtrPassword() {
        return txtrPassword;
    }

    public void setTxtrPassword(String txtrPassword) {
        this.txtrPassword = txtrPassword;
    }

    public int getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(int codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public String getCodigoFuncionario() {
        return codigoFuncionario;
    }

    public void setCodigoFuncionario(String codigoFuncionario) {
        this.codigoFuncionario = codigoFuncionario;
    }

    public String getTxtDireccion() {
        return txtDireccion;
    }

    public void setTxtDireccion(String txtDireccion) {
        this.txtDireccion = txtDireccion;
    }

}
