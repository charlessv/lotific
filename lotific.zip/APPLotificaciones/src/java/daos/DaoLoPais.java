/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import interfaces.InterfacePaises;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import pojos.LoPais;

/**
 *
 * @author Carlos
 */
public class DaoLoPais implements InterfacePaises {

    @Override
    public boolean register(Session session, LoPais loPais) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<LoPais> getAll(Session session) throws Exception{
      String hql="from LoPais where paEstado=true";
      Query query=session.createQuery(hql);
      List<LoPais> lstPais=(List<LoPais>) query.list();
      
      return lstPais;
    
    }
    
}
