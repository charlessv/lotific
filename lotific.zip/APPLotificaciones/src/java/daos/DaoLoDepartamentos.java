/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import interfaces.InterfaceDepartamentos;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import pojos.LoDepartamento;

/**
 *
 * @author Carlos
 */
public class DaoLoDepartamentos implements InterfaceDepartamentos {

    @Override
    public boolean register(Session session, LoDepartamento loDepartamento) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<LoDepartamento> getAllDepartamentos(Session session, int idPais) throws Exception {
       String hql="from LoDepartamento where id.deIdpais=:idPais and deEstado=true";
      Query query=session.createQuery(hql);
      query.setParameter("idPais",idPais);
      
      List<LoDepartamento> lstDepartamentos=(List<LoDepartamento>) query.list();
      
      return lstDepartamentos;
    }
    
}
