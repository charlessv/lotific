/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import interfaces.InterfaceUsuario;
import org.hibernate.Query;
import org.hibernate.Session;
import pojos.LoUsuarios;

/**
 *
 * @author Carlos
 */
public class DaoLoUsuarios implements InterfaceUsuario {

    @Override
    public boolean register(Session session, LoUsuarios usuario) throws Exception {
        session.save(usuario);
        return true;
    }

    @Override
    public LoUsuarios getByLoginID(Session session, String codigoLogin,int codigoEmpresa) throws Exception {
      String hql="select u from LoUsuarios as u, LoFuncionarios as f " +
            "where u.usCodigousuario=f.id.fuIdfuncionario and f.id.fuEmpresa=? " +
            "and u.usLogin=?";  
        
      Query query=session.createQuery(hql);
      
      query.setParameter(0, codigoEmpresa);
      query.setParameter(1,codigoLogin);
      
      LoUsuarios loUsuario=(LoUsuarios) query.uniqueResult();
      
      return loUsuario;
      
    }

    @Override
    public LoUsuarios getByLoginVerifCode(Session session,String codigoUsuario,String verifCode) throws Exception {
        String hql="select u from LoUsuarios u, LoFuncionarios f, LoEmpresa e " +
                   "where f.id.fuIdfuncionario=u.usCodigousuario " +
                   "and e.id.emIdempresa=f.id.fuEmpresa " +
                   "and e.emCodigoverificacion=? and u.usLogin=?";   
        
        Query query=session.createQuery(hql);
        query.setParameter(0,verifCode);
        query.setParameter(1,codigoUsuario);
        
        LoUsuarios loUsuarios=(LoUsuarios) query.uniqueResult();
        
        return loUsuarios;
    }
    
}
