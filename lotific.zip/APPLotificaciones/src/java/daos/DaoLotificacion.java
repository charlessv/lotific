/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import interfaces.InterfaceLotificacion;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import pojos.LoLotificacion;

/**
 *
 * @author Carlos
 */
public class DaoLotificacion implements InterfaceLotificacion {

    @Override
    public boolean register(Session session, LoLotificacion lotificacion) throws Exception {
        session.save(lotificacion);
        return true;
    }

    @Override
    public List<LoLotificacion> getAll(Session session,int codigoEmpresa,String estado) throws Exception {
        String hql="from LoLotificacion where ";
        String condicion="";
        boolean estadoLotificacion=true;
        
        switch (estado){
            case "T":
                condicion="id.loEmpresa=?";
                break;
            default:
                condicion="id.loEmpresa=? and loEstado=?";
            
            if (estado.equals("I")){
                estadoLotificacion=false;
            }    
        }
        
        
        hql=hql+condicion;
        Query query=session.createQuery(hql);
        
        query.setParameter(0, codigoEmpresa);
        
        if (!estado.equals("T")){
            query.setParameter(1, estadoLotificacion);
        }
        
        List<LoLotificacion> listaLotificacion=(List<LoLotificacion>) query.list();
        
        return listaLotificacion;
        
    }

    @Override
    public LoLotificacion getByName(Session session, String nombre,int codigoEmpresa) throws Exception {
        String hql="from LoLotificacion where id.loEmpresa=? and id.loNombre=?";
        Query query=session.createQuery(hql);
        
        query.setParameter(0, codigoEmpresa);
        query.setParameter(1, nombre);
        
        LoLotificacion lotificacion=(LoLotificacion) query.uniqueResult();
        
        return lotificacion;
    }
}
