/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import java.util.List;
import org.hibernate.Session;
import pojos.LoDepartamento;
import pojos.LoMunicipios;

/**
 *
 * @author Carlos
 */
public interface InterfaceMunicipios {
    public boolean register(Session session,LoMunicipios loMunicipio) throws Exception;
    public List<LoMunicipios> getAllMunicipios(Session session,int idDepartamento)throws Exception;
    
}
