/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import org.hibernate.Session;
import pojos.LoEmpresa;

/**
 *
 * @author Carlos
 */
public interface InterfaceEmpresa {
    public boolean register(Session session, LoEmpresa loEmpresa) throws Exception;
    public LoEmpresa getByNombre(Session session, String nombreEmpresa)throws Exception;
    public LoEmpresa getByCodigo(Session session,int codigoEmpresa)throws Exception;
    
}
