/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import java.util.List;
import org.hibernate.Session;
import pojos.LoLotes;

/**
 *
 * @author Carlos
 */
public interface InterfaceLotes {
    public boolean register(Session session,LoLotes lote)throws Exception;
    public List<LoLotes> getAll(Session session,String codigoLotificacion)throws Exception;
    public LoLotes getByLote(Session session,String codigoLotificacion,int codigoLote);
    
}
