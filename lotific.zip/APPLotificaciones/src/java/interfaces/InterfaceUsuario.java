/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import org.hibernate.Session;
import pojos.LoUsuarios;

/**
 *
 * @author Carlos
 */
public interface InterfaceUsuario {
    public boolean register(Session session,LoUsuarios usuario) throws Exception;
    public LoUsuarios getByLoginID(Session session,String codigoLogin,int codigoEmpresa)throws Exception;
    public LoUsuarios getByLoginVerifCode(Session session,String codigoUsuario,String verifCode)throws Exception;
    
}
