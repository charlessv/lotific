/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Productos;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Carlos
 */
@Stateless
public class ProductosFacade extends AbstractFacade<Productos> {

    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProductosFacade() {
        super(Productos.class);
    }

    public int calcularId(int idCategoria) {
        Query query = em.createQuery("SELECT coalesce(MAX(p.productosPK.idProducto)+1,1)"
                + "FROM Productos p where p.productosPK.idCategoria=?1");

        query.setParameter(1, idCategoria);

        return Integer.parseInt(query.getSingleResult().toString());
    }

    public List<Productos> cargarPorCategoria(int idCategoria) {
        Query query = em.createQuery("SELECT p "
                + "FROM Productos p where p.productosPK.idCategoria=?1");

        query.setParameter(1, idCategoria);

        return (List<Productos>) query.getResultList();

    }

    public String obtenerNombre(int idCategoria, int idProducto) {
      try{
        Query query = em.createQuery("SELECT p.nombre "
                + "FROM Productos p where p.productosPK.idCategoria=?1 "
                + "and p.productosPK.idProducto=?2");

        query.setParameter(1, idCategoria);
        query.setParameter(2, idProducto);

        return query.getSingleResult().toString();
      }catch(Exception ex){
          return null;
      }  
    }

    public Productos obtenerProducto(int idCategoria, int idProducto) {
        Query query = em.createQuery("SELECT p "
                + "FROM Productos p where p.productosPK.idCategoria=?1 "
                + "and p.productosPK.idProducto=?2");

        query.setParameter(1, idCategoria);
        query.setParameter(2, idProducto);

        return (Productos) query.getSingleResult();
    }

}
