/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Menurol;
import entidades.Roles;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Carlos
 */
@Stateless
public class MenurolFacade extends AbstractFacade<Menurol> {
    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MenurolFacade() {
        super(Menurol.class);
    }
    
    public List<Menurol> menuAsociadoByRol(int idRol){
        try{
            Query query=em.createQuery("Select mr from Menurol mr where mr.idRol=?1");
            query.setParameter(1, idRol);
            
            return (List<Menurol>) query.getResultList();
        }catch(Exception ex){
            return null;
        }
    }
}
