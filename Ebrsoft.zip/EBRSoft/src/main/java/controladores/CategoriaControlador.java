/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controladores;

import entidades.Categorias;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import modelo.CategoriasFacade;
import org.primefaces.context.RequestContext;

/**
 *
 * @author cc90930
 */
@ManagedBean
@SessionScoped
public class CategoriaControlador implements Serializable {
    @EJB
    CategoriasFacade categoriasFacade;
    
    Categorias categoria;
    
    List<Categorias> listaCategorias;
    List<Categorias> listaCategoriasFiltrada;
    
    
    

    /**
     * Creates a new instance of CategoriaControlador
     * 
     * 
     */
    @PostConstruct
        public void init() {
        categoria = new Categorias();
        categoria.setIdCategoria(0);
        
        listaCategorias = new ArrayList<>();
        listaCategorias = cargarCategorias();
    }

    
    
    public CategoriaControlador() {
    }
    
    public void crearCategoria(){
        try{
            categoriasFacade.edit(categoria);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,"Correcto","Categoria Ingresada Correctamente"));
        }catch(Exception ex){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,"Error","Categoria No Creada"));
        }
    }
    
        public void eliminarCategoria(Categorias idcategoria) {
        try {
            categoriasFacade.remove(idcategoria);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Categoria Eliminada"));
            categoria = new Categorias();
            RequestContext.getCurrentInstance().update("frmCategoriasdetalle:tblDetalle");
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "Categoria No Eliminada"));
        }
    }

    public void actualizarCategoria() {
        try {
            categoriasFacade.edit(categoria);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Categoria Actualizada"));
            categoria = new Categorias();
            RequestContext.getCurrentInstance().update("frmCategoriasdetalle:tblDetalle");
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "Categoria No Actualizada"));
        }
    }


    public List<Categorias> cargarCategorias() {
        listaCategorias = categoriasFacade.findAll();
        return listaCategorias;
    }
    
    public List<SelectItem> listarCategorias(){
        List<SelectItem> listadoCategorias=new ArrayList<>();
        
        this.listaCategorias=categoriasFacade.findAll();
        
        for(Categorias cat:this.listaCategorias){
            listadoCategorias.add(new SelectItem(cat.getIdCategoria(),cat.getNombre()));
        }
        
        return listadoCategorias;
    }

    
    
    public Categorias getCategoria() {
        return categoria;
    }

    public void setCategoria(Categorias categoria) {
        this.categoria = categoria;
    }

    public List<Categorias> getListaCategorias() {
        return listaCategorias;
    }

    public void setListaCategorias(List<Categorias> listaCategorias) {
        this.listaCategorias = listaCategorias;
    }

    public List<Categorias> getListaCategoriasFiltrada() {
        return listaCategoriasFiltrada;
    }

    public void setListaCategoriasFiltrada(List<Categorias> listaCategoriasFiltrada) {
        this.listaCategoriasFiltrada = listaCategoriasFiltrada;
    }

    
    
    
}
