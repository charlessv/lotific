/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Clientes;
import entidades.Eventos;
import javax.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import modelo.EventosFacade;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Carlos
 */

@ManagedBean
@SessionScoped

public class EventosControlador implements Serializable {

    private Clientes cliente;
    private Eventos evento;
   
    private List<Eventos> listadoEventos;
    private List<Eventos> listadoEventosFiltrada;
    private Date FechaHoy;

    @EJB
    EventosFacade eventoFacade;

    @PostConstruct
    public void init() {
        FechaHoy = new Date();
        limpiarControles();
    }

    public List<Eventos> cargarEventos() {
        listadoEventos = eventoFacade.findAll();
        return listadoEventos;
    }

    

    public EventosControlador() {
    }

    public void crearEvento(int valor) {
        if (this.ValidacionesEvento(evento) == true) {
            try {

                eventoFacade.edit(evento);
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Evento Creado"));
                this.cargarEventos();
                if(valor==0)
                {
                limpiarControles();
                }
                RequestContext.getCurrentInstance().update("frmAddEventos");
                RequestContext.getCurrentInstance().update("frmEventos:tblEventos");
                RequestContext.getCurrentInstance().execute("PF('dlgAddEvento').hide()");
                
            } catch (Exception ex) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Evento no Creado"));
            }
        }
    }

    public void eliminarEvento(Eventos idevento) {
        try {
            eventoFacade.remove(idevento);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Evento Eliminado"));
            this.cargarEventos();
            RequestContext.getCurrentInstance().update("frmEventos:tblEventos");
            RequestContext.getCurrentInstance().execute("PF('dlgAddEvento').hide()");
            this.evento = new Eventos();
            
                    
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Evento no Eliminado"));
        }
    }

    public void editarEvento() {
        try {
            eventoFacade.edit(evento);
            evento.setIdCliente(cliente);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Evento Actualizado"));
            this.cargarEventos();
            this.evento = new Eventos();
            this.cliente = new Clientes();
            RequestContext.getCurrentInstance().update("frmEventos:tblEventos");
            RequestContext.getCurrentInstance().execute("PF('dlgAddEvento').hide()");
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Evento no Actualizado"));
        }
    }

    public List<SelectItem> listarEventos() {
        List<SelectItem> listaEventos = new ArrayList<>();

        this.listadoEventos = eventoFacade.findAll();

        for (Eventos eve : this.listadoEventos) {
            listaEventos.add(new SelectItem(eve.getIdEvento(), eve.getNombre()));
        }

        return listaEventos;
    }

    public boolean ValidacionesEvento(Eventos idevento) {
        boolean bandera = true;
        //VALIDAR CLIENTE SELECCIONADO
        if (idevento.getIdCliente().getIdCliente() == 0) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Validacion", "Debe asignar un cliente al evento"));
            bandera = false;
        }

        //VALIDAR FECHA EVENTO VS FECHA MONTAJE
        if (idevento.getFechafin().before(evento.getFechainicio())) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Validacion", "Fecha final es inferior la fecha de inicio"));
            bandera = false;
        }

        if (idevento.getFechamontajefin().before(evento.getFechamontajeinicio())) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Validacion", "Fecha montaje final es inferior la fecha montaje inicio"));
            bandera = false;
        }

        if (idevento.getHorafin().before(evento.getHorainicio())) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Validacion", "Hora final es inferior la Hora de inicio"));
            bandera = false;
        }

        if (idevento.getHoramontajefin().before(evento.getHoramontajeinicio())) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Validacion", "Hora montaje  final es inferior la fecha de inicio"));
            bandera = false;
        }

        if (idevento.getFechamontajeinicio().after(evento.getFechainicio())) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Validacion", "Fecha montaje final es inferior la fecha inicio"));
            bandera = false;
        }

        if (idevento.getFechamontajefin().after(evento.getFechainicio())) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Validacion", "Fecha montaje final es inferior la fecha inicio"));
            bandera = false;
        }
        return bandera;
    }
    public String  buscarEventoporId(int idevento)
    {
         return eventoFacade.buscarEventoporId(idevento);
    }
    public List<Eventos>buscarEventosxEstado(int estado){
       return (List<Eventos>) eventoFacade.buscarEventosEstado(estado);
    }
    
    
    
    public void limpiarControles(){
        cliente = new Clientes();
        evento = new Eventos();
        
        cliente.setIdCliente(0);
        cliente.setNombres("");
        cliente.setApellidos("");
        cliente.setRazonsocial("");
        

        evento.setIdEvento(0);
        evento.setFechainicio(FechaHoy);
        evento.setFechafin(FechaHoy);
        evento.setFechamontajeinicio(FechaHoy);
        evento.setFechamontajefin(FechaHoy);
        evento.setHorainicio(FechaHoy);
        evento.setHorafin(FechaHoy);
        evento.setHoramontajeinicio(FechaHoy);
        evento.setHoramontajefin(FechaHoy);
        evento.setEstado(0);
        evento.setEncargado("");
        evento.setTransporte("");
        evento.setNombre("");
        evento.setIdCliente(cliente);
        evento.setCosto(0.00);
        
        listadoEventos = new ArrayList<>();
        listadoEventos = cargarEventos();
    }

    public Clientes getCliente() {
        return cliente;
    }

    public void setCliente(Clientes cliente) {
        this.cliente = cliente;
    }

    public Eventos getEvento() {
        return evento;
    }

    public void setEvento(Eventos evento) {
        this.evento = evento;
        
    }

    

    public List<Eventos> getListadoEventos() {
        return listadoEventos;
    }

    public void setListadoEventos(List<Eventos> listadoEventos) {
        this.listadoEventos = listadoEventos;
    }

    public List<Eventos> getListadoEventosFiltrada() {
        return listadoEventosFiltrada;
    }

    public void setListadoEventosFiltrada(List<Eventos> listadoEventosFiltrada) {
        this.listadoEventosFiltrada = listadoEventosFiltrada;
    }

    public Date getFechaHoy() {
        return FechaHoy;
    }

    public void setFechaHoy(Date FechaHoy) {
        this.FechaHoy = FechaHoy;
    }
    
    
    

}
