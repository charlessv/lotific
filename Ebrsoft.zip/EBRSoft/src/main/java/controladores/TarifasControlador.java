/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Productos;
import entidades.Tarifario;
import entidades.TarifarioPK;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import modelo.CategoriasFacade;
import modelo.ProductosFacade;
import modelo.TarifarioFacade;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Carlos
 */
@ManagedBean
@SessionScoped
public class TarifasControlador implements Serializable {

    @EJB
    CategoriasFacade categoriasFacade;
    @EJB
    ProductosFacade productosFacade;
    @EJB
    TarifarioFacade tarifarioFacade;

    private Tarifario tarifas;
    private TarifarioPK tarifasPK;
    private Productos producto;

    private List<Tarifario> listaTarifas;
    private List<Tarifario> listaTarifasFiltrada;
    private List<Tarifario> listaNuevasTarifas;

    private int idProducto;
    private int idCategoria;

    private int tabActiva;

    /**
     * Creates a new instance of TarifasControlador
     */
    @ManagedProperty("#{productosControlador}")
    private ProductosControlador productosControlador;

    @PostConstruct
    public void init() {
        idProducto = 0;
        idCategoria = 0;

        tarifas = new Tarifario();
        tarifasPK = new TarifarioPK();

        listaTarifas = new ArrayList<>();
        listaNuevasTarifas = new ArrayList<>();
        listaTarifas = cargarTarifas();

        tarifas.setTarifarioPK(tarifasPK);

        tabActiva = 1;

    }

    public TarifasControlador() {

    }

    public void crearTarifa() {
        boolean flagError = false;
        try {
            if (!this.listaNuevasTarifas.isEmpty()) {
                for (Tarifario dtTarifas : this.listaNuevasTarifas) {
                    this.tarifasPK.setIdTarifa(tarifarioFacade.calcularId());
                    this.tarifasPK.setIdCategoria(dtTarifas.getCategorias().getIdCategoria());
                    this.tarifasPK.setIdProducto(dtTarifas.getProductos().getProductosPK().getIdProducto());
                    dtTarifas.setTarifarioPK(tarifasPK);
                    tarifarioFacade.create(dtTarifas);

                }
                this.cargarTarifas();

                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                        "Correcto :", "Tarifas Agregada Correctamente"));

                this.listaNuevasTarifas.clear();
                RequestContext.getCurrentInstance().update("frmTarifas:acctarifas:pnlAddTarifa");
                RequestContext.getCurrentInstance().update("frmTarifas:acctarifas:tblTarifas");

                //RequestContext.getCurrentInstance().execute("PF('dlgAddProducto').hide()");
                this.tarifas = new Tarifario();
                this.tarifasPK = new TarifarioPK();
                this.tarifasPK.setIdTarifa(tarifarioFacade.calcularId());
                this.tarifas.setTarifarioPK(tarifasPK);

            }

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Crear Tarifa" + ex.getMessage()));
        }

    }

    public void eliminarTarifa(Tarifario idTarifa) {
        try {
            tarifarioFacade.remove(idTarifa);

            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                    "Correcto :", "Tarifa Eliminado"));

            this.cargarTarifas();
            this.productosControlador.cargarPorCategoria();
            this.validaProdTarifas();
            RequestContext.getCurrentInstance().update("frmTarifas:acctarifas");
            
            this.tarifas = new Tarifario();
            this.tarifasPK = new TarifarioPK();
            this.tarifas.setTarifarioPK(tarifasPK);

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Eliminar Tarifa" + ex.getMessage()));
        }

    }

    public void editarTarifa() {
        try {
            if (this.tarifas.getPreciomax() < this.tarifas.getPreciomin()) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
                                        "Error :", "Rango de Precios Incorrecto"));
                return;
            }

            tarifarioFacade.edit(tarifas);

            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                    "Correcto :", "Tarifa Actualizada"));

            this.cargarTarifas();
            RequestContext.getCurrentInstance().update("frmTarifas:acctarifas:tblTarifas");
            RequestContext.getCurrentInstance().execute("PF('dlgEditTarifa').hide()");
            this.tarifas = new Tarifario();

            this.tarifasPK = new TarifarioPK();
            this.tarifas.setTarifarioPK(tarifasPK);

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Actualizar Tarifa" + ex.getMessage()));
        }

    }

    public void validaProdTarifas() {
        if (!this.listaTarifas.isEmpty()) {
            for (Tarifario dtTarifas : this.listaTarifas) {
                this.producto = productosFacade.obtenerProducto(dtTarifas.getTarifarioPK().getIdCategoria(),
                        dtTarifas.getTarifarioPK().getIdProducto());
                productosControlador.getListaProductos().remove(this.producto);
            }
            RequestContext.getCurrentInstance().update("frmTarifas:acctarifas:pnlAddTarifa");
        }

    }

    public List<Tarifario> cargarTarifas() {
        this.listaTarifas = tarifarioFacade.findAll();
        return this.listaTarifas;
    }

    public void agregarListaNewTarifas(Productos idProductos) {
        try {
            this.tarifasPK = new TarifarioPK();
            this.tarifasPK.setIdCategoria(idProductos.getCategorias().getIdCategoria());
            this.tarifasPK.setIdProducto(idProductos.getProductosPK().getIdProducto());
            this.tarifas.setTarifarioPK(tarifasPK);
            this.tarifas.setProductos(idProductos);
            this.tarifas.setCategorias(idProductos.getCategorias());

            this.listaNuevasTarifas.add(this.tarifas);

            productosControlador.getListaProductos().remove(idProductos);

            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                    "Correcto", "Producto Agregado"));
            this.tarifas = new Tarifario();
            this.tarifasPK = new TarifarioPK();
            this.tarifas.setTarifarioPK(tarifasPK);

            RequestContext.getCurrentInstance().update("frmTarifas:acctarifas:pnlAddTarifa");

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Producto no Adicionado" + ex.getMessage()));
        }
    }

    public void removerListaNewTarifas(Tarifario idTarifas) {
        try {
            //int i=0;
            for (Tarifario dtTarifa : this.listaNuevasTarifas) {
                if (dtTarifa == idTarifas) {
                    this.listaNuevasTarifas.remove(dtTarifa);
                    break;
                }
            }

            productosControlador.getListaProductos().add(idTarifas.getProductos());

            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
                                    "Correcto", "Item Removido"));

            RequestContext.getCurrentInstance().update("frmTarifas:acctarifas:pnlAddTarifa");

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL,
                                    "Error", ex.getMessage()));
        }
    }

    public Tarifario getTarifas() {
        return tarifas;
    }

    public void setTarifas(Tarifario tarifas) {
        this.tarifas = tarifas;
    }

    public TarifarioPK getTarifasPK() {
        return tarifasPK;
    }

    public void setTarifasPK(TarifarioPK tarifasPK) {
        this.tarifasPK = tarifasPK;
    }

    public List<Tarifario> getListaTarifas() {
        return listaTarifas;
    }

    public void setListaTarifas(List<Tarifario> listaTarifas) {
        this.listaTarifas = listaTarifas;
    }

    public List<Tarifario> getListaTarifasFiltrada() {
        return listaTarifasFiltrada;
    }

    public void setListaTarifasFiltrada(List<Tarifario> listaTarifasFiltrada) {
        this.listaTarifasFiltrada = listaTarifasFiltrada;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public List<Tarifario> getListaNuevasTarifas() {
        return listaNuevasTarifas;
    }

    public void setListaNuevasTarifas(List<Tarifario> listaNuevasTarifas) {
        this.listaNuevasTarifas = listaNuevasTarifas;
    }

    public ProductosControlador getProductosControlador() {
        return productosControlador;
    }

    public void setProductosControlador(ProductosControlador productosControlador) {
        this.productosControlador = productosControlador;
    }

    public Productos getProducto() {
        return producto;
    }

    public void setProducto(Productos producto) {
        this.producto = producto;
    }

    public int getTabActiva() {
        return tabActiva;
    }

    public void setTabActiva(int tabActiva) {
        this.tabActiva = tabActiva;
    }

}
