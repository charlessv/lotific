/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Carlos
 */
@Entity
@Table(name = "tarifario")
@NamedQueries({
    @NamedQuery(name = "Tarifario.findAll", query = "SELECT t FROM Tarifario t"),
    @NamedQuery(name = "Tarifario.findByIdTarifa", query = "SELECT t FROM Tarifario t WHERE t.tarifarioPK.idTarifa = :idTarifa"),
    @NamedQuery(name = "Tarifario.findByIdProducto", query = "SELECT t FROM Tarifario t WHERE t.tarifarioPK.idProducto = :idProducto"),
    @NamedQuery(name = "Tarifario.findByIdCategoria", query = "SELECT t FROM Tarifario t WHERE t.tarifarioPK.idCategoria = :idCategoria"),
    @NamedQuery(name = "Tarifario.findByPreciomax", query = "SELECT t FROM Tarifario t WHERE t.preciomax = :preciomax"),
    @NamedQuery(name = "Tarifario.findByPreciomin", query = "SELECT t FROM Tarifario t WHERE t.preciomin = :preciomin"),
    @NamedQuery(name = "Tarifario.findByPrecioideal", query = "SELECT t FROM Tarifario t WHERE t.precioideal = :precioideal")})
public class Tarifario implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected TarifarioPK tarifarioPK;
    @Column(name = "preciomax")
    private Integer preciomax;
    @Column(name = "preciomin")
    private Integer preciomin;
    @Column(name = "precioideal")
    private Integer precioideal;
    @JoinColumn(name = "id_categoria", referencedColumnName = "id_categoria", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Categorias categorias;
    @JoinColumns({
        @JoinColumn(name = "id_producto", referencedColumnName = "id_producto", insertable = false, updatable = false),
        @JoinColumn(name = "id_categoria", referencedColumnName = "id_categoria", insertable = false, updatable = false)})
    @ManyToOne(optional = false)
    private Productos productos;

    public Tarifario() {
    }

    public Tarifario(TarifarioPK tarifarioPK) {
        this.tarifarioPK = tarifarioPK;
    }

    public Tarifario(int idTarifa, int idProducto, int idCategoria) {
        this.tarifarioPK = new TarifarioPK(idTarifa, idProducto, idCategoria);
    }

    public TarifarioPK getTarifarioPK() {
        return tarifarioPK;
    }

    public void setTarifarioPK(TarifarioPK tarifarioPK) {
        this.tarifarioPK = tarifarioPK;
    }

    public Integer getPreciomax() {
        return preciomax;
    }

    public void setPreciomax(Integer preciomax) {
        this.preciomax = preciomax;
    }

    public Integer getPreciomin() {
        return preciomin;
    }

    public void setPreciomin(Integer preciomin) {
        this.preciomin = preciomin;
    }

    public Integer getPrecioideal() {
        return precioideal;
    }

    public void setPrecioideal(Integer precioideal) {
        this.precioideal = precioideal;
    }

    public Categorias getCategorias() {
        return categorias;
    }

    public void setCategorias(Categorias categorias) {
        this.categorias = categorias;
    }

    public Productos getProductos() {
        return productos;
    }

    public void setProductos(Productos productos) {
        this.productos = productos;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tarifarioPK != null ? tarifarioPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tarifario)) {
            return false;
        }
        Tarifario other = (Tarifario) object;
        if ((this.tarifarioPK == null && other.tarifarioPK != null) || (this.tarifarioPK != null && !this.tarifarioPK.equals(other.tarifarioPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Tarifario[ tarifarioPK=" + tarifarioPK + " ]";
    }
    
}
