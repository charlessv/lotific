/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Carlos
 */
@Entity
@Table(name = "facturacion")
@NamedQueries({
    @NamedQuery(name = "Facturacion.findAll", query = "SELECT f FROM Facturacion f"),
    @NamedQuery(name = "Facturacion.findByIdfactura", query = "SELECT f FROM Facturacion f WHERE f.facturacionPK.idfactura = :idfactura"),
    @NamedQuery(name = "Facturacion.findByIdtdocumento", query = "SELECT f FROM Facturacion f WHERE f.facturacionPK.idtdocumento = :idtdocumento"),
    @NamedQuery(name = "Facturacion.findByCredito", query = "SELECT f FROM Facturacion f WHERE f.credito = :credito"),
    @NamedQuery(name = "Facturacion.findByDiascredito", query = "SELECT f FROM Facturacion f WHERE f.diascredito = :diascredito"),
    @NamedQuery(name = "Facturacion.findByIdCliente", query = "SELECT f FROM Facturacion f WHERE f.facturacionPK.idCliente = :idCliente"),
    @NamedQuery(name = "Facturacion.findByMonto", query = "SELECT f FROM Facturacion f WHERE f.monto = :monto"),
    @NamedQuery(name = "Facturacion.findByDescripcion", query = "SELECT f FROM Facturacion f WHERE f.descripcion = :descripcion"),
    @NamedQuery(name = "Facturacion.findByFechaingreso", query = "SELECT f FROM Facturacion f WHERE f.fechaingreso = :fechaingreso"),
    @NamedQuery(name = "Facturacion.findByFechaemision", query = "SELECT f FROM Facturacion f WHERE f.fechaemision = :fechaemision"),
    @NamedQuery(name = "Facturacion.findByGeneraiva", query = "SELECT f FROM Facturacion f WHERE f.generaiva = :generaiva"),
    @NamedQuery(name = "Facturacion.findByGenretencion", query = "SELECT f FROM Facturacion f WHERE f.genretencion = :genretencion"),
    @NamedQuery(name = "Facturacion.findByIdquedan", query = "SELECT f FROM Facturacion f WHERE f.idquedan = :idquedan"),
    @NamedQuery(name = "Facturacion.findByFechaquedan", query = "SELECT f FROM Facturacion f WHERE f.fechaquedan = :fechaquedan"),
    @NamedQuery(name = "Facturacion.findByEstado", query = "SELECT f FROM Facturacion f WHERE f.estado = :estado")})
public class Facturacion implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected FacturacionPK facturacionPK;
    @Column(name = "credito")
    private Boolean credito;
    @Column(name = "diascredito")
    private Integer diascredito;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "monto")
    private Double monto;
    @Size(max = 100)
    @Column(name = "descripcion")
    private String descripcion;
    @Column(name = "fechaingreso")
    @Temporal(TemporalType.DATE)
    private Date fechaingreso;
    @Column(name = "fechaemision")
    @Temporal(TemporalType.DATE)
    private Date fechaemision;
    @Column(name = "generaiva")
    private Boolean generaiva;
    @Column(name = "genretencion")
    private Boolean genretencion;
    @Size(max = 255)
    @Column(name = "idquedan")
    private String idquedan;
    @Column(name = "fechaquedan")
    @Temporal(TemporalType.DATE)
    private Date fechaquedan;
    @Basic(optional = false)
    @NotNull
    @Column(name = "estado")
    private int estado;
    @JoinColumn(name = "idCliente", referencedColumnName = "id_cliente", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Clientes clientes;
    @JoinColumn(name = "id_evento", referencedColumnName = "id_evento")
    @ManyToOne
    private Eventos idEvento;

    public Facturacion() {
    }

    public Facturacion(FacturacionPK facturacionPK) {
        this.facturacionPK = facturacionPK;
    }

    public Facturacion(FacturacionPK facturacionPK, int estado) {
        this.facturacionPK = facturacionPK;
        this.estado = estado;
    }

    public Facturacion(String idfactura, int idtdocumento, int idCliente) {
        this.facturacionPK = new FacturacionPK(idfactura, idtdocumento, idCliente);
    }

    public FacturacionPK getFacturacionPK() {
        return facturacionPK;
    }

    public void setFacturacionPK(FacturacionPK facturacionPK) {
        this.facturacionPK = facturacionPK;
    }

    public Boolean getCredito() {
        return credito;
    }

    public void setCredito(Boolean credito) {
        this.credito = credito;
    }

    public Integer getDiascredito() {
        return diascredito;
    }

    public void setDiascredito(Integer diascredito) {
        this.diascredito = diascredito;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaingreso() {
        return fechaingreso;
    }

    public void setFechaingreso(Date fechaingreso) {
        this.fechaingreso = fechaingreso;
    }

    public Date getFechaemision() {
        return fechaemision;
    }

    public void setFechaemision(Date fechaemision) {
        this.fechaemision = fechaemision;
    }

    public Boolean getGeneraiva() {
        return generaiva;
    }

    public void setGeneraiva(Boolean generaiva) {
        this.generaiva = generaiva;
    }

    public Boolean getGenretencion() {
        return genretencion;
    }

    public void setGenretencion(Boolean genretencion) {
        this.genretencion = genretencion;
    }

    public String getIdquedan() {
        return idquedan;
    }

    public void setIdquedan(String idquedan) {
        this.idquedan = idquedan;
    }

    public Date getFechaquedan() {
        return fechaquedan;
    }

    public void setFechaquedan(Date fechaquedan) {
        this.fechaquedan = fechaquedan;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public Clientes getClientes() {
        return clientes;
    }

    public void setClientes(Clientes clientes) {
        this.clientes = clientes;
    }

    public Eventos getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(Eventos idEvento) {
        this.idEvento = idEvento;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (facturacionPK != null ? facturacionPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Facturacion)) {
            return false;
        }
        Facturacion other = (Facturacion) object;
        if ((this.facturacionPK == null && other.facturacionPK != null) || (this.facturacionPK != null && !this.facturacionPK.equals(other.facturacionPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Facturacion[ facturacionPK=" + facturacionPK + " ]";
    }
    
}
