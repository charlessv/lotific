/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Carlos
 */
@Embeddable
public class AuxdetparamPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "descripcion")
    private String descripcion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "codigo")
    private int codigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "estado")
    private boolean estado;
    @Basic(optional = false)
    @NotNull
    @Column(name = "catalogo")
    private int catalogo;

    public AuxdetparamPK() {
    }

    public AuxdetparamPK(String descripcion, int codigo, boolean estado, int catalogo) {
        this.descripcion = descripcion;
        this.codigo = codigo;
        this.estado = estado;
        this.catalogo = catalogo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getCatalogo() {
        return catalogo;
    }

    public void setCatalogo(int catalogo) {
        this.catalogo = catalogo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (descripcion != null ? descripcion.hashCode() : 0);
        hash += (int) codigo;
        hash += (estado ? 1 : 0);
        hash += (int) catalogo;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AuxdetparamPK)) {
            return false;
        }
        AuxdetparamPK other = (AuxdetparamPK) object;
        if ((this.descripcion == null && other.descripcion != null) || (this.descripcion != null && !this.descripcion.equals(other.descripcion))) {
            return false;
        }
        if (this.codigo != other.codigo) {
            return false;
        }
        if (this.estado != other.estado) {
            return false;
        }
        if (this.catalogo != other.catalogo) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.AuxdetparamPK[ descripcion=" + descripcion + ", codigo=" + codigo + ", estado=" + estado + ", catalogo=" + catalogo + " ]";
    }
    
}
