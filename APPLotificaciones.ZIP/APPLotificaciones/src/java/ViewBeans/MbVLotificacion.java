/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ViewBeans;

import HibernateUtils.HibernateUtil;
import static com.sun.faces.el.ELUtils.createValueExpression;

import daos.DaoLotificacion;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIInput;
import javax.faces.component.UIOutput;
import javax.faces.component.html.HtmlInputText;
import javax.faces.component.html.HtmlOutputLabel;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.primefaces.context.RequestContext;
import pojos.LoLotificacion;
import pojos.LoLotificacionId;
import utilityclass.HtmlObjContext;

/**
 *
 * @author Carlos
 */
@Named(value = "mbVLotificacion")
@ViewScoped
public class MbVLotificacion implements Serializable {

    private LoLotificacion lotificacion;
    private LoLotificacionId pkLotificacion;
    private List<LoLotificacion> listaLotificacion;
    private List<LoLotificacion> listaLotificacionFilter;

    private Session session;
    private Transaction transaction;

    private HttpSession sessionActiva;
    private String validarEmpresaActiva;
    private int empresaActiva;
    private String filtroLista;

    private HtmlObjContext htmlObjContext;
    private String poligonoInicial;
    private String poligonoFinal;
    
    private HtmlPanelGrid pnlLotes;

    /**
     * Creates a new instance of MbVLotificacion
     */
    @PostConstruct
    public void init(){
        this.poligonoInicial="A";
        this.poligonoFinal="Z";
        this.pnlLotes=new HtmlPanelGrid();
        this.pnlLotes=generaPanel();
    }

    
    public MbVLotificacion() {
        this.lotificacion = new LoLotificacion();
        this.pkLotificacion = new LoLotificacionId();
        this.lotificacion.setId(pkLotificacion);
        this.lotificacion.getId().setLoIdlotificacion("");
        this.lotificacion.setLoEstado(true);

        this.sessionActiva = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        this.validarEmpresaActiva = String.valueOf(sessionActiva.getAttribute("empresa"));
        if (!this.validarEmpresaActiva.equals("null")) {
            this.empresaActiva = Integer.parseInt(sessionActiva.getAttribute("empresa").toString());
            this.lotificacion.getId().setLoEmpresa(this.empresaActiva);
        }
        this.filtroLista = "T";
         

    }
    public List<LoLotificacion> getAllLotificaciones() {
        this.session = null;
        this.transaction = null;
        try {

            this.session = HibernateUtil.getSessionFactory().openSession();
            this.transaction = session.beginTransaction();

            if (!this.validarEmpresaActiva.equals("null")) {
                DaoLotificacion daoLotificacion = new DaoLotificacion();
                this.listaLotificacion = daoLotificacion.getAll(this.session, this.empresaActiva, this.filtroLista);
                transaction.commit();

                return this.listaLotificacion;
            } else {
                return null;
            }

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error Fatal :", "Por favor contactar al Administrador"));
            if (this.transaction != null) {
                this.transaction.rollback();
            }
            return null;
        } finally {
            if (this.session != null) {
                this.session.close();
            }
        }

    }

    public void register() {
        this.session = null;
        this.transaction = null;
        try {
            this.session = HibernateUtil.getSessionFactory().openSession();
            this.transaction = session.beginTransaction();
            DaoLotificacion daoLotificacion = new DaoLotificacion();
            if (daoLotificacion.getByName(this.session, this.lotificacion.getId().getLoNombre(), this.lotificacion.getId().getLoEmpresa()) != null) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Existe una Empresa Registrada con \n el mismo nombre para la Empresa Activa"));
                return;
            }
            daoLotificacion.register(this.session, this.lotificacion);
            
            this.transaction.commit();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto :", "Lotificación Ingresada Correctamente"));
            this.lotificacion = new LoLotificacion();
            this.pkLotificacion = new LoLotificacionId();
          //  RequestContext.getCurrentInstance().update(":frmLotes:panelLotes");
          //  RequestContext.getCurrentInstance().execute("PF('dialogoLotes').show()");

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Error al Ingresar Lotificación Intente Nuevamente" + ex.getMessage()));
            if (this.transaction != null) {
                this.transaction.rollback();
            }

        } finally {
            if (this.session != null) {
                this.session.close();
            }
        }
    }

    public void cargarLotificaciones() {
        if (this.validarEmpresaActiva != null) {
            RequestContext.getCurrentInstance().update("frmSession:panelLotificaciones");
            RequestContext.getCurrentInstance().execute("PF('dialogoLotificaciones').show()");
        }

    }

    public List<SelectItem> generarPoligonos() {
        char poligonoIni=this.poligonoInicial.charAt(0);
        char poligonoFin=this.poligonoFinal.charAt(0);
        int plgInicial = (int) poligonoIni;
        int plgFinal = (int) poligonoFin;
        char plg;
        String poligono;
        List<SelectItem> items = new ArrayList<>();

        for (int i = plgInicial; i <= plgFinal; i++) {
            plg = (char) i;
            poligono = String.valueOf(plg);
            items.add(new SelectItem(poligono, poligono));
        }

        return items;
    }
    
    public HtmlPanelGrid generaPanel() {
        HtmlPanelGrid panelGrid = null;
        int valorInicio;
        int valorFin;
        char caracterPoligono;
        char poligonoIni;
        char poligonoFin;
    
        poligonoIni=this.poligonoInicial.charAt(0);
        poligonoFin=this.poligonoFinal.charAt(0);
        valorInicio = (int) poligonoIni;
        valorFin = (int) poligonoFin;
    
     if(valorInicio!=0&&valorFin!=0){   
        if (panelGrid == null) {
            panelGrid = new HtmlPanelGrid();

            for (int i = valorInicio; i <= valorFin; i++) {
                caracterPoligono=(char) i;
                
                UIOutput etiqueta= new HtmlOutputLabel();
                UIInput txtInput= new HtmlInputText();
                etiqueta.setId("lblpoligono"+caracterPoligono);
                etiqueta.setValue("Poligono "+caracterPoligono+":");
                txtInput.setId("txtpoligono"+caracterPoligono);
                txtInput.setValueExpression("value", createValueExpression("#{mbVLotificacion.poligonoInicial}",String.class));
                panelGrid.getChildren().add(etiqueta);
                panelGrid.getChildren().add(txtInput);
            }

        }
    } 
        return panelGrid;
       
    }


    public LoLotificacion getLotificacion() {
        return lotificacion;
    }

    public void setLotificacion(LoLotificacion lotificacion) {
        this.lotificacion = lotificacion;
    }

    public List<LoLotificacion> getListaLotificacion() {
        return listaLotificacion;
    }

    public void setListaLotificacion(List<LoLotificacion> listaLotificacion) {
        this.listaLotificacion = listaLotificacion;
    }

    public LoLotificacionId getPkLotificacion() {
        return pkLotificacion;
    }

    public void setPkLotificacion(LoLotificacionId pkLotificacion) {
        this.pkLotificacion = pkLotificacion;
    }

    public HttpSession getSessionActiva() {
        return sessionActiva;
    }

    public void setSessionActiva(HttpSession sessionActiva) {
        this.sessionActiva = sessionActiva;
    }

    public int getEmpresaActiva() {
        return empresaActiva;
    }

    public void setEmpresaActiva(int empresaActiva) {
        this.empresaActiva = empresaActiva;
    }

    public List<LoLotificacion> getListaLotificacionFilter() {
        return listaLotificacionFilter;
    }

    public void setListaLotificacionFilter(List<LoLotificacion> listaLotificacionFilter) {
        this.listaLotificacionFilter = listaLotificacionFilter;
    }

    public String getValidarEmpresaActiva() {
        return validarEmpresaActiva;
    }

    public void setValidarEmpresaActiva(String validarEmpresaActiva) {
        this.validarEmpresaActiva = validarEmpresaActiva;
    }

    public String getFiltroLista() {
        return filtroLista;
    }

    public void setFiltroLista(String filtroLista) {
        this.filtroLista = filtroLista;
    }

    public HtmlObjContext getHtmlObjContext() {
        return htmlObjContext;
    }

    public void setHtmlObjContext(HtmlObjContext htmlObjContext) {
        this.htmlObjContext = htmlObjContext;
    }

    public String getPoligonoInicial() {
        return poligonoInicial;
    }

    public void setPoligonoInicial(String poligonoInicial) {
        this.poligonoInicial = poligonoInicial;
    }

    public String getPoligonoFinal() {
        return poligonoFinal;
    }

    public void setPoligonoFinal(String poligonoFinal) {
        this.poligonoFinal = poligonoFinal;
    }

    public HtmlPanelGrid getPnlLotes() {
        return pnlLotes;
    }

    public void setPnlLotes(HtmlPanelGrid pnlLotes) {
        this.pnlLotes = pnlLotes;
    }
    
    

}
