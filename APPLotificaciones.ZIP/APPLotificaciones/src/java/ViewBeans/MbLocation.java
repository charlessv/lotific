/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ViewBeans;

import HibernateUtils.HibernateUtil;
import daos.DaoLoDepartamentos;
import daos.DaoLoMunicipios;
import daos.DaoLoPais;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.primefaces.context.RequestContext;
import pojos.LoDepartamento;
import pojos.LoMunicipios;
import pojos.LoPais;
import utilityclass.HtmlObjContext;

/**
 *
 * @author Carlos
 */
@Named(value = "mbVLocation")
@ViewScoped
public class MbLocation implements Serializable {
    private Session session;
    private Transaction transaction;
    
    private LoPais pais;
    private List<LoPais> listadoPais;
    
    private LoDepartamento departamento;
    private List<LoDepartamento> listaDepartamentos;
    
    private LoMunicipios municipio;
    private List<LoMunicipios> listaMunicipios;
    
    private int idPais;
    private int idDepartamento;
    //Variables para Cast de httpSession
    private String codigoPais;
    private String codigoDepartamento;
    
    private HtmlObjContext htmlObjContextValue;
    
    
    /**
     * Creates a new instance of MbVPais
     */
    public MbLocation() {
        htmlObjContextValue=new HtmlObjContext();
    }
    
    public List<SelectItem> getAllPais()
    {
      this.session=null;
      this.transaction=null;
      try
      {
          this.session=HibernateUtil.getSessionFactory().openSession();
          this.transaction=session.beginTransaction();
          DaoLoPais daoLoPais=new DaoLoPais();
          
          List<SelectItem> items=new ArrayList<>();
          this.listadoPais=daoLoPais.getAll(this.session);
          this.transaction.commit();
          
          for(LoPais item:this.listadoPais){
              items.add(new SelectItem(item.getId().getPaPais(),item.getId().getPaDescripcion()));
          }
          
          return items;
          
      }
      catch(Exception ex)
      {
          FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_ERROR,"Error :","No se Pudieron Cargar Los paises, intentelo nuevamente"));
          if(this.transaction!=null){
              this.transaction.rollback();
          }
          return null;
      }
      finally
      {
          if(this.session!=null){
              this.session.close();
          }
          
      }
    }
    
    public List<SelectItem> getAllDepartamentos()
    {
     this.session=null;
     this.transaction=null;
     try{
         this.session=HibernateUtil.getSessionFactory().openSession();
         this.transaction=session.beginTransaction();
         
         HttpSession httpSession=(HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
         codigoPais=(String) httpSession.getAttribute("idPais");
         if (codigoPais!=null){
                this.idPais=Integer.parseInt(httpSession.getAttribute("idPais").toString());
                DaoLoDepartamentos daoLoDepartamento=new DaoLoDepartamentos();

                List<SelectItem> items=new ArrayList<>();
                this.listaDepartamentos=daoLoDepartamento.getAllDepartamentos(this.session,this.idPais);
                this.transaction.commit();

                for(LoDepartamento item:listaDepartamentos){
                    items.add(new SelectItem(item.getId().getDeIddepartamento(),item.getId().getDeDescripcion()));
                }

                return items;
         }else{
             return null;
         }
     }catch(Exception ex){
         FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_ERROR,"Error :","No se Pudo cargar Lista de Departamentos, intentelo nuevamente"+ex.getMessage()));
         if(this.transaction!=null){
             this.transaction.rollback();
         }
         return null;
     }
     finally{
         if(this.session!=null){
             this.session.close();
         }
     }
    }

    public List<SelectItem> getAllMunicipios()
    {
     this.session=null;
     this.transaction=null;
     try{
         
         this.session=HibernateUtil.getSessionFactory().openSession();
         this.transaction=session.beginTransaction();
         
         HttpSession httpSession=(HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
         codigoDepartamento=(String) httpSession.getAttribute("idDepartamento");
         if(codigoDepartamento!=null){
                this.idDepartamento=Integer.parseInt(httpSession.getAttribute("idDepartamento").toString());

                DaoLoMunicipios daoLoMunicipio=new DaoLoMunicipios();

                List<SelectItem> items=new ArrayList<>();
                this.listaMunicipios=daoLoMunicipio.getAllMunicipios(this.session, this.idDepartamento);
                this.transaction.commit();

                for(LoMunicipios item:listaMunicipios){
                    items.add(new SelectItem(item.getId().getMuIdmunicipio(),item.getId().getMuDescripcion()));
                }

                return items;
         }else{
             return null;
         }    
         
     }catch(Exception ex){
         FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_ERROR,"Error :","No se pudo Cargar Lista de Municipios, intentelo nuevamente"));
         if(this.transaction!=null){
             this.transaction.rollback();
             
         }
         return null;
     }
     finally{
         if(this.session!=null){
             this.session.close();
         }
     }
    }
    
    public void updateContext(int idContexto){
     String formulario="";
     String htmlParam="";
     
     
     HttpSession httpSession=(HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
     formulario=this.htmlObjContextValue.getHtmlObjectName(1);
     
     htmlParam=this.htmlObjContextValue.getComponentValue();
     
        switch(idContexto){
            case 1:
                httpSession.setAttribute("idPais", htmlParam);
                httpSession.setAttribute("idDepartamento","0");
                RequestContext.getCurrentInstance().update(formulario+":cmbdepartamento");
                RequestContext.getCurrentInstance().update(formulario+":cmbmunicipio");
                break;
            case 2:
                httpSession.setAttribute("idDepartamento", htmlParam);
                RequestContext.getCurrentInstance().update(formulario+":cmbmunicipio");
                
                break;
                
                
        }  
          
    }
    public LoPais getPais() {
        return pais;
    }

    public void setPais(LoPais pais) {
        this.pais = pais;
    }

    public List<LoPais> getListadoPais() {
        return listadoPais;
    }

    public void setListadoPais(List<LoPais> listadoPais) {
        this.listadoPais = listadoPais;
    }

    public LoDepartamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(LoDepartamento departamento) {
        this.departamento = departamento;
    }

    public List<LoDepartamento> getListaDepartamentos() {
        return listaDepartamentos;
    }

    public void setListaDepartamentos(List<LoDepartamento> listaDepartamentos) {
        this.listaDepartamentos = listaDepartamentos;
    }

    public int getIdPais() {
        return idPais;
    }

    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    public LoMunicipios getMunicipio() {
        return municipio;
    }

    public void setMunicipio(LoMunicipios municipio) {
        this.municipio = municipio;
    }

    public List<LoMunicipios> getListaMunicipios() {
        return listaMunicipios;
    }

    public void setListaMunicipios(List<LoMunicipios> listaMunicipios) {
        this.listaMunicipios = listaMunicipios;
    }

    public int getIdDepartamento() {
        return idDepartamento;
    }

    public void setIdDepartamento(int idDepartamento) {
        this.idDepartamento = idDepartamento;
    }

    public String getCodigoPais() {
        return codigoPais;
    }

    public void setCodigoPais(String codigoPais) {
        this.codigoPais = codigoPais;
    }

    public String getCodigoDepartamento() {
        return codigoDepartamento;
    }

    public void setCodigoDepartamento(String codigoDepartamento) {
        this.codigoDepartamento = codigoDepartamento;
    }

    public HtmlObjContext getHtmlObjContextValue() {
        return htmlObjContextValue;
    }

    public void setHtmlObjContextValue(HtmlObjContext htmlObjContextValue) {
        this.htmlObjContextValue = htmlObjContextValue;
    }
    
    
    
}
