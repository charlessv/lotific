/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilityclass;

import java.security.MessageDigest;

/**
 *
 * @author Carlos
 */
public class Encriptar {
    public static String sha512(String cadena){
        StringBuilder strBuilder=new StringBuilder();
        try
        {
            MessageDigest md=MessageDigest.getInstance("SHA-512");
            md.update(cadena.getBytes());
            byte[] mb=md.digest();
            for(int i=0;i<mb.length;i++){
                strBuilder.append(Integer.toString(mb[i] &0xff + 0x100,16).substring(1));
            }
            
        }
        catch(Exception ex)
        {
            
        }
        return strBuilder.toString();
    }
    
}
