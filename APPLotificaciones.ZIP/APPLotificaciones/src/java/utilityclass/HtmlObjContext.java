/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilityclass;

import static com.sun.faces.el.ELUtils.createValueExpression;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.component.UIOutput;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.component.html.HtmlInputText;
import javax.faces.component.html.HtmlOutputLabel;
import javax.faces.component.html.HtmlOutputText;

/**
 *
 * @author Carlos
 */
public class HtmlObjContext {

    private String componente;
    private String[] parentId;
    FacesContext facesContext;
    UIComponent uiComponent;

    private String componentValue;
    private char valorInicial;
    private char valorFinal;

    public HtmlObjContext() {
    }

    public String getHtmlObjectName(int request) {
        int sizeArray = 0;
        facesContext = FacesContext.getCurrentInstance();
        uiComponent = UIComponent.getCurrentComponent(facesContext);

        this.componente = (String) uiComponent.getClientId();

        this.parentId = componente.split(":");
        sizeArray = this.parentId.length - 1;

        switch (request) {
            case 1:// NombreFormulario;
                if (sizeArray == 2) {
                    this.componente = this.parentId[sizeArray - 2] + ":" + this.parentId[sizeArray - 1];
                } else {
                    this.componente = this.parentId[sizeArray - 1];
                }

                break;
            case 2:
                this.componente = this.parentId[sizeArray];
                break;
            default:
                this.componente = null;
        }

        return this.componente;
    }

    public void getHtmlObjectValue(ValueChangeEvent evento) {
        try {
            if (evento.getNewValue().toString() != null) {
                this.componentValue = evento.getNewValue().toString();

            } else {
                this.componentValue = null;
            }
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "No se pudo Refrescar el Listado"));
        }
    }

    
    public String getComponente() {
        return componente;
    }

    public void setComponente(String componente) {
        this.componente = componente;
    }

    public String[] getParentId() {
        return parentId;
    }

    public void setParentId(String[] parentId) {
        this.parentId = parentId;
    }

    public String getComponentValue() {
        return componentValue;
    }

    public void setComponentValue(String componentValue) {
        this.componentValue = componentValue;
    }

    public char getValorInicial() {
        return valorInicial;
    }

    public void setValorInicial(char valorInicial) {
        this.valorInicial = valorInicial;
    }

    public char getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(char valorFinal) {
        this.valorFinal = valorFinal;
    }

}
