/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SessionBeans;

import HibernateUtils.HibernateUtil;
import daos.DaoLoEmpresa;
import daos.DaoLoFuncionario;
import daos.DaoLoUsuarios;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.Transaction;
import pojos.LoEmpresa;
import pojos.LoFuncionarios;
import pojos.LoUsuarios;
import utilityclass.Encriptar;

/**
 *
 * @author Carlos
 */
@ManagedBean
@SessionScoped
public class MbSLogin {
 private String usuarioLogin;
  private String password;
  private String codigoVerificacion;
  private String nombreUsuario;
  private String nombreEmpresa;
  private String nombreLotificacion;
  private int codigoEmpresa;
  private int codigoRol;
  private boolean validaLogin;
  
  private Session session;
  private Transaction transaction;
  
  private LoUsuarios usuario;
  private LoFuncionarios funcionario;
  private LoEmpresa empresa;
    /**
     * Creates a new instance of MbSLogin
     */
    public MbSLogin() {
        HttpSession currentSession=(HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        currentSession.setMaxInactiveInterval(50000);
    }
    
    public String login(){
        this.session=null;
        this.transaction=null;
        this.validaLogin=false;
        
        
        try{
            this.session=HibernateUtil.getSessionFactory().openSession();
            this.transaction=session.beginTransaction();
            DaoLoUsuarios daoLoUsuarios=new DaoLoUsuarios();
            DaoLoFuncionario daoLoFuncionarios=new DaoLoFuncionario();
            DaoLoEmpresa daoLoEmpresa=new DaoLoEmpresa();
            
            this.usuario=daoLoUsuarios.getByLoginVerifCode(this.session,this.usuarioLogin,this.codigoVerificacion);
            
            if(usuario!=null){
                
                if(usuario.getUsPassword().equals(Encriptar.sha512(this.password))){
                    this.codigoRol=usuario.getUsRol();
                    this.funcionario=daoLoFuncionarios.getByCodigo(this.session,this.usuario.getUsCodigousuario(),this.codigoVerificacion);
                    this.codigoEmpresa=this.funcionario.getId().getFuEmpresa();
                    this.nombreUsuario=this.funcionario.getFuPnombre()+" "+this.funcionario.getFuPapellido();
                    
                    this.empresa=daoLoEmpresa.getByCodigo(this.session, this.codigoEmpresa);
                    this.nombreEmpresa=this.empresa.getId().getEmNombre();
                    
                    
                    HttpSession httpSession=(HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
                    httpSession.setAttribute("userLogin", this.usuarioLogin);
                    httpSession.setAttribute("empresa", this.codigoEmpresa);
                    
                    this.validaLogin=true;
                    
                }
            }
            this.transaction.commit();
            
            if(this.validaLogin){
               switch(this.codigoRol){ 
                   case 1:   
                    return "/front-menu/optmenusadm";
                   default:
                     return "/front-menu/optmenususer";
               }         
            }else{
            this.usuarioLogin=null;
            this.password=null;
            this.codigoVerificacion=null;
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_ERROR,"Error de Acceso:","Usuario/Password \n o Codigo Verificado Incorrecto"));
            return "index";
            }

            
            
        }catch(Exception ex){
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_ERROR,"Error :","Favor Contactar al Administrador de la Aplicación"));
            if(this.transaction!=null){
                this.transaction.rollback();
            }
            return null;
        }finally{
            if(this.session!=null){
                this.session.close();
            }
        }
        
        
    }
    
    public String closeSession(){
        this.usuarioLogin=null;
        this.codigoVerificacion=null;
        this.nombreEmpresa=null;
        this.nombreUsuario=null;
        this.nombreLotificacion=null;
        this.password=null;
        
       HttpSession httpSession=(HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
       httpSession.invalidate();
       
       return "/index";
        
    }
    
    public String getUsuarioLogin() {
        return usuarioLogin;
    }

    public void setUsuarioLogin(String usuarioLogin) {
        this.usuarioLogin = usuarioLogin;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCodigoVerificacion() {
        return codigoVerificacion;
    }

    public void setCodigoVerificacion(String codigoVerificacion) {
        this.codigoVerificacion = codigoVerificacion;
    }

    public LoUsuarios getUsuario() {
        return usuario;
    }

    public void setUsuario(LoUsuarios usuario) {
        this.usuario = usuario;
    }

    public int getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(int codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public LoFuncionarios getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(LoFuncionarios funcionario) {
        this.funcionario = funcionario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public LoEmpresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(LoEmpresa empresa) {
        this.empresa = empresa;
    }

    public String getNombreLotificacion() {
        return nombreLotificacion;
    }

    public void setNombreLotificacion(String nombreLotificacion) {
        this.nombreLotificacion = nombreLotificacion;
    }
 
}
