/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import org.hibernate.Session;
import pojos.LoFuncionarios;

/**
 *
 * @author Carlos
 */
public interface InterfaceFuncionario {
    public boolean register(Session session,LoFuncionarios funcionario)throws Exception;
    public LoFuncionarios getByDocumento(Session session,String codigoDocumento,int codigoEmpresa)throws Exception;
    public LoFuncionarios getByEmail(Session session, String email,int codigoEmpresa)throws Exception;
    public LoFuncionarios getByCodigo(Session session,String codigoFuncionario,String verifCode) throws Exception;
}
