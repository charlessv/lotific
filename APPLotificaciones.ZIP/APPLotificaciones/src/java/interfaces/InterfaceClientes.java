/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;
import java.util.List;
import org.hibernate.Session;
import pojos.LoClientes;

/**
 *
 * @author Carlos
 */
public interface InterfaceClientes {
    public boolean register(Session session,LoClientes loClientes) throws Exception;
    public boolean update(Session session, LoClientes loClientes)throws Exception;
    public boolean delete(Session session, LoClientes loClientes) throws Exception;
    public List<LoClientes> getAll(Session session,int codigoEmpresa,String estado) throws Exception;
    public LoClientes getByidCliente(Session session,int codigoEmpresa, String idCliente) throws Exception;    
    public LoClientes getByIDsDiff(Session session,int codigoEmpresa, String idCliente,String numDocumento,String numNit)throws Exception;
    public LoClientes getByIDs(Session session,int codigoEmpresa,String numDocumento,String numNit) throws Exception;
}
