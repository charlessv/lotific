/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Auxdetparam;
import entidades.AuxdetparamPK;
import entidades.Eventos;
import entidades.Facturacion;
import entidades.FacturacionPK;
import entidades.Facturacionxpagar;
import entidades.FacturacionxpagarPK;
import entidades.PagosFactura;
import entidades.PagosFacturaPK;
import entidades.PagosFacturaxpagar;
import entidades.PagosFacturaxpagarPK;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import modelo.AuxdetparamFacade;
import modelo.FacturacionFacade;
import modelo.FacturacionxpagarFacade;
import modelo.PagosFacturaFacade;
import modelo.PagosFacturaxpagarFacade;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;

/**
 *
 * @author Carlos
 */
@ManagedBean
@SessionScoped
public class CuentasControlador {

    @EJB
    FacturacionFacade facturacionFacade;
    @EJB
    AuxdetparamFacade parametrizacionFacade;
    @EJB
    PagosFacturaFacade pagosFacturaFacade;

    @EJB
    FacturacionxpagarFacade facturacionxpagarFacade;
    @EJB
    PagosFacturaxpagarFacade pagosProveedorFacade;

    @ManagedProperty("#{eventosControlador}")
    private EventosControlador eventoControlador;

    @ManagedProperty("#{clientesControlador}")
    private ClienteControlador clienteControlador;

    @ManagedProperty("#{proveedoresControlador}")
    private ProveedoresControlador proveedorControlador;

    private Eventos evento;
    //Cuentas por Cobrar
    private Facturacion cuentaxcobrar;
    private PagosFactura pagosFactura;

    //private Facturacion cuentaxcobrarSelected;
    private FacturacionPK cuentasxcobrarPK;
    private PagosFacturaPK pagosFacturaPK;

    //Cuentas por Pagar
    private Facturacionxpagar cuentaxpagar;
    private PagosFacturaxpagar pagosProveedor;

    private FacturacionxpagarPK cuentaxpagarPK;
    private PagosFacturaxpagarPK pagosProveedorPK;

    private Auxdetparam tiposDocumento;
    private AuxdetparamPK tiposDocumentoPK;

    private List<Facturacion> listaCuentasCobro;
    private List<Facturacion> listaComprobantesCobro;
    private List<Facturacion> listaComprobantesCobroSelected;
    private List<Facturacion> listaCuentasCobroFiltrada;

    private List<Facturacionxpagar> listaCuentasPagar;
    private List<Facturacionxpagar> listaComprobantesPago;
    private List<Facturacionxpagar> listaComprobantesPagoSelected;
    private List<Facturacionxpagar> listaCuentasPagoFiltrada;

    private List<Auxdetparam> listaTiposDocumento;
    private List<Auxdetparam> listaEstadosComprobante;
    private List<Auxdetparam> listaFormasdePago;
    private List<Auxdetparam> listaPorcentajeIVA;

    private Date fechaDia;
    private Date fechaVencimiento;
    private Date fechaCalculada;
    private int diasCredito;

    private Double valorIVA;
    private Double valorRetencion;
    private Double valorTotal;
    private Double porcentajeIva;
    private DecimalFormat decimalFormat;

    private boolean mostrarDiasVencimiento;

    private boolean onMontoCobro;
    private boolean onMontoPago;
    private boolean showBtnAddComprobanteCobrar;
    private boolean showBtnAddComprobantePagar;

    /**
     * Creates a new instance of CuentasControlador
     */
    @PostConstruct
    public void init() {
        diasCredito = 30;
        this.porcentajeIva = 13d;

        fechaDia = new Date();
        fechaCalculada = new Date();
        fechaVencimiento = new Date();

        evento = new Eventos();
        cuentasxcobrarPK = new FacturacionPK();
        cuentasxcobrarPK.setIdfactura("");
        cuentasxcobrarPK.setIdtdocumento(0);

        cuentaxcobrar = new Facturacion();
        cuentaxcobrar.setFacturacionPK(cuentasxcobrarPK);
        cuentaxcobrar.setFechaingreso(fechaDia);
        cuentaxcobrar.setFechaemision(fechaDia);
        cuentaxcobrar.setFechaquedan(fechaDia);
        cuentaxcobrar.setDiascredito(diasCredito);
        cuentaxcobrar.setCredito(Boolean.FALSE);
        cuentaxcobrar.setEstado(0);

        pagosFacturaPK = new PagosFacturaPK();

        pagosFactura = new PagosFactura();
        pagosFactura.setPagosFacturaPK(pagosFacturaPK);
        pagosFactura.setTipopago(0);
        pagosFactura.setFechapago(fechaDia);
        pagosFactura.setFecharegistropago(fechaDia);

        //Variable Cuentas x Pagar
        cuentaxpagarPK = new FacturacionxpagarPK();
        cuentaxpagarPK.setIdfactura("");
        cuentaxpagarPK.setIdtdocumento(0);

        cuentaxpagar = new Facturacionxpagar();
        cuentaxpagar.setFacturacionxpagarPK(cuentaxpagarPK);
        cuentaxpagar.setFechaingreso(fechaDia);
        cuentaxpagar.setFechaemision(fechaDia);
        cuentaxpagar.setFechaquedan(fechaDia);
        cuentaxpagar.setDiascredito(diasCredito);
        cuentaxpagar.setCredito(Boolean.FALSE);
        cuentaxpagar.setEstado(0);

        pagosProveedorPK = new PagosFacturaxpagarPK();

        pagosProveedor = new PagosFacturaxpagar();
        pagosProveedor.setPagosFacturaxpagarPK(pagosProveedorPK);
        pagosProveedor.setTipopago(0);
        pagosProveedor.setFechapago(fechaDia);
        pagosProveedor.setFecharegistropago(fechaDia);

        tiposDocumentoPK = new AuxdetparamPK();
        tiposDocumentoPK.setCodigo(1);
        tiposDocumento = new Auxdetparam();

        tiposDocumento.setAuxdetparamPK(tiposDocumentoPK);

        listaCuentasCobro = new ArrayList<>();
        listaComprobantesCobro = new ArrayList<>();
        listaComprobantesCobroSelected = new ArrayList<>();
        listaTiposDocumento = new ArrayList<>();
        listaFormasdePago = new ArrayList<>();

        listaCuentasCobro = cargarCuentasCobro();
        listaCuentasPagar = cargarCuentasPago();
        listaTiposDocumento = cargarTiposDocumento();
        listaFormasdePago = cargarFormasPago();

        habilitarControlesDocCobro();
        habilitarControlesDocPago();

    }

    public CuentasControlador() {
    }

    public void crearCobro() {
        try {
            this.cuentasxcobrarPK
                    .setIdCliente(this.cuentaxcobrar.getClientes().getIdCliente());

            this.cuentaxcobrar.setFacturacionPK(cuentasxcobrarPK);
            if (cuentaxcobrar.getFacturacionPK().getIdtdocumento() == 0) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error :", "Debe Seleccionar el Tipo de Comprobante"));
                return;

            }

            if ((cuentaxcobrar.getCredito()) && (cuentaxcobrar.getDiascredito() == null || cuentaxcobrar.getDiascredito() <= 0)) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error :", "Credito no puede ser a cero días"));
                return;
            }
            if (cuentaxcobrar.getFacturacionPK().getIdtdocumento() == 0
                    && this.listaComprobantesCobroSelected.isEmpty()) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Atención :", "Debe Asociar Comprobantes a Quedan"));
                listarComprobantesCredito();
                RequestContext.getCurrentInstance().update(":frmCobros:pnlComprobante");
                RequestContext.getCurrentInstance().execute("PF('dlgComprobantes').show()");
                return;
            }
            if (cuentaxcobrar.getMonto() == 0) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error :", "Monto debe ser Mayor a Cero"));
                return;
            }

            if (facturacionFacade.buscarComprobante(cuentaxcobrar.getFacturacionPK().getIdfactura(),
                    cuentaxcobrar.getFacturacionPK().getIdtdocumento(),
                    cuentaxcobrar.getFacturacionPK().getIdCliente()) != null) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "No de Comprobante ya Registrado"));
                return;
            } else {

                facturacionFacade.create(cuentaxcobrar);

                if (cuentaxcobrar.getFacturacionPK().getIdtdocumento() == 0
                        && !this.listaComprobantesCobroSelected.isEmpty()) {
                    for (Facturacion comprobantes : listaComprobantesCobroSelected) {
                        comprobantes.setIdquedan(cuentaxcobrar.getFacturacionPK().getIdfactura());

                        facturacionFacade.edit(comprobantes);
                    }
                    this.listaComprobantesCobroSelected.clear();
                }

                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                        "Correcto:", "Comprobante Registrado Correctamente"));

                limpiarComprobantesCobro();

                habilitarControlesDocCobro();
                cargarCuentasCobro();

                RequestContext.getCurrentInstance().update("frmCobros:accobros:tblCuentasCobro");
                RequestContext.getCurrentInstance().update("frmCobros:accobros:pnlcobros");
            }

        } catch (NullPointerException | NumberFormatException ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Debe Completar los Datos Solicitados"));
        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Registrar Comprobante"));
        }
    }

    public void anularCobro(Facturacion documento) {
        try {
            this.cuentaxcobrar = documento;
            if (cuentaxcobrar.getEstado() == 1) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error:", "Comprobante ya se encuentra Cancelado, No puede ser Anulado"));
            } else {

                if (cuentaxcobrar.getEstado() == 2) {
                    FacesContext.getCurrentInstance()
                            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                            "Error:", "Comprobante ya se encuentra Anulado"));
                } else {
                    cuentaxcobrar.setEstado(2);
                    facturacionFacade.edit(cuentaxcobrar);
                    if (cuentaxcobrar.getFacturacionPK().getIdtdocumento() == 0) {
                        listaComprobantesCobro = facturacionFacade
                                .obtenerComprobantesporQuedan(cuentaxcobrar.getFacturacionPK().getIdfactura());

                        if (!listaComprobantesCobro.isEmpty()) {
                            for (Facturacion comprobante : listaComprobantesCobro) {
                                comprobante.setIdquedan(null);
                                facturacionFacade.edit(comprobante);
                            }
                        }
                    }

                    FacesContext.getCurrentInstance()
                            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                            "Correcto:", "Comprobante Anulado Exitosamente"));
                }
            }
            limpiarComprobantesCobro();
            this.cargarCuentasCobro();
            RequestContext.getCurrentInstance().update("frmCobros:accobros:tblCuentasCobro");
            RequestContext.getCurrentInstance().update("frmCobros:accobros:pnlcobros");
        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error:", "No se anulo comprobante, intentelo nuevamente" + ex.getMessage()));
        }
    }

    public void validarComprobanteCobro(int accion, Facturacion comprobante) {
        try {
            this.cuentaxcobrar = comprobante;

            switch (accion) {
                case 1:
                    if (cuentaxcobrar.getEstado() == 2) {
                        FacesContext.getCurrentInstance()
                                .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Error:", "Comprobante se Encuentra Anulado, no se puede Ingresar Pago"));
                        limpiarComprobantesCobro();
                        RequestContext.getCurrentInstance().update("frmCobros:accobros:tblCuentasCobro");
                        RequestContext.getCurrentInstance().update("frmCobros:accobros:pnlcobros");
                    } else {

                        if (cuentaxcobrar.getEstado() == 1) {
                            FacesContext.getCurrentInstance()
                                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                    "Error:", "Ya se registro el pago del Comprobante"));
                            limpiarComprobantesCobro();
                            RequestContext.getCurrentInstance().update("frmCobros:accobros:tblCuentasCobro");
                            RequestContext.getCurrentInstance().update("frmCobros:accobros:pnlcobros");
                        } else {
                            this.calculaTotal(0);
                            this.pagosFactura.setMonto(this.valorTotal);
                            RequestContext.getCurrentInstance().update("frmCobros:pnlAddPago");
                            RequestContext.getCurrentInstance().execute("PF('dlgAddPago').show()");
                        }
                    }
                    break;

                case 2:
                    if (this.cuentaxcobrar.getEstado() != 0) {
                        FacesContext.getCurrentInstance()
                                .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Error:", "El Comprobante no se encuentra en un estado que pueda ser Modificado"));
                        limpiarComprobantesCobro();
                        RequestContext.getCurrentInstance().update("frmCobros:accobros:tblCuentasCobro");
                        RequestContext.getCurrentInstance().update("frmCobros:accobros:pnlcobros");
                    } else {
                        RequestContext.getCurrentInstance().update("frmCobros:pnlEditComprobante");
                        RequestContext.getCurrentInstance().execute("PF('dlgEditComprobante').show()");
                    }
                    break;

            }

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error:", "No se pudo validar Comprobante"));

        }
    }

    public void registrarPagoxCobro() {
        try {
            this.pagosFacturaPK.setIdfactura(this.cuentaxcobrar.getFacturacionPK().getIdfactura());
            this.pagosFacturaPK.setTipodocumento(this.cuentaxcobrar.getFacturacionPK().getIdtdocumento());
            this.pagosFacturaPK.setIdCliente(this.cuentaxcobrar.getFacturacionPK().getIdCliente());

            this.pagosFactura.setPagosFacturaPK(pagosFacturaPK);

            if (this.pagosFactura.getTipopago() == 0) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error:", "Debe Seleccionar Forma de Pago"));
                return;
            } else {
                if (!Objects.equals(this.pagosFactura.getMonto(), this.cuentaxcobrar.getMonto() + this.valorIVA)) {
                    FacesContext.getCurrentInstance()
                            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                            "Error:", "El Valor Ingresado es Diferente al Monto del Comprobante a Cancelar"));
                    return;
                } else {
                    pagosFacturaFacade.create(pagosFactura);
                    cuentaxcobrar.setEstado(1);
                    facturacionFacade.edit(cuentaxcobrar);

                    if (cuentaxcobrar.getIdEvento() != null) {//Se actualiza estado Evento en caso de ser cancelE
                        if (facturacionFacade
                                .saldoxEvento(cuentaxcobrar.getIdEvento()) >= cuentaxcobrar.getIdEvento().getCosto()) {
                            this.evento = cuentaxcobrar.getIdEvento();
                            this.evento.setEstado(3);
                            this.eventoControlador.eventoFacade.edit(evento);

                        }

                    }

                    FacesContext.getCurrentInstance()
                            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                            "Correcto:", "Pago Registrado Exitosamente"));

                    RequestContext.getCurrentInstance().execute("PF('dlgAddPago').hide()");

                }

            }

            limpiarComprobantesCobro();
            RequestContext.getCurrentInstance().update("frmCobros:accobros:tblCuentasCobro");
            RequestContext.getCurrentInstance().update("frmCobros:accobros:pnlcobros");

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error:", "Pago no Registrado, Intentelo Nuevamente" + ex.getMessage()));
            return;
        }

    }

    public void calcularMontoQuedanCobro() {
        double valor = 0;

        for (Facturacion comprobantes : this.listaComprobantesCobroSelected) {
            valor += comprobantes.getMonto();
        }
        this.cuentaxcobrar.setMonto(valor);
        RequestContext.getCurrentInstance().update("frmCobros:accobros:tblCuentasCobro");
        RequestContext.getCurrentInstance().update("frmCobros:accobros:pnlcobros");
    }

    public void generarVencimientoPorCobrar(int tipo) {
        if (tipo == 0) {
            this.cuentaxcobrar.setDiascredito(this.calcularVencimiento());
        } else {
            this.fechaVencimiento = addDays(this.cuentaxcobrar.getFechaquedan(),
                    this.cuentaxcobrar.getDiascredito());
        }
        RequestContext.getCurrentInstance().update("frmCobros");

    }

    public void asignarFechaVencimientoCobro(SelectEvent event) {
        this.fechaVencimiento = (Date) event.getObject();
        this.generarVencimientoPorCobrar(1);
    }

    //METODOS CUENTAS X PAGAR
    public void crearCuentaxPagar() {
        try {
            this.cuentaxpagarPK
                    .setIdproveedor(this.cuentaxpagar.getFacturacionxpagarPK().getIdproveedor());

            this.cuentaxpagar.setFacturacionxpagarPK(cuentaxpagarPK);
            if (cuentaxpagar.getFacturacionxpagarPK().toString() == null) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error :", "Debe Seleccionar el Tipo de Comprobante"));
                return;

            }

            if ((cuentaxpagar.getCredito()) && (cuentaxpagar.getDiascredito() == null || cuentaxpagar.getDiascredito() <= 0)) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error :", "Credito no puede ser a cero días"));
                return;
            }
            if (cuentaxpagar.getFacturacionxpagarPK().getIdtdocumento() == 0
                    && this.listaComprobantesPagoSelected.isEmpty()) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Atención :", "Debe Asociar Comprobantes a Quedan"));
                listarComprobantesCredito();
                RequestContext.getCurrentInstance().update(":frmPagos:pnlComprobante");
                RequestContext.getCurrentInstance().execute("PF('dlgComprobantes').show()");
                return;
            }
            if (cuentaxpagar.getMonto() == 0) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error :", "Monto debe ser Mayor a Cero"));
                return;
            }

            if (facturacionxpagarFacade.buscarComprobante(cuentaxpagar.getFacturacionxpagarPK().getIdfactura(),
                    cuentaxpagar.getFacturacionxpagarPK().getIdtdocumento(),
                    cuentaxpagar.getFacturacionxpagarPK().getIdproveedor()) != null) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "No de Comprobante ya Registrado"));
                return;
            } else {
                cuentaxpagarPK.setIdproveedor(cuentaxpagar.getProveedores().getIdproveedor());
                cuentaxpagar.setFacturacionxpagarPK(cuentaxpagarPK);
                facturacionxpagarFacade.create(cuentaxpagar);

                if (cuentaxpagar.getFacturacionxpagarPK().getIdtdocumento() == 0
                        && !this.listaComprobantesCobroSelected.isEmpty()) {
                    for (Facturacionxpagar comprobantes : listaComprobantesPagoSelected) {
                        comprobantes.setIdquedan(cuentaxpagar.getFacturacionxpagarPK().getIdfactura());

                        facturacionxpagarFacade.edit(comprobantes);
                    }
                    this.listaComprobantesPagoSelected.clear();
                }

                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                        "Correcto:", "Comprobante Registrado Correctamente"));

                limpiarComprobantesPago();

                habilitarControlesDocPago();
                cargarCuentasPago();

                RequestContext.getCurrentInstance().update("frmPagos:acpagos:tblCuentasPago");
                RequestContext.getCurrentInstance().update("frmPagos:acpagos:pnlpagos");
            }

        } catch (NullPointerException | NumberFormatException ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Debe Completar los Datos Solicitados"));
        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Registrar Comprobante"));
        }
    }

    public void anularPago(Facturacionxpagar documento) {
        try {
            this.cuentaxpagar = documento;
            if (cuentaxpagar.getEstado() == 1) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error:", "Comprobante ya se encuentra Cancelado, No puede ser Anulado"));
            } else {

                if (cuentaxpagar.getEstado() == 2) {
                    FacesContext.getCurrentInstance()
                            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                            "Error:", "Comprobante ya se encuentra Anulado"));
                } else {
                    cuentaxpagar.setEstado(2);
                    facturacionxpagarFacade.edit(cuentaxpagar);
                    if (cuentaxpagar.getFacturacionxpagarPK().getIdtdocumento() == 0) {
                        listaComprobantesPago = facturacionxpagarFacade
                                .obtenerComprobantesporQuedan(cuentaxpagar.getFacturacionxpagarPK().getIdfactura());

                        if (!listaComprobantesPago.isEmpty()) {
                            for (Facturacionxpagar comprobante : listaComprobantesPago) {
                                comprobante.setIdquedan(null);
                                facturacionxpagarFacade.edit(comprobante);
                            }
                        }
                    }

                    FacesContext.getCurrentInstance()
                            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                            "Correcto:", "Comprobante Anulado Exitosamente"));
                }
            }
            limpiarComprobantesPago();
            this.cargarCuentasPago();
            RequestContext.getCurrentInstance().update("frmPagos:acpagos:tblCuentasPago");
            RequestContext.getCurrentInstance().update("frmPagos:acpagos:pnlpagos");
        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error:", "No se anulo comprobante, intentelo nuevamente" + ex.getMessage()));
        }
    }

    public void validarComprobantePago(int accion, Facturacionxpagar comprobante) {
        try {
            this.cuentaxpagar = comprobante;

            switch (accion) {
                case 1:
                    if (cuentaxpagar.getEstado() == 2) {
                        FacesContext.getCurrentInstance()
                                .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Error:", "Comprobante se Encuentra Anulado, no se puede Ingresar Pago"));
                        limpiarComprobantesPago();
                        RequestContext.getCurrentInstance().update("frmPagos:acpagos:tblCuentasPago");
                        RequestContext.getCurrentInstance().update("frmPagos:acpagos:pnlpagos");
                    } else {

                        if (cuentaxpagar.getEstado() == 1) {
                            FacesContext.getCurrentInstance()
                                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                    "Error:", "Ya se registro el pago del Comprobante"));
                            limpiarComprobantesPago();
                            RequestContext.getCurrentInstance().update("frmPagos:acpagos:tblCuentasPago");
                            RequestContext.getCurrentInstance().update("frmPagos:acpagos:pnlpagos");
                        } else {
                            this.calculaTotal(1);
                            this.pagosProveedor.setMonto(this.valorTotal);
                            RequestContext.getCurrentInstance().update("frmPagos:pnlAddCobro");
                            RequestContext.getCurrentInstance().execute("PF('dlgAddCobro').show()");
                        }
                    }
                    break;

                case 2:
                    if (this.cuentaxpagar.getEstado() != 0) {
                        FacesContext.getCurrentInstance()
                                .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Error:", "El Comprobante no se encuentra en un estado que pueda ser Modificado"));
                        limpiarComprobantesPago();
                        RequestContext.getCurrentInstance().update("frmPagos:acpagos:tblCuentasPago");
                        RequestContext.getCurrentInstance().update("frmPagos:acpagos:pnlpagos");
                    } else {
                        RequestContext.getCurrentInstance().update("frmPagos:pnlEditComprobante");
                        RequestContext.getCurrentInstance().execute("PF('dlgEditComprobante').show()");
                    }
                    break;

            }

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error:", "No se pudo validar Comprobante"));

        }
    }

    public void registrarCobroxPago() {
        try {
            this.pagosProveedorPK.setIdfactura(this.cuentaxpagar.getFacturacionxpagarPK().getIdfactura());
            this.pagosProveedorPK.setTipodocumento(this.cuentaxpagar.getFacturacionxpagarPK().getIdtdocumento());
            this.pagosProveedorPK.setIdproveedor(this.cuentaxpagar.getFacturacionxpagarPK().getIdproveedor());

            this.pagosProveedor.setPagosFacturaxpagarPK(pagosProveedorPK);

            if (this.pagosProveedor.getTipopago() == 0) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error:", "Debe Seleccionar Forma de Pago"));
                return;
            } else {
                if (!Objects.equals(this.pagosProveedor.getMonto(), this.cuentaxpagar.getMonto() + this.valorIVA)) {
                    FacesContext.getCurrentInstance()
                            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                            "Error:", "El Valor Ingresado es Diferente al Monto del Comprobante a Cancelar"));
                    return;
                } else {
                    pagosProveedorFacade.create(pagosProveedor);
                    cuentaxpagar.setEstado(1);
                    facturacionxpagarFacade.edit(cuentaxpagar);

                    FacesContext.getCurrentInstance()
                            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                            "Correcto:", "Pago Registrado Exitosamente"));

                    RequestContext.getCurrentInstance().execute("PF('dlgAddCobro').hide()");

                }

            }

            limpiarComprobantesPago();
            RequestContext.getCurrentInstance().update("frmPagos:acpagos:tblCuentasPago");
            RequestContext.getCurrentInstance().update("frmPagos:acpagos:pnlpagos");

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error:", "Pago no Registrado, Intentelo Nuevamente" + ex.getMessage()));
            return;
        }

    }

    public void calcularMontoQuedanPago() {
        double valor = 0;

        for (Facturacionxpagar comprobantes : this.listaComprobantesPagoSelected) {
            valor += comprobantes.getMonto();
        }
        this.cuentaxpagar.setMonto(valor);
        RequestContext.getCurrentInstance().update("frmPagos:acpagos:tblCuentasPago");
        RequestContext.getCurrentInstance().update("frmPagos:acpagos:pnlpagos");
    }

    public void generarVencimientoPorPagar(int tipo) {
        if (tipo == 0) {
            this.cuentaxpagar.setDiascredito(this.calcularVencimiento());
        } else {
            this.fechaVencimiento = addDays(this.cuentaxpagar.getFechaquedan(),
                    this.cuentaxpagar.getDiascredito());
        }
        RequestContext.getCurrentInstance().update("frmPagos");

    }

    public void asignarFechaVencimientoPagar(SelectEvent event) {
        this.fechaVencimiento = (Date) event.getObject();
        this.generarVencimientoPorPagar(1);
    }

    /**
     * **** METODOS COMUNES ********
     */
    public Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days);
        return cal.getTime();
    }

    public int calcularDiasVencido(Object factura, int rubro) {
        Date fechavencimiento;
        fechavencimiento = new Date();
        long diff;

        switch (rubro) {
            case 0:

                Facturacion comprobante = new Facturacion();
                comprobante = (Facturacion) factura;

                if (comprobante.getEstado() == 0) {
                    if (comprobante.getDiascredito() == null) {
                        comprobante.setDiascredito(0);
                    }
                    fechavencimiento = addDays(comprobante.getFechaquedan(),
                            comprobante.getDiascredito());

                    if (this.fechaDia.getTime() > fechavencimiento.getTime()) {
                        diff = this.fechaDia.getTime() - fechavencimiento.getTime();
                        return (int) (diff / (1000 * 60 * 60 * 24));
                    } else {
                        return 0;
                    }
                } else {
                    return 0;
                }

            case 1:
                Facturacionxpagar comprobantes = new Facturacionxpagar();
                comprobantes = (Facturacionxpagar) factura;

                if (comprobantes.getEstado() == 0) {
                    if (comprobantes.getDiascredito() == null) {
                        comprobantes.setDiascredito(0);
                    }
                    fechavencimiento = addDays(comprobantes.getFechaquedan(),
                            comprobantes.getDiascredito());

                    if (this.fechaDia.getTime() > fechavencimiento.getTime()) {
                        diff = this.fechaDia.getTime() - fechavencimiento.getTime();
                        return (int) (diff / (1000 * 60 * 60 * 24));
                    } else {
                        return 0;
                    }
                } else {
                    return 0;
                }

        }
        return 0;
    }

    public int calcularVencimiento() {
        long diff;
        int diasdiff;

        if (this.fechaVencimiento.getTime() > this.fechaDia.getTime()) {
            diff = this.fechaVencimiento.getTime() - this.fechaDia.getTime();
            diasdiff = (int) (diff / (1000 * 60 * 60 * 24));
        } else {
            diasdiff = 0;
        }
        return diasdiff;
    }

    public void calculaIVA(int rubro) {
        this.valorIVA = 0d;
        switch (rubro) {
            case 0:
                if (!this.cuentaxcobrar.getGeneraiva()
                        && this.cuentaxcobrar.getMonto() >= 0) {
                    this.valorIVA = this.cuentaxcobrar.getMonto() * (this.porcentajeIva / 100);
                }
                if (Double.isNaN(this.valorIVA)) {
                    this.valorIVA = 0d;
                }
                break;
            case 1:
                if (!this.cuentaxpagar.getGeneraiva()
                        && this.cuentaxpagar.getMonto() >= 0) {
                    this.valorIVA = this.cuentaxpagar.getMonto() * (this.porcentajeIva / 100);
                }
                if (Double.isNaN(this.valorIVA)) {
                    this.valorIVA = 0d;
                }
                break;
        }
    }

    public void calculaRetencion(int rubro) {
        this.valorRetencion = 0d;
        switch (rubro) {
            case 0:
                if (this.cuentaxcobrar.getGenretencion()
                        && this.cuentaxcobrar.getMonto() >= 0) {
                    this.valorRetencion = this.cuentaxcobrar.getMonto() * 0.01;
                }
                if (Double.isNaN(this.valorRetencion)) {
                    this.valorRetencion = 0d;
                }

                break;
            case 1:
                if (this.cuentaxpagar.getGenretencion()
                        && this.cuentaxpagar.getMonto() >= 0) {
                    this.valorRetencion = this.cuentaxpagar.getMonto() * 0.01;
                }
                if (Double.isNaN(this.valorRetencion)) {
                    this.valorRetencion = 0d;
                }
                break;
        }
    }

    public void calculaTotal(int rubro) {
        this.valorTotal = 0d;

            this.calculaIVA(rubro);
        this.calculaRetencion(rubro);

        switch (rubro) {
            case 0:
                this.valorTotal = this.cuentaxcobrar.getMonto()
                        + this.valorIVA
                        - this.valorRetencion;
                if (Double.isNaN(this.valorTotal)) {
                    this.valorTotal = 0d;
                }

                RequestContext.getCurrentInstance().update("frmCobros");
                //this.limpiarComprobantesCobro();
                break;
            case 1:
                this.valorTotal = this.cuentaxpagar.getMonto()
                        + this.valorIVA
                        + this.valorRetencion;
                if (Double.isNaN(this.valorTotal)) {
                    this.valorTotal = 0d;
                }

                RequestContext.getCurrentInstance().update("frmPagos");
               // this.limpiarComprobantesPago();
                break;
        }
    }

    public double calculaTotal(Object cuenta, int rubro) {
        try {
            switch (rubro) {
                case 0:
                    this.cuentaxcobrar = (Facturacion) cuenta;
                    break;
                case 1:
                    this.cuentaxpagar = (Facturacionxpagar) cuenta;
                    break;
            }
            this.calculaTotal(rubro);

        } catch (Exception ex) {
            return 0d;
        }
        return this.valorTotal;
    }

    public List<Facturacion> cargarCuentasCobro() {
        listaCuentasCobro = facturacionFacade.comprobantes();
        return this.listaCuentasCobro;
    }

    public List<Facturacionxpagar> cargarCuentasPago() {
        this.listaCuentasPagar = facturacionxpagarFacade.comprobantes();
        return this.listaCuentasPagar;
    }

    public void listarComprobantesCredito() {
        try {
            listaComprobantesCobro = facturacionFacade.listarComprobantes();
        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No Se pudo Listar Comprobantes de Cobro"));
        }
    }

    /*public void listarComprobantesPagar() {
     try {
     listaComprobantesPago = facturacionFacade.listarComprobantes('P');
     } catch (Exception ex) {
     FacesContext.getCurrentInstance()
     .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No Se pudo Listar Comprobantes por Pagar"));
     }
     }*/
    public List<Auxdetparam> cargarTiposDocumento() {
        this.listaTiposDocumento = parametrizacionFacade.catalogoFiltrado(4);

        return this.listaTiposDocumento;
    }

    public List<Auxdetparam> cargarEstadosComprobantes() {
        this.listaEstadosComprobante = parametrizacionFacade.catalogoFiltrado(7);

        return this.listaEstadosComprobante;
    }

    public List<Auxdetparam> cargarFormasPago() {
        this.listaFormasdePago = parametrizacionFacade.catalogoFiltrado(8);
        return this.listaFormasdePago;
    }

    public List<Auxdetparam> cargarTiposIva() {
        this.listaPorcentajeIVA = parametrizacionFacade.catalogoFiltrado(11);
        return this.listaPorcentajeIVA;
    }

    public List<SelectItem> listarDocumentos() {
        List<SelectItem> listaSelectedDocumentos;
        listaSelectedDocumentos = new ArrayList<>();

        cargarTiposDocumento();

        for (Auxdetparam documento : listaTiposDocumento) {
            listaSelectedDocumentos
                    .add(new SelectItem(documento.getAuxdetparamPK().getCodigo(),
                                    documento.getAuxdetparamPK().getDescripcion()));
        }

        return listaSelectedDocumentos;
    }

    public List<SelectItem> listarEstadoComprobantes() {
        List<SelectItem> listaSelectedEstados;
        listaSelectedEstados = new ArrayList<>();

        cargarEstadosComprobantes();

        for (Auxdetparam estado : listaEstadosComprobante) {
            listaSelectedEstados
                    .add(new SelectItem(estado.getAuxdetparamPK().getCodigo(),
                                    estado.getAuxdetparamPK().getDescripcion()));
        }

        return listaSelectedEstados;
    }

    public List<SelectItem> listarFormasPago() {
        List<SelectItem> listaFormasPago;
        listaFormasPago = new ArrayList<>();

        cargarFormasPago();

        for (Auxdetparam fPago : this.listaFormasdePago) {
            listaFormasPago
                    .add(new SelectItem(fPago.getAuxdetparamPK().getCodigo(),
                                    fPago.getAuxdetparamPK().getDescripcion()));
        }

        return listaFormasPago;
    }

    public List<SelectItem> listarPorcentajeIva() {
        List<SelectItem> listaSelectedIva;
        listaSelectedIva = new ArrayList<>();

        cargarTiposIva();

        for (Auxdetparam iva : this.listaPorcentajeIVA) {
            listaSelectedIva
                    .add(new SelectItem(iva.getValaux(),
                                    iva.getAuxdetparamPK().getDescripcion()
                                    + "(" + iva.getValaux() + "%)"));
        }

        return listaSelectedIva;
    }

    public String descripcionComprobante(int idComprobante) {
        for (Auxdetparam comprobante : listaTiposDocumento) {
            if (comprobante.getAuxdetparamPK().getCodigo() == idComprobante) {
                return comprobante.getAuxdetparamPK().getDescripcion();
            }
        }
        return "No Definido";
    }

    public void habilitarControlesDocCobro() {
        try {
            if (this.cuentaxcobrar.getFacturacionPK().getIdtdocumento() == 0) {
                this.onMontoCobro = Boolean.TRUE;
                this.cuentaxcobrar.setGeneraiva(Boolean.FALSE);
                this.cuentaxcobrar.setGenretencion(Boolean.FALSE);
                this.showBtnAddComprobanteCobrar = Boolean.TRUE;
                //this.cuentaxcobrar.setMonto(0d);
            } else {
                this.onMontoCobro = Boolean.FALSE;
                this.showBtnAddComprobanteCobrar = Boolean.FALSE;
            }

            RequestContext.getCurrentInstance().update(":frmCobros");
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_FATAL,
                            "Error:", "Error al seleccionar forma de Cobro" + ex.getMessage()));
        }
    }

    public void habilitarControlesDocPago() {
        if (this.cuentaxpagar.getFacturacionxpagarPK().getIdtdocumento() == 0) {
            this.onMontoPago = Boolean.TRUE;
            this.cuentaxpagar.setGeneraiva(Boolean.FALSE);
            this.cuentaxpagar.setGenretencion(Boolean.FALSE);
            //this.showBtnAddComprobanteCobrar = Boolean.TRUE;
        } else {
            this.onMontoPago = Boolean.FALSE;
            //this.showBtnAddComprobantePagar = Boolean.FALSE;
        }

        RequestContext.getCurrentInstance().update(":frmPagos");
    }

    public void limpiarComprobantesCobro() {
        evento = new Eventos();
        cuentasxcobrarPK = new FacturacionPK();
        cuentasxcobrarPK.setIdfactura("");
        cuentasxcobrarPK.setIdtdocumento(0);
        cuentasxcobrarPK.setIdCliente(0);

        cuentaxcobrar = new Facturacion();
        cuentaxcobrar.setFacturacionPK(cuentasxcobrarPK);
        cuentaxcobrar.setFechaingreso(fechaDia);
        cuentaxcobrar.setCredito(Boolean.FALSE);
        cuentaxcobrar.setFechaemision(fechaDia);
        cuentaxcobrar.setFechaquedan(fechaDia);

        pagosFacturaPK = new PagosFacturaPK();

        pagosFactura = new PagosFactura();
        pagosFactura.setPagosFacturaPK(pagosFacturaPK);
        pagosFactura.setTipopago(0);
        pagosFactura.setFechapago(fechaDia);
        pagosFactura.setFecharegistropago(fechaDia);

       /* this.valorIVA = null;
        this.valorRetencion = null;
        this.valorTotal = null;*/
        habilitarControlesDocCobro();
        habilitarControlesDocPago();
    }

    public void limpiarComprobantesPago() {
        cuentaxpagarPK = new FacturacionxpagarPK();
        cuentaxpagarPK.setIdfactura("");
        cuentaxpagarPK.setIdtdocumento(0);

        cuentaxpagar = new Facturacionxpagar();
        cuentaxpagar.setFacturacionxpagarPK(cuentaxpagarPK);
        cuentaxpagar.setFechaingreso(fechaDia);
        cuentaxpagar.setCredito(Boolean.FALSE);

        habilitarControlesDocPago();
        /*this.valorIVA = 0d;
        this.valorRetencion = 0d;
        this.valorTotal = 0d;*/
    }

    public String obtenerEstadoComprobante(int idCodigo) {
        String estado = "";
        estado = parametrizacionFacade.getDescripcionByID(7, idCodigo);

        return estado;
    }

    public EventosControlador getEventoControlador() {
        return eventoControlador;
    }

    public void setEventoControlador(EventosControlador eventoControlador) {
        this.eventoControlador = eventoControlador;
    }

    public ClienteControlador getClienteControlador() {
        return clienteControlador;
    }

    public void setClienteControlador(ClienteControlador clienteControlador) {
        this.clienteControlador = clienteControlador;
    }

    public ProveedoresControlador getProveedorControlador() {
        return proveedorControlador;
    }

    public void setProveedorControlador(ProveedoresControlador proveedorControlador) {
        this.proveedorControlador = proveedorControlador;
    }

    public Eventos getEvento() {
        return evento;
    }

    public void setEvento(Eventos evento) {
        this.evento = evento;
    }

    public Facturacion getCuentaxcobrar() {
        return cuentaxcobrar;
    }

    public void setCuentaxcobrar(Facturacion cuentaxcobrar) {
        this.cuentaxcobrar = cuentaxcobrar;
    }

    public PagosFactura getPagosFactura() {
        return pagosFactura;
    }

    public void setPagosFactura(PagosFactura pagosFactura) {
        this.pagosFactura = pagosFactura;
    }

    public Facturacionxpagar getCuentaxpagar() {
        return cuentaxpagar;
    }

    public void setCuentaxpagar(Facturacionxpagar cuentaxpagar) {
        this.cuentaxpagar = cuentaxpagar;
    }

    public PagosFacturaxpagar getPagosProveedor() {
        return pagosProveedor;
    }

    public void setPagosProveedor(PagosFacturaxpagar pagosProveedor) {
        this.pagosProveedor = pagosProveedor;
    }

    public Auxdetparam getTiposDocumento() {
        return tiposDocumento;
    }

    public void setTiposDocumento(Auxdetparam tiposDocumento) {
        this.tiposDocumento = tiposDocumento;
    }

    public List<Facturacion> getListaCuentasCobro() {
        return listaCuentasCobro;
    }

    public void setListaCuentasCobro(List<Facturacion> listaCuentasCobro) {
        this.listaCuentasCobro = listaCuentasCobro;
    }

    public List<Facturacion> getListaComprobantesCobro() {
        return listaComprobantesCobro;
    }

    public void setListaComprobantesCobro(List<Facturacion> listaComprobantesCobro) {
        this.listaComprobantesCobro = listaComprobantesCobro;
    }

    public List<Facturacion> getListaComprobantesCobroSelected() {
        return listaComprobantesCobroSelected;
    }

    public void setListaComprobantesCobroSelected(List<Facturacion> listaComprobantesCobroSelected) {
        this.listaComprobantesCobroSelected = listaComprobantesCobroSelected;
    }

    public List<Facturacionxpagar> getListaComprobantesPagoSelected() {
        return listaComprobantesPagoSelected;
    }

    public void setListaComprobantesPagoSelected(List<Facturacionxpagar> listaComprobantesPagoSelected) {
        this.listaComprobantesPagoSelected = listaComprobantesPagoSelected;
    }

    public List<Facturacion> getListaCuentasCobroFiltrada() {
        return listaCuentasCobroFiltrada;
    }

    public void setListaCuentasCobroFiltrada(List<Facturacion> listaCuentasCobroFiltrada) {
        this.listaCuentasCobroFiltrada = listaCuentasCobroFiltrada;
    }

    public List<Facturacionxpagar> getListaCuentasPagar() {
        return listaCuentasPagar;
    }

    public void setListaCuentasPagar(List<Facturacionxpagar> listaCuentasPagar) {
        this.listaCuentasPagar = listaCuentasPagar;
    }

    public List<Facturacionxpagar> getListaComprobantesPago() {
        return listaComprobantesPago;
    }

    public void setListaComprobantesPago(List<Facturacionxpagar> listaComprobantesPago) {
        this.listaComprobantesPago = listaComprobantesPago;
    }

    public List<Facturacionxpagar> getListaCuentasPagoFiltrada() {
        return listaCuentasPagoFiltrada;
    }

    public void setListaCuentasPagoFiltrada(List<Facturacionxpagar> listaCuentasPagoFiltrada) {
        this.listaCuentasPagoFiltrada = listaCuentasPagoFiltrada;
    }

    public List<Auxdetparam> getListaTiposDocumento() {
        return listaTiposDocumento;
    }

    public void setListaTiposDocumento(List<Auxdetparam> listaTiposDocumento) {
        this.listaTiposDocumento = listaTiposDocumento;
    }

    public List<Auxdetparam> getListaEstadosComprobante() {
        return listaEstadosComprobante;
    }

    public void setListaEstadosComprobante(List<Auxdetparam> listaEstadosComprobante) {
        this.listaEstadosComprobante = listaEstadosComprobante;
    }

    public List<Auxdetparam> getListaFormasdePago() {
        return listaFormasdePago;
    }

    public void setListaFormasdePago(List<Auxdetparam> listaFormasdePago) {
        this.listaFormasdePago = listaFormasdePago;
    }

    public Date getFechaDia() {
        return fechaDia;
    }

    public void setFechaDia(Date fechaDia) {
        this.fechaDia = fechaDia;
    }

    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(Date fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public Date getFechaCalculada() {
        return fechaCalculada;
    }

    public void setFechaCalculada(Date fechaCalculada) {
        this.fechaCalculada = fechaCalculada;
    }

    public int getDiasCredito() {
        return diasCredito;
    }

    public void setDiasCredito(int diasCredito) {
        this.diasCredito = diasCredito;
    }

    public boolean isMostrarDiasVencimiento() {
        return mostrarDiasVencimiento;
    }

    public void setMostrarDiasVencimiento(boolean mostrarDiasVencimiento) {
        this.mostrarDiasVencimiento = mostrarDiasVencimiento;
    }

    public boolean isOnMontoCobro() {
        return onMontoCobro;
    }

    public void setOnMontoCobro(boolean onMontoCobro) {
        this.onMontoCobro = onMontoCobro;
    }

    public boolean isOnMontoPago() {
        return onMontoPago;
    }

    public void setOnMontoPago(boolean onMontoPago) {
        this.onMontoPago = onMontoPago;
    }

    public boolean isShowBtnAddComprobanteCobrar() {
        return showBtnAddComprobanteCobrar;
    }

    public void setShowBtnAddComprobanteCobrar(boolean showBtnAddComprobanteCobrar) {
        this.showBtnAddComprobanteCobrar = showBtnAddComprobanteCobrar;
    }

    public boolean isShowBtnAddComprobantePagar() {
        return showBtnAddComprobantePagar;
    }

    public void setShowBtnAddComprobantePagar(boolean showBtnAddComprobantePagar) {
        this.showBtnAddComprobantePagar = showBtnAddComprobantePagar;
    }

    public Double getValorIVA() {
        return valorIVA;
    }

    public void setValorIVA(Double valorIVA) {
        this.valorIVA = valorIVA;
    }

    public Double getValorRetencion() {
        return valorRetencion;
    }

    public Double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(Double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public void setValorRetencion(Double valorRetencion) {
        this.valorRetencion = valorRetencion;
    }

    public DecimalFormat getDecimalFormat() {
        return decimalFormat;
    }

    public void setDecimalFormat(DecimalFormat decimalFormat) {
        this.decimalFormat = decimalFormat;
    }

    public List<Auxdetparam> getListaPorcentajeIVA() {
        return listaPorcentajeIVA;
    }

    public void setListaPorcentajeIVA(List<Auxdetparam> listaPorcentajeIVA) {
        this.listaPorcentajeIVA = listaPorcentajeIVA;
    }

    public Double getPorcentajeIva() {
        return porcentajeIva;
    }

    public void setPorcentajeIva(Double porcentajeIva) {
        this.porcentajeIva = porcentajeIva;
    }

}
