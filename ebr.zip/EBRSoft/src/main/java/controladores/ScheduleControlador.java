/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Auxdetparam;
import entidades.AuxdetparamPK;
import entidades.Cotizaciones;
import entidades.Eventos;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import modelo.AuxdetparamFacade;
import modelo.CotizacionesFacade;
import modelo.EventosFacade;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.DefaultScheduleEvent;
import org.primefaces.model.DefaultScheduleModel;
import org.primefaces.model.ScheduleEvent;
import org.primefaces.model.ScheduleModel;

/**
 *
 * @author cc90930
 */
@ManagedBean
@ViewScoped
public class ScheduleControlador {

    @EJB
    EventosFacade eventoFacade;

    @EJB
    CotizacionesFacade cotizacionFacade;

    @EJB
    AuxdetparamFacade auxDetParamFacade;

    private Eventos evento;
    private Auxdetparam colores;
    private AuxdetparamPK coloresPK;

    private Auxdetparam estadoEvento;
    private AuxdetparamPK estadoEventoPK;

    private Auxdetparam estadoCotizacion;
    private AuxdetparamPK estadoCotizacionPK;

    private ScheduleModel modeloEventos;
    private ScheduleEvent eventoCalendario;

    private List<Eventos> listaEventos;
    private List<Eventos> listaEventosNoCotizados;
    private List<Cotizaciones> listaCotizaciones;
    private List<Cotizaciones> listaCotizacionesEvento;

    private List<Auxdetparam> listaColores;
    private List<Auxdetparam> listaEstadosEvento;
    private List<Auxdetparam> listaEstadosCotizacion;

    private List<Eventos> listaEventosFiltrada;
    private List<Auxdetparam> listaColoresFiltrada;
    private List<Auxdetparam> listaEstadosEventoFiltrada;
    private List<Cotizaciones> listaCotizacionesFiltrada;

    private String estilo;
    private String colorEvento;
    private String colorCotizacion;

    private boolean draggableEvento;

    private Date fechaHoy;

    /**
     * Creates a new instance of ScheduleControlador
     */
    @PostConstruct
    public void init() {

        fechaHoy = new Date();

        evento = new Eventos();
        coloresPK = new AuxdetparamPK();
        colores = new Auxdetparam();
        colores.setAuxdetparamPK(coloresPK);

        estadoEventoPK = new AuxdetparamPK();
        estadoEvento = new Auxdetparam();
        estadoEvento.setAuxdetparamPK(estadoEventoPK);

        estadoCotizacionPK = new AuxdetparamPK();
        estadoCotizacion = new Auxdetparam();
        estadoCotizacion.setAuxdetparamPK(estadoCotizacionPK);

        listaEventos = new ArrayList<>();
        listaEventosNoCotizados = new ArrayList<>();
        listaCotizaciones = new ArrayList<>();

        listaColores = new ArrayList<>();
        listaEstadosEvento = new ArrayList<>();
        listaEstadosCotizacion = new ArrayList<>();
        listaCotizacionesEvento = new ArrayList<>();

        listaColores = this.cargarColores();
        listaEstadosEvento = this.cargarEstadosEvento();
        listaEstadosCotizacion = this.cargarEstadoCotizaciones();

        modeloEventos = new DefaultScheduleModel();
        eventoCalendario = new DefaultScheduleEvent();

        actualizarEventosVencidos();
        cargarEventos("T");

        this.estilo = "";
        this.colorEvento = "";
        this.draggableEvento = false;

    }

    public ScheduleControlador() {
    }

    public void generarCalendarioEventos() {
        try {
            for (Eventos eventos : listaEventos) {
                estilo = "ev" + this.obtenerColor(obtenerEstadoEvento(eventos.getEstado()));

                eventoCalendario = new DefaultScheduleEvent(eventos.getNombre(),
                        obtenerFecha(eventos.getFechainicio(), eventos.getHorainicio()),
                        obtenerFecha(eventos.getFechafin(), eventos.getHorafin()),
                        estilo);

                modeloEventos.addEvent(eventoCalendario);
            }
            this.listaEventos = new ArrayList<>();

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "No se Cargaron los Eventos en Calendario"));
        }
    }

    public void generarCalendarioMontaje() {
        try {
            for (Eventos eventos : listaEventos) {
                //estilo = "ev" + this.obtenerColor(obtenerEstadoEvento(eventos.getEstado()));
                eventoCalendario = new DefaultScheduleEvent(eventos.getNombre(),
                        obtenerFecha(eventos.getFechamontajeinicio(), eventos.getHoramontajeinicio()),
                        obtenerFecha(eventos.getFechamontajefin(), eventos.getHoramontajefin()),
                        estilo);

                modeloEventos.addEvent(eventoCalendario);
            }
            this.listaEventos = new ArrayList<>();

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "No se Cargaron los Eventos en Calendario"));
        }
    }

    public void cargarEventoProgramado(SelectEvent selectEvent) {
        this.eventoCalendario = (ScheduleEvent) selectEvent.getObject();

        this.evento = this.eventoFacade.buscarEventoporNombre(this.eventoCalendario.getTitle());
        cotizacionesPorEvento(this.evento.getIdEvento());

    }

    public void filtrarEventosEstado(SelectEvent estadoSeleccionado) {
        this.estadoEvento = (Auxdetparam) estadoSeleccionado.getObject();
        cargarEventos(Integer.toString(this.estadoEvento.getAuxdetparamPK().getCodigo()));
    }

    public void filtrarEventosEstadoU(SelectEvent estadoSeleccionado) {
        this.estadoEvento = (Auxdetparam) estadoSeleccionado.getObject();
        cargarEventos(Integer.toString(this.estadoEvento.getAuxdetparamPK().getCodigo()));
    }

    public void cargarEventos(String idFiltro) {
        modeloEventos = new DefaultScheduleModel();
        switch (idFiltro) {
            case "T":
                listaEventos = eventoFacade.findAll();
                generarCalendarioEventos();
                break;
            case "M":
                listaEventos = eventoFacade.findAll();
                generarCalendarioMontaje();
                break;
            default:
                listaEventos = eventoFacade.buscarEventosEstado(Integer.parseInt(idFiltro));
                generarCalendarioEventos();
                break;
        }
    }

    public List<Cotizaciones> cotizacionesPorEvento(int idEvento) {
        this.listaCotizacionesEvento = this.cotizacionFacade.cotizacionesPorEvento(idEvento);
        if (this.listaCotizacionesEvento.isEmpty()) {
            this.listaCotizacionesEvento = new ArrayList<>();
        }
        return this.listaCotizacionesEvento;
    }

    public List<Cotizaciones> cotizacionesEstado() {
        this.listaCotizaciones = this.cotizacionFacade.cotizacionesPorEstado(0);
        if (this.listaCotizaciones.isEmpty()) {
            this.listaCotizaciones = new ArrayList<>();
        }
        return this.listaCotizaciones;
    }

    public String obtenerNombreEvento(int idEvento) {
        return this.eventoFacade.obtenerNombreEvento(idEvento);
    }

    public List<Eventos> cargarEventosNoCotizados() {
        this.listaEventos = eventoFacade.buscarEventosEstado(0);

        for (Eventos evento : this.listaEventos) {
            if (this.cotizacionFacade.validarCotizacionesxEvento(evento.getIdEvento()) == 0) {
                this.listaEventosNoCotizados.add(evento);
            }

        }

        return this.listaEventosNoCotizados;
    }

    public void actualizarEventosVencidos() {
        long diff;
        int dias;
        this.listaEventos = eventoFacade.buscarEventosEstado(1);
        if (!this.listaEventos.isEmpty()) {
            for (Eventos evento : this.listaEventos) {
                diff=this.fechaHoy.getTime() - evento.getFechafin().getTime();
                dias=(int) (diff / (1000 * 60 * 60 * 24));
                    if (dias>0){
                        evento.setEstado(2);
                        eventoFacade.edit(evento);
                    }
            }
        }

    }

    public Date obtenerFecha(Date fecha, Date hora) {

        String fechaString;
        String horaString;
        String separarFecha[];
        String separarHora[];
        try {
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat hourFormat = new SimpleDateFormat("hh:mm:ss");

            fechaString = dateFormat.format(fecha);
            horaString = hourFormat.format(hora);
            separarFecha = fechaString.split("/");
            separarHora = horaString.split(":");
            Calendar calendario = Calendar.getInstance();
            //Seteamos Fecha
            calendario.set(Calendar.YEAR, Integer.parseInt(separarFecha[2]));
            calendario.set(Calendar.MONTH, Integer.parseInt(separarFecha[1]) - 1);
            calendario.set(Calendar.DAY_OF_MONTH, Integer.parseInt(separarFecha[0]));
            //Seteamos Hora
            calendario.set(Calendar.HOUR, Integer.parseInt(separarHora[0]));
            calendario.set(Calendar.MINUTE, Integer.parseInt(separarHora[1]));

            return calendario.getTime();
        } catch (Exception ex) {
            return null;
        }
    }

    public List<Auxdetparam> cargarColores() {
        listaColores = auxDetParamFacade.catalogoFiltrado(3); //Lista Colores

        return listaColores;
    }

    public List<Auxdetparam> cargarEstadosEvento() {
        listaEstadosEvento = auxDetParamFacade.catalogoFiltrado(1); //Lista Estados
        return listaEstadosEvento;
    }

    public List<Auxdetparam> cargarEstadoCotizaciones() {
        listaEstadosCotizacion = auxDetParamFacade.catalogoFiltrado(2);//Estados Cotizacion
        return listaEstadosCotizacion;
    }

    public int obtenerEstadoEvento(int idEstado) {
        int estadoE = 0;
        for (Auxdetparam estado : this.listaEstadosEvento) {
            if (estado.getAuxdetparamPK().getCodigo() == idEstado) {
                estadoE = Integer.parseInt(estado.getValaux());
                break;
            } else {
                estadoE = 0;
            }
        }
        return estadoE;
    }

    public String estadoEvento(int idEstado) {
        String estadoE = "";
        for (Auxdetparam estado : this.listaEstadosEvento) {
            if (estado.getAuxdetparamPK().getCodigo() == idEstado) {
                estadoE = estado.getAuxdetparamPK().getDescripcion();
                break;
            } else {
                estadoE = "No Definido";
            }
        }
        return estadoE;
    }

    public String obtenerEstadoCotizacion(int idEstado) {
        String estadoC = "";
        for (Auxdetparam estado : this.listaEstadosCotizacion) {
            if (estado.getAuxdetparamPK().getCodigo() == idEstado) {
                estadoC = estado.getAuxdetparamPK().getDescripcion();
                estadoCotizacion = estado;
                break;
            } else {
                estadoC = "No Definido";
            }
        }
        this.colorCotizacion = this.obtenerColor(Integer.parseInt(estadoCotizacion.getValaux()));
        return estadoC;
    }

    public String obtenerColor(int idColor) {
        String colorE = "";
        for (Auxdetparam color : this.listaColores) {
            if (color.getAuxdetparamPK().getCodigo() == idColor) {
                colorE = color.getValaux();
                break;
            } else {
                colorE = "";
            }
        }
        return colorE;
    }

    public EventosFacade getEventoFacade() {
        return eventoFacade;
    }

    public void setEventoFacade(EventosFacade eventoFacade) {
        this.eventoFacade = eventoFacade;
    }

    public Eventos getEvento() {
        return evento;
    }

    public void setEvento(Eventos evento) {
        this.evento = evento;
    }

    public List<Eventos> getListaEventos() {
        return listaEventos;
    }

    public void setListaEventos(List<Eventos> listaEventos) {
        this.listaEventos = listaEventos;
    }

    public ScheduleModel getModeloEventos() {
        return modeloEventos;
    }

    public void setModeloEventos(ScheduleModel modeloEventos) {
        this.modeloEventos = modeloEventos;
    }

    public ScheduleEvent getEventoCalendario() {
        return eventoCalendario;
    }

    public void setEventoCalendario(ScheduleEvent eventoCalendario) {
        this.eventoCalendario = eventoCalendario;
    }

    public List<Auxdetparam> getListaColores() {
        return listaColores;
    }

    public void setListaColores(List<Auxdetparam> listaColores) {
        this.listaColores = listaColores;
    }

    public List<Auxdetparam> getListaEstadosEvento() {
        return listaEstadosEvento;
    }

    public void setListaEstadosEvento(List<Auxdetparam> listaEstadosEvento) {
        this.listaEstadosEvento = listaEstadosEvento;
    }

    public Auxdetparam getColores() {
        return colores;
    }

    public void setColores(Auxdetparam colores) {
        this.colores = colores;
    }

    public String getEstilo() {
        return estilo;
    }

    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }

    public String getColorEvento() {
        return colorEvento;
    }

    public void setColorEvento(String colorEvento) {
        this.colorEvento = colorEvento;
    }

    public boolean isDraggableEvento() {
        return draggableEvento;
    }

    public void setDraggableEvento(boolean draggableEvento) {
        this.draggableEvento = draggableEvento;
    }

    public Auxdetparam getEstadoEvento() {
        return estadoEvento;
    }

    public void setEstadoEvento(Auxdetparam estadoEvento) {
        this.estadoEvento = estadoEvento;
    }

    public List<Cotizaciones> getListaCotizaciones() {
        return listaCotizaciones;
    }

    public void setListaCotizaciones(List<Cotizaciones> listaCotizaciones) {
        this.listaCotizaciones = listaCotizaciones;
    }

    public List<Eventos> getListaEventosFiltrada() {
        return listaEventosFiltrada;
    }

    public void setListaEventosFiltrada(List<Eventos> listaEventosFiltrada) {
        this.listaEventosFiltrada = listaEventosFiltrada;
    }

    public List<Auxdetparam> getListaColoresFiltrada() {
        return listaColoresFiltrada;
    }

    public void setListaColoresFiltrada(List<Auxdetparam> listaColoresFiltrada) {
        this.listaColoresFiltrada = listaColoresFiltrada;
    }

    public List<Auxdetparam> getListaEstadosEventoFiltrada() {
        return listaEstadosEventoFiltrada;
    }

    public void setListaEstadosEventoFiltrada(List<Auxdetparam> listaEstadosEventoFiltrada) {
        this.listaEstadosEventoFiltrada = listaEstadosEventoFiltrada;
    }

    public List<Cotizaciones> getListaCotizacionesFiltrada() {
        return listaCotizacionesFiltrada;
    }

    public void setListaCotizacionesFiltrada(List<Cotizaciones> listaCotizacionesFiltrada) {
        this.listaCotizacionesFiltrada = listaCotizacionesFiltrada;
    }

    public List<Auxdetparam> getListaEstadosCotizacion() {
        return listaEstadosCotizacion;
    }

    public void setListaEstadosCotizacion(List<Auxdetparam> listaEstadosCotizacion) {
        this.listaEstadosCotizacion = listaEstadosCotizacion;
    }

    public Auxdetparam getEstadoCotizacion() {
        return estadoCotizacion;
    }

    public void setEstadoCotizacion(Auxdetparam estadoCotizacion) {
        this.estadoCotizacion = estadoCotizacion;
    }

    public String getColorCotizacion() {
        return colorCotizacion;
    }

    public void setColorCotizacion(String colorCotizacion) {
        this.colorCotizacion = colorCotizacion;
    }

    public List<Cotizaciones> getListaCotizacionesEvento() {
        return listaCotizacionesEvento;
    }

    public void setListaCotizacionesEvento(List<Cotizaciones> listaCotizacionesEvento) {
        this.listaCotizacionesEvento = listaCotizacionesEvento;
    }

    public List<Eventos> getListaEventosNoCotizados() {
        return listaEventosNoCotizados;
    }

    public void setListaEventosNoCotizados(List<Eventos> listaEventosNoCotizados) {
        this.listaEventosNoCotizados = listaEventosNoCotizados;
    }

    public Date getFechaHoy() {
        return fechaHoy;
    }

    public void setFechaHoy(Date fechaHoy) {
        this.fechaHoy = fechaHoy;
    }

}
