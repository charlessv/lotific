/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Menu;
import entidades.Menurol;
import entidades.Roles;
import entidades.Usuariorol;
import entidades.Usuarios;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpSession;
import modelo.MenuFacade;
import modelo.MenurolFacade;
import modelo.RolesFacade;
import modelo.UsuariorolFacade;
import modelo.UsuariosFacade;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DualListModel;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;
import utilities.Encriptar;
import utilities.PasswordString;

/**
 *
 * @author Carlos
 */
@ManagedBean
@SessionScoped
public class SeguridadControlador {

    @EJB
    UsuariosFacade usuarioFacade;
    @EJB
    RolesFacade rolFacade;

    @EJB
    UsuariorolFacade usuariorolFacade;
    @EJB
    MenuFacade menuFacade;
    @EJB
    MenurolFacade menuRolFacade;

    private Usuarios usuario;
    private Roles rol;
    private Usuariorol userRol;
    private Menu menu;
    private Menurol menuRol;

    private List<Usuarios> listaUsuarios;
    private List<Roles> listaRoles;
    private List<Menu> listaMenu;
    private List<Menu> listaMenuSelected;
    private List<Menurol> listaMenusRol;
    private List<Usuariorol> listaUsrRoles;

    private List<Usuarios> listaUsuariosFiltrada;
    private List<Roles> listaRolesFiltrada;

    private DualListModel<Menu> listaSelectMenu;
    private MenuModel modeloMenu;
    DefaultMenuItem item;
    DefaultSubMenu subMenu;

    private String usuarioActivo;
    private String password;
    private String nuevoPassword;
    private String repitaPassword;

    private Date fechaDia;

    private int codigoRol;
    private String theme;

    boolean menuVisible;
    boolean showLogin;
    boolean showEditPass;
    
    HttpSession miSession;

    /**
     * Creates a new instance of SeguridadControlador
     */
    @PostConstruct
    public void init() {

        usuario = new Usuarios();
        rol = new Roles();
        userRol = new Usuariorol();
        menuRol = new Menurol();
        fechaDia = new Date();
        rol.setIdRol(rolFacade.calcularId());
        rol.setRol("");
        usuario.setIdUsuario(usuarioFacade.calcularId());
        usuario.setEstado(Boolean.TRUE);

        listaUsuarios = new ArrayList<>();
        listaRoles = new ArrayList<>();
        listaUsrRoles = new ArrayList<>();
        listaMenu = new ArrayList<>();
        listaMenusRol = new ArrayList<>();
        listaMenuSelected = new ArrayList<>();

        listaUsuarios = cargarUsuarios();
        listaRoles = cargarRoles();
        listaMenu = cargarMenu();

        this.listaSelectMenu = new DualListModel<>(listaMenu, listaMenuSelected);

        this.menuVisible = false;//Valida si Menu se Muestra
        this.showLogin = true;
        this.showEditPass = false;
        this.theme = "bootstrap";

    }

    public SeguridadControlador() {
        miSession = (HttpSession) 
                FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        miSession.setMaxInactiveInterval(5000);

    }

    public String login() {
        try {
            usuario = usuarioFacade.getUsuarioByLogin(this.usuarioActivo);
            if (usuario != null) {
                if (usuario.getPassword().equals(Encriptar.sha512(this.password))) {
                    if (usuario.getValidapass()) {
                        RequestContext.getCurrentInstance().execute("PF('dlgEditarPassword').show()");
                        return null;
                    }

                    if (usuario.getEstado()) {
                        HttpSession httpSession = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
                        obtenerRolByIdUsuario(usuario);
                        httpSession.setAttribute("usuarioActivo", this.usuarioActivo);
                        this.listaMenuSelected = menuFacade.obtenerMenusAsociadosByRol(rol.getIdRol());
                        httpSession.setAttribute("urlValidas", this.listaMenuSelected);
                        generaMenuRol();
                        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto:", "Acceso Permitido"));
                        this.usuario = new Usuarios();
                        usuario.setIdUsuario(usuarioFacade.calcularId());
                        usuario.setEstado(Boolean.TRUE);
                        RequestContext.getCurrentInstance().update(":frmAddUsuario");
                        return "/schedule" + "?faces-redirect=true";
                    } else {
                        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "AVISO:", "Usuario Inactivo"));
                    }
                }
            }

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error de acceso:", "Usuario o contraseña incorrecto"));
            this.usuario = null;
            this.usuarioActivo = null;
            this.password = null;
            return "/index";
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error fatal:", "Por favor contacte con su administrador " + ex.getMessage()));

            return null;
        }

    }

    public String cerrarSesion() {
        this.usuarioActivo = null;
        this.password = null;

        HttpSession httpSession = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        httpSession.invalidate();
        modeloMenu = new DefaultMenuModel();
        return "/index" + "?faces-redirect=true";
    }

    public List<Usuarios> cargarUsuarios() {
        this.listaUsuarios = usuarioFacade.findAll();
        return this.listaUsuarios;
    }

    public void crearUsuario() throws Exception {
        try {

            if (this.rol.getIdRol() == 0) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error :", "Debe Seleccionar un Rol"));
                return;

            }

            if (!this.usuario.getPassword().equals(this.repitaPassword)) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Password no Coincide"));
                return;
            }

            this.usuario.setLogin(this.usuario.getLogin().toUpperCase());

            if (usuarioFacade.getUsuarioByLogin(this.usuario.getLogin()) != null) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Existe Registrado Usuario con Login Seleccionado"));
            } else {
                this.usuario.setPassword(Encriptar.sha512(this.usuario.getPassword()));
                this.usuario.setValidapass(Boolean.TRUE);
                usuarioFacade.edit(usuario);
                this.asignarRol();//Crea Rol Nuevo Usuario
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                        "Correcto :", "Usuario Creado Exitosamente"));

                this.cargarUsuarios();
                this.usuario = new Usuarios();
                this.usuario.setIdUsuario(usuarioFacade.calcularId());

                RequestContext.getCurrentInstance().update("frmSeguridad:tblUsuarios");
                RequestContext.getCurrentInstance().update("frmAddUsuario");
                RequestContext.getCurrentInstance().execute("PF('dlgAddUsuario').hide()");

            }

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Crear Usuario " + ex.getMessage()));
        }

    }

    public void actualizarUsuario() {
        try {
            if (usuarioFacade.getLoginByIdUsuario(usuario.getLogin(), usuario.getIdUsuario()) != null) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Existe Registrado Usuario con Login Seleccionado"));
            } else {
                this.userRol.setIdRol(rol.getIdRol());
                this.userRol.setIdUsuario(usuario.getIdUsuario());

                usuarioFacade.edit(usuario);
                if (rol.getIdRol() > 0) {
                    usuariorolFacade.edit(userRol);
                }

                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                        "Correcto :", "Usuario Actualizado "));
                this.cargarUsuarios();
                RequestContext.getCurrentInstance().update("frmSeguridad:tblUsuarios");
                RequestContext.getCurrentInstance().update("frmAddUsuario:pnlAddUsuario");
                RequestContext.getCurrentInstance().execute("PF('dlgEditUsuario').hide()");
                this.usuario = new Usuarios();
                this.userRol = new Usuariorol();
                usuario.setIdUsuario(usuarioFacade.calcularId());
            }
        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Actualizar Usuario " + ex.getMessage()));

        }
    }

    public String actualizarPassword() {
        try {
            if (!this.usuario.getPassword().equals(Encriptar.sha512(this.password))) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error:", "Usuario o contraseña incorrecto"));
                return null;
            } else {
                if (!this.nuevoPassword.equals(this.repitaPassword)) {
                    FacesContext.getCurrentInstance().
                            addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Nuevo Password no Coincide"));
                    return null;
                }
            }

            this.usuario.setLogin(this.usuario.getLogin().toUpperCase());

            this.usuario.setPassword(Encriptar.sha512(this.nuevoPassword));
            this.usuario.setValidapass(Boolean.FALSE);

            usuarioFacade.edit(usuario);
            RequestContext.getCurrentInstance().
                    showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Cambio de Password Exitoso"));

            this.password = this.nuevoPassword;
            Thread.sleep(2000);
            return login();

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Operacion no Realizada"));
            return null;
        }

    }

    public void resetPassword() {
        this.nuevoPassword = PasswordString.aleatorio();
        RequestContext.getCurrentInstance().update("frmSeguridad:passwordTemporal");
        
        this.usuario.setPassword(Encriptar.sha512(this.nuevoPassword));
        this.usuario.setValidapass(Boolean.TRUE);
        try{
            usuarioFacade.edit(usuario);
        }catch(Exception ex){
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error al hacer Reset del password",null));
            
        }
        

    }

    public void eliminarUsuario(Usuarios users) {
        try {

            this.codigoRol = usuariorolFacade.getRolByIdUsuario(users.getIdUsuario());
            this.userRol.setIdRol(codigoRol);
            this.userRol.setIdUsuario(users.getIdUsuario());

            usuariorolFacade.remove(userRol);
            usuarioFacade.remove(users);

            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                    "Correcto :", "Usuario Eliminado"));

            this.cargarUsuarios();
            RequestContext.getCurrentInstance().update("frmSeguridad:tblUsuarios");

            this.userRol = new Usuariorol();
            this.codigoRol = 0;

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Eliminar Usuario" + ex.getMessage()));
        }

    }

    public void asignarRol() {
        try {
            userRol.setIdRol(rol.getIdRol());
            userRol.setIdUsuario(usuario.getIdUsuario());

            this.usuariorolFacade.create(userRol);

            this.userRol = new Usuariorol();

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Asignar Rol" + ex.getMessage()));
        }
    }

    public String getRolByIdUsuario(Usuarios users) {
        String rolSeleccionado = "";

        this.codigoRol = this.usuariorolFacade.getRolByIdUsuario(users.getIdUsuario());
        if (this.codigoRol > 0) {
            this.rol = rolFacade.find(this.codigoRol);

            if (this.rol != null) {
                rolSeleccionado = this.rol.getRol();

            } else {
                rolSeleccionado = "No Asignado";
            }
        } else {
            rolSeleccionado = "No Asignado";
        }
        this.rol = new Roles();
        this.rol.setIdRol(this.rolFacade.calcularId());
        this.codigoRol = 0;
        return rolSeleccionado;
    }

    public void obtenerRolByIdUsuario(Usuarios user) {
        this.codigoRol = this.usuariorolFacade.getRolByIdUsuario(user.getIdUsuario());
        if (this.codigoRol > 0) {
            this.rol = rolFacade.find(this.codigoRol);
        }
    }

    public List<Roles> cargarRoles() {
        this.listaRoles = rolFacade.findAll();
        return this.listaRoles;
    }

    public void crearRol() {
        try {

            rolFacade.edit(rol);
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                    "Correcto :", "Rol Creado Exitosamente"));

            rol = new Roles();
            rol.setIdRol(rolFacade.calcularId());
            this.cargarRoles();
            RequestContext.getCurrentInstance().update("frmAddUsuario");
            RequestContext.getCurrentInstance().update("frmAddRol");
            RequestContext.getCurrentInstance().update("frmRoles");
            RequestContext.getCurrentInstance().execute("PF('dlgAddRol').hide()");

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Crear Rol" + ex.getMessage()));
        }

    }

    public void actualizarRol() {
        try {

            rolFacade.edit(rol);
            this.actualizarMenuRol();
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                    "Correcto :", "Rol Actualizado Exitosamente"));

            rol = new Roles();
            rol.setIdRol(rolFacade.calcularId());
            this.cargarRoles();
            RequestContext.getCurrentInstance().update("frmAddUsuario");
            RequestContext.getCurrentInstance().update("frmRoles");
            RequestContext.getCurrentInstance().update("frmEditRol");
            RequestContext.getCurrentInstance().execute("PF('dlgEditRol').hide()");

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Actualizar Rol" + ex.getMessage()));
        }

    }

    public void eliminarRol(Roles roles) {
        try {
            this.listaUsrRoles = this.usuariorolFacade.getUsuariosByIdRol(roles.getIdRol());

            for (Usuariorol ur : this.listaUsrRoles) {
                usuariorolFacade.remove(ur);
            }
            this.rol = roles;
            eliminarMenuRol();
            rolFacade.remove(roles);

            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                    "Correcto :", "Rol Eliminado Correctamente"));

            this.cargarRoles();
            RequestContext.getCurrentInstance().update("frmSeguridad:tblUsuarios");
            RequestContext.getCurrentInstance().update("frmRoles:tblRoles");
            RequestContext.getCurrentInstance().update("frmAddUsuario");

            this.userRol = new Usuariorol();
            this.codigoRol = 0;

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Eliminar Rol" + ex.getMessage()));
        }

    }

    public List<SelectItem> listarRoles() {
        List<SelectItem> listadoRoles = new ArrayList<>();

        this.listaRoles = rolFacade.findAll();

        for (Roles roles : this.listaRoles) {
            listadoRoles.add(new SelectItem(roles.getIdRol(), roles.getRol()));
        }

        if (listadoRoles.isEmpty()) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
                                    "Error :", "Es Necesario Ingresar Roles para Crear Usuarios"));
            return null;
        }

        return listadoRoles;
    }

    public List<Menu> cargarMenu() {
        this.listaMenu = menuFacade.findAll();

        return this.listaMenu;
    }

    public void actualizarMenuRol() {
        try {
            eliminarMenuRol();
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
                                    "Status :", "Asociando Menus Asociados a Rol"));
            this.listaMenuSelected = this.listaSelectMenu.getTarget();
            for (Menu men : this.listaMenuSelected) {

                menuRol.setIdAsociacion(0);
                menuRol.setIdRol(rol.getIdRol());
                menuRol.setIdMenu(men.getIdMenu());
                menuRolFacade.edit(menuRol);
            }
        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al asignar Menus a Rol" + ex.getMessage()));
        }
    }

    public void eliminarMenuRol() {
        this.listaMenusRol = menuRolFacade.menuAsociadoByRol(rol.getIdRol());
        FacesContext.getCurrentInstance()
                .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
                                "Status :", "Eliminando Menus Asociados a Rol"));
        for (Menurol menrol : this.listaMenusRol) {
            menuRolFacade.remove(menrol);
        }

    }

    public void obtenerPickList(Roles roles) {
        this.listaMenu = new ArrayList<>();
        this.listaMenuSelected = new ArrayList<>();
        this.listaMenu = menuFacade.obtenerMenusNoAsociadosByRol(roles.getIdRol());
        this.listaMenuSelected = menuFacade.obtenerMenusAsociadosByRol(roles.getIdRol());
        this.listaSelectMenu = new DualListModel<>(this.listaMenu, this.listaMenuSelected);

        RequestContext.getCurrentInstance().update(":frmEditRol:pnlEditRol");

    }

    public void generaMenuRol() {

        modeloMenu = new DefaultMenuModel();
        
        

        item = new DefaultMenuItem("Inicio");
        item.setOutcome("/schedule.xhtml");
        item.setIcon("ui-icon-home");
        modeloMenu.addElement(item);
        

        for (Menu men : this.listaMenuSelected) {

            item = new DefaultMenuItem(men.getDescripcion());
            item.setOutcome("/" + men.getUrl());
            item.setIcon("ui-icon-circle-check");

            modeloMenu.addElement(item);
            

        }

        this.menuVisible = true;

        // this.listaMenuSelected = new ArrayList<>();
    }
    
    public String userSessionHandler(int indicador){
        try{
           if(indicador==0){ //Session Inactiva
              RequestContext.getCurrentInstance().
                      showMessageInDialog(new FacesMessage(FacesMessage.
                              SEVERITY_INFO,"Session Inactiva",null));
             return this.cerrarSesion();
              
           }else{
             FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.
                              SEVERITY_INFO,"Session activa",null));
             return "";
           }
            
        }catch(Exception ex){
            return "";
        }
        
    }

    public Usuarios getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuarios usuario) {
        this.usuario = usuario;
    }

    public Roles getRol() {
        return rol;
    }

    public void setRol(Roles rol) {
        this.rol = rol;
    }

    public Usuariorol getUserRol() {
        return userRol;
    }

    public void setUserRol(Usuariorol userRol) {
        this.userRol = userRol;
    }

    public List<Usuarios> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(List<Usuarios> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    public List<Roles> getListaRoles() {
        return listaRoles;
    }

    public void setListaRoles(List<Roles> listaRoles) {
        this.listaRoles = listaRoles;
    }

    public List<Usuarios> getListaUsuariosFiltrada() {
        return listaUsuariosFiltrada;
    }

    public void setListaUsuariosFiltrada(List<Usuarios> listaUsuariosFiltrada) {
        this.listaUsuariosFiltrada = listaUsuariosFiltrada;
    }

    public List<Roles> getListaRolesFiltrada() {
        return listaRolesFiltrada;
    }

    public void setListaRolesFiltrada(List<Roles> listaRolesFiltrada) {
        this.listaRolesFiltrada = listaRolesFiltrada;
    }

    public String getUsuarioActivo() {
        return usuarioActivo;
    }

    public void setUsuarioActivo(String usuarioActivo) {
        this.usuarioActivo = usuarioActivo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRepitaPassword() {
        return repitaPassword;
    }

    public void setRepitaPassword(String repitaPassword) {
        this.repitaPassword = repitaPassword;
    }

    public String getNuevoPassword() {
        return nuevoPassword;
    }

    public void setNuevoPassword(String nuevoPassword) {
        this.nuevoPassword = nuevoPassword;
    }

    public Date getFechaDia() {
        return fechaDia;
    }

    public void setFechaDia(Date fechaDia) {
        this.fechaDia = fechaDia;
    }

    public int getCodigoRol() {
        return codigoRol;
    }

    public void setCodigoRol(int codigoRol) {
        this.codigoRol = codigoRol;
    }

    public List<Menu> getListaMenu() {
        return listaMenu;
    }

    public void setListaMenu(List<Menu> listaMenu) {
        this.listaMenu = listaMenu;
    }

    public List<Menu> getListaMenuSelected() {
        return listaMenuSelected;
    }

    public void setListaMenuSelected(List<Menu> listaMenuSelected) {
        this.listaMenuSelected = listaMenuSelected;
    }

    public DualListModel<Menu> getListaSelectMenu() {
        return listaSelectMenu;
    }

    public void setListaSelectMenu(DualListModel<Menu> listaSelectMenu) {
        this.listaSelectMenu = listaSelectMenu;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public Menurol getMenuRol() {
        return menuRol;
    }

    public void setMenuRol(Menurol menuRol) {
        this.menuRol = menuRol;
    }

    public MenuModel getModeloMenu() {
        return modeloMenu;
    }

    public void setModeloMenu(MenuModel modeloMenu) {
        this.modeloMenu = modeloMenu;
    }

    public boolean isMenuVisible() {
        return menuVisible;
    }

    public void setMenuVisible(boolean menuVisible) {
        this.menuVisible = menuVisible;
    }

    public List<Menurol> getListaMenusRol() {
        return listaMenusRol;
    }

    public void setListaMenusRol(List<Menurol> listaMenusRol) {
        this.listaMenusRol = listaMenusRol;
    }

    public List<Usuariorol> getListaUsrRoles() {
        return listaUsrRoles;
    }

    public void setListaUsrRoles(List<Usuariorol> listaUsrRoles) {
        this.listaUsrRoles = listaUsrRoles;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public boolean isShowEditPass() {
        return showEditPass;
    }

    public void setShowEditPass(boolean showEditPass) {
        this.showEditPass = showEditPass;
    }

    public boolean isShowLogin() {
        return showLogin;
    }

    public void setShowLogin(boolean showLogin) {
        this.showLogin = showLogin;
    }

    public HttpSession getMiSession() {
        return miSession;
    }

    public void setMiSession(HttpSession miSession) {
        this.miSession = miSession;
    }
    
    

}
