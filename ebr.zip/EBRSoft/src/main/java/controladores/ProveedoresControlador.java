/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Proveedores;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import modelo.ProveedoresFacade;

/**
 *
 * @author Carlos
 */
@Named(value = "proveedoresControlador")
@SessionScoped
public class ProveedoresControlador implements Serializable {

    private Proveedores proveedor;
    private List<Proveedores> listaProveedores;
    private List<Proveedores> listaProveedoresFiltrada;
    private Date fechaHoy;

    @EJB
    ProveedoresFacade proveedorFacade;

    /**
     * Creates a new instance of ProveedoresControlador
     */
    public ProveedoresControlador() {
    }

    @PostConstruct
    public void init() {
        fechaHoy = new Date();
        proveedor = new Proveedores();
        proveedor.setFechacreacion(fechaHoy);
        proveedor.setContacto("");
        proveedor.setEmail("");
        proveedor.setNit("");
        proveedor.setNrc("");
        proveedor.setRazonsocial("");

        this.listaProveedores = new ArrayList<>();
        this.listaProveedores=cargarProveedores();

    }
    
    public List<Proveedores> cargarProveedores(){
        this.listaProveedores=proveedorFacade.findAll();
        
        return this.listaProveedores;
    }

    public Proveedores getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedores proveedor) {
        this.proveedor = proveedor;
    }

    public List<Proveedores> getListaProveedores() {
        return listaProveedores;
    }

    public void setListaProveedores(List<Proveedores> listaProveedores) {
        this.listaProveedores = listaProveedores;
    }

    public List<Proveedores> getListaProveedoresFiltrada() {
        return listaProveedoresFiltrada;
    }

    public void setListaProveedoresFiltrada(List<Proveedores> listaProveedoresFiltrada) {
        this.listaProveedoresFiltrada = listaProveedoresFiltrada;
    }

    public Date getFechaHoy() {
        return fechaHoy;
    }

    public void setFechaHoy(Date fechaHoy) {
        this.fechaHoy = fechaHoy;
    }

}
