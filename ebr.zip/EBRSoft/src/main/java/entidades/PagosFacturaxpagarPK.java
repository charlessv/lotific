/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Carlos
 */
@Embeddable
public class PagosFacturaxpagarPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "idpago")
    private int idpago;
    @Basic(optional = false)
    @NotNull
    @Column(name = "tipodocumento")
    private int tipodocumento;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "idfactura")
    private String idfactura;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idproveedor")
    private int idproveedor;

    public PagosFacturaxpagarPK() {
    }

    public PagosFacturaxpagarPK(int idpago, int tipodocumento, String idfactura, int idproveedor) {
        this.idpago = idpago;
        this.tipodocumento = tipodocumento;
        this.idfactura = idfactura;
        this.idproveedor = idproveedor;
    }

    public int getIdpago() {
        return idpago;
    }

    public void setIdpago(int idpago) {
        this.idpago = idpago;
    }

    public int getTipodocumento() {
        return tipodocumento;
    }

    public void setTipodocumento(int tipodocumento) {
        this.tipodocumento = tipodocumento;
    }

    public String getIdfactura() {
        return idfactura;
    }

    public void setIdfactura(String idfactura) {
        this.idfactura = idfactura;
    }

    public int getIdproveedor() {
        return idproveedor;
    }

    public void setIdproveedor(int idproveedor) {
        this.idproveedor = idproveedor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idpago;
        hash += (int) tipodocumento;
        hash += (idfactura != null ? idfactura.hashCode() : 0);
        hash += (int) idproveedor;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PagosFacturaxpagarPK)) {
            return false;
        }
        PagosFacturaxpagarPK other = (PagosFacturaxpagarPK) object;
        if (this.idpago != other.idpago) {
            return false;
        }
        if (this.tipodocumento != other.tipodocumento) {
            return false;
        }
        if ((this.idfactura == null && other.idfactura != null) || (this.idfactura != null && !this.idfactura.equals(other.idfactura))) {
            return false;
        }
        if (this.idproveedor != other.idproveedor) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.PagosFacturaxpagarPK[ idpago=" + idpago + ", tipodocumento=" + tipodocumento + ", idfactura=" + idfactura + ", idproveedor=" + idproveedor + " ]";
    }
    
}
