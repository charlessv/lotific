/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Carlos
 */
@Entity
@Table(name = "menurol")
@NamedQueries({
    @NamedQuery(name = "Menurol.findAll", query = "SELECT m FROM Menurol m"),
    @NamedQuery(name = "Menurol.findByIdAsociacion", query = "SELECT m FROM Menurol m WHERE m.idAsociacion = :idAsociacion"),
    @NamedQuery(name = "Menurol.findByIdMenu", query = "SELECT m FROM Menurol m WHERE m.idMenu = :idMenu"),
    @NamedQuery(name = "Menurol.findByIdRol", query = "SELECT m FROM Menurol m WHERE m.idRol = :idRol")})
public class Menurol implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_asociacion")
    private Integer idAsociacion;
    @Column(name = "id_menu")
    private Integer idMenu;
    @Column(name = "id_rol")
    private Integer idRol;

    public Menurol() {
    }

    public Menurol(Integer idAsociacion) {
        this.idAsociacion = idAsociacion;
    }

    public Integer getIdAsociacion() {
        return idAsociacion;
    }

    public void setIdAsociacion(Integer idAsociacion) {
        this.idAsociacion = idAsociacion;
    }

    public Integer getIdMenu() {
        return idMenu;
    }

    public void setIdMenu(Integer idMenu) {
        this.idMenu = idMenu;
    }

    public Integer getIdRol() {
        return idRol;
    }

    public void setIdRol(Integer idRol) {
        this.idRol = idRol;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAsociacion != null ? idAsociacion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Menurol)) {
            return false;
        }
        Menurol other = (Menurol) object;
        if ((this.idAsociacion == null && other.idAsociacion != null) || (this.idAsociacion != null && !this.idAsociacion.equals(other.idAsociacion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Menurol[ idAsociacion=" + idAsociacion + " ]";
    }
    
}
