/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.PrimaryKeyJoinColumns;
import javax.persistence.Table;

/**
 *
 * @author Carlos
 */
@Entity
@Table(name = "detallecotizacion")
@NamedQueries({
    @NamedQuery(name = "Detallecotizacion.findAll", query = "SELECT d FROM Detallecotizacion d"),
    @NamedQuery(name = "Detallecotizacion.findByCantidad", query = "SELECT d FROM Detallecotizacion d WHERE d.cantidad = :cantidad"),
    @NamedQuery(name = "Detallecotizacion.findByPrecio", query = "SELECT d FROM Detallecotizacion d WHERE d.precio = :precio"),
    @NamedQuery(name = "Detallecotizacion.findByIdDetallecotizacion", query = "SELECT d FROM Detallecotizacion d WHERE d.detallecotizacionPK.idDetallecotizacion = :idDetallecotizacion"),
    @NamedQuery(name = "Detallecotizacion.findByIdCotizacion", query = "SELECT d FROM Detallecotizacion d WHERE d.detallecotizacionPK.idCotizacion = :idCotizacion")})
public class Detallecotizacion implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected DetallecotizacionPK detallecotizacionPK;
    @Column(name = "cantidad")
    private Integer cantidad;
    @Column(name = "precio")
    private Integer precio;
    @JoinColumn(name = "id_categoria", referencedColumnName = "id_categoria",insertable = false, updatable =false)
    @ManyToOne
    private Categorias idCategoria;
    @JoinColumn(name = "id_cotizacion", referencedColumnName = "id_cotizacion",updatable = false,insertable = false)
    @ManyToOne(optional = false)
    private Cotizaciones cotizaciones;
    @JoinColumns({
        @JoinColumn(name = "id_producto", referencedColumnName = "id_producto"),
        @JoinColumn(name = "id_categoria", referencedColumnName = "id_categoria")})
    @ManyToOne
    private Productos productos;
    
    
    public Detallecotizacion() {
    }

    public Detallecotizacion(DetallecotizacionPK detallecotizacionPK) {
        this.detallecotizacionPK = detallecotizacionPK;
    }

    public Detallecotizacion(int idDetallecotizacion, int idCotizacion) {
        this.detallecotizacionPK = new DetallecotizacionPK(idDetallecotizacion, idCotizacion);
    }
    
    public Detallecotizacion(DetallecotizacionPK detallecotizacionPK,Productos productos,int precio,int cantidad,Categorias categorias){
        this.detallecotizacionPK=detallecotizacionPK;
        this.productos=productos;
        this.precio=precio;
        this.cantidad=cantidad;
        this.idCategoria=categorias;
    

    }

    public DetallecotizacionPK getDetallecotizacionPK() {
        return detallecotizacionPK;
    }

    public void setDetallecotizacionPK(DetallecotizacionPK detallecotizacionPK) {
        this.detallecotizacionPK = detallecotizacionPK;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Integer getPrecio() {
        return precio;
    }

    public void setPrecio(Integer precio) {
        this.precio = precio;
    }

    public Categorias getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Categorias idCategoria) {
        this.idCategoria = idCategoria;
    }

    public Cotizaciones getCotizaciones() {
        return cotizaciones;
    }

    public void setCotizaciones(Cotizaciones cotizaciones) {
        this.cotizaciones = cotizaciones;
    }

    public Productos getProductos() {
        return productos;
    }

    public void setProductos(Productos productos) {
        this.productos = productos;
    }

    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (detallecotizacionPK != null ? detallecotizacionPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Detallecotizacion)) {
            return false;
        }
        Detallecotizacion other = (Detallecotizacion) object;
        if ((this.detallecotizacionPK == null && other.detallecotizacionPK != null) || (this.detallecotizacionPK != null && !this.detallecotizacionPK.equals(other.detallecotizacionPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Detallecotizacion[ detallecotizacionPK=" + detallecotizacionPK + " ]";
    }
}
