/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

/**
 *
 * @author Carlos
 */
@Entity
@Table(name = "pagos_facturaxpagar")
@NamedQueries({
    @NamedQuery(name = "PagosFacturaxpagar.findAll", query = "SELECT p FROM PagosFacturaxpagar p"),
    @NamedQuery(name = "PagosFacturaxpagar.findByIdpago", query = "SELECT p FROM PagosFacturaxpagar p WHERE p.pagosFacturaxpagarPK.idpago = :idpago"),
    @NamedQuery(name = "PagosFacturaxpagar.findByTipodocumento", query = "SELECT p FROM PagosFacturaxpagar p WHERE p.pagosFacturaxpagarPK.tipodocumento = :tipodocumento"),
    @NamedQuery(name = "PagosFacturaxpagar.findByIdfactura", query = "SELECT p FROM PagosFacturaxpagar p WHERE p.pagosFacturaxpagarPK.idfactura = :idfactura"),
    @NamedQuery(name = "PagosFacturaxpagar.findByTipopago", query = "SELECT p FROM PagosFacturaxpagar p WHERE p.tipopago = :tipopago"),
    @NamedQuery(name = "PagosFacturaxpagar.findByIdproveedor", query = "SELECT p FROM PagosFacturaxpagar p WHERE p.pagosFacturaxpagarPK.idproveedor = :idproveedor"),
    @NamedQuery(name = "PagosFacturaxpagar.findByReferencia", query = "SELECT p FROM PagosFacturaxpagar p WHERE p.referencia = :referencia"),
    @NamedQuery(name = "PagosFacturaxpagar.findByMonto", query = "SELECT p FROM PagosFacturaxpagar p WHERE p.monto = :monto"),
    @NamedQuery(name = "PagosFacturaxpagar.findByFechapago", query = "SELECT p FROM PagosFacturaxpagar p WHERE p.fechapago = :fechapago"),
    @NamedQuery(name = "PagosFacturaxpagar.findByFecharegistropago", query = "SELECT p FROM PagosFacturaxpagar p WHERE p.fecharegistropago = :fecharegistropago")})
public class PagosFacturaxpagar implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PagosFacturaxpagarPK pagosFacturaxpagarPK;
    @Column(name = "tipopago")
    private Integer tipopago;
    @Size(max = 255)
    @Column(name = "referencia")
    private String referencia;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "monto")
    private Double monto;
    @Column(name = "fechapago")
    @Temporal(TemporalType.DATE)
    private Date fechapago;
    @Column(name = "fecharegistropago")
    @Temporal(TemporalType.DATE)
    private Date fecharegistropago;
    @JoinColumn(name = "idproveedor", referencedColumnName = "idproveedor", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Proveedores proveedores;

    public PagosFacturaxpagar() {
    }

    public PagosFacturaxpagar(PagosFacturaxpagarPK pagosFacturaxpagarPK) {
        this.pagosFacturaxpagarPK = pagosFacturaxpagarPK;
    }

    public PagosFacturaxpagar(int idpago, int tipodocumento, String idfactura, int idproveedor) {
        this.pagosFacturaxpagarPK = new PagosFacturaxpagarPK(idpago, tipodocumento, idfactura, idproveedor);
    }

    public PagosFacturaxpagarPK getPagosFacturaxpagarPK() {
        return pagosFacturaxpagarPK;
    }

    public void setPagosFacturaxpagarPK(PagosFacturaxpagarPK pagosFacturaxpagarPK) {
        this.pagosFacturaxpagarPK = pagosFacturaxpagarPK;
    }

    public Integer getTipopago() {
        return tipopago;
    }

    public void setTipopago(Integer tipopago) {
        this.tipopago = tipopago;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }

    public Date getFechapago() {
        return fechapago;
    }

    public void setFechapago(Date fechapago) {
        this.fechapago = fechapago;
    }

    public Date getFecharegistropago() {
        return fecharegistropago;
    }

    public void setFecharegistropago(Date fecharegistropago) {
        this.fecharegistropago = fecharegistropago;
    }

    public Proveedores getProveedores() {
        return proveedores;
    }

    public void setProveedores(Proveedores proveedores) {
        this.proveedores = proveedores;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pagosFacturaxpagarPK != null ? pagosFacturaxpagarPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PagosFacturaxpagar)) {
            return false;
        }
        PagosFacturaxpagar other = (PagosFacturaxpagar) object;
        if ((this.pagosFacturaxpagarPK == null && other.pagosFacturaxpagarPK != null) || (this.pagosFacturaxpagarPK != null && !this.pagosFacturaxpagarPK.equals(other.pagosFacturaxpagarPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.PagosFacturaxpagar[ pagosFacturaxpagarPK=" + pagosFacturaxpagarPK + " ]";
    }
    
}
