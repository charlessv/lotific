/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Carlos
 */
@Entity
@Table(name = "facturacionxpagar")
@NamedQueries({
    @NamedQuery(name = "Facturacionxpagar.findAll", query = "SELECT f FROM Facturacionxpagar f"),
    @NamedQuery(name = "Facturacionxpagar.findByIdfactura", query = "SELECT f FROM Facturacionxpagar f WHERE f.facturacionxpagarPK.idfactura = :idfactura"),
    @NamedQuery(name = "Facturacionxpagar.findByIdtdocumento", query = "SELECT f FROM Facturacionxpagar f WHERE f.facturacionxpagarPK.idtdocumento = :idtdocumento"),
    @NamedQuery(name = "Facturacionxpagar.findByCredito", query = "SELECT f FROM Facturacionxpagar f WHERE f.credito = :credito"),
    @NamedQuery(name = "Facturacionxpagar.findByDiascredito", query = "SELECT f FROM Facturacionxpagar f WHERE f.diascredito = :diascredito"),
    @NamedQuery(name = "Facturacionxpagar.findByIdproveedor", query = "SELECT f FROM Facturacionxpagar f WHERE f.facturacionxpagarPK.idproveedor = :idproveedor"),
    @NamedQuery(name = "Facturacionxpagar.findByMonto", query = "SELECT f FROM Facturacionxpagar f WHERE f.monto = :monto"),
    @NamedQuery(name = "Facturacionxpagar.findByDescripcion", query = "SELECT f FROM Facturacionxpagar f WHERE f.descripcion = :descripcion"),
    @NamedQuery(name = "Facturacionxpagar.findByFechaingreso", query = "SELECT f FROM Facturacionxpagar f WHERE f.fechaingreso = :fechaingreso"),
    @NamedQuery(name = "Facturacionxpagar.findByFechaemision", query = "SELECT f FROM Facturacionxpagar f WHERE f.fechaemision = :fechaemision"),
    @NamedQuery(name = "Facturacionxpagar.findByGeneraiva", query = "SELECT f FROM Facturacionxpagar f WHERE f.generaiva = :generaiva"),
    @NamedQuery(name = "Facturacionxpagar.findByGenretencion", query = "SELECT f FROM Facturacionxpagar f WHERE f.genretencion = :genretencion"),
    @NamedQuery(name = "Facturacionxpagar.findByIdquedan", query = "SELECT f FROM Facturacionxpagar f WHERE f.idquedan = :idquedan"),
    @NamedQuery(name = "Facturacionxpagar.findByFechaquedan", query = "SELECT f FROM Facturacionxpagar f WHERE f.fechaquedan = :fechaquedan"),
    @NamedQuery(name = "Facturacionxpagar.findByEstado", query = "SELECT f FROM Facturacionxpagar f WHERE f.estado = :estado")})
public class Facturacionxpagar implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected FacturacionxpagarPK facturacionxpagarPK;
    @Column(name = "credito")
    private Boolean credito;
    @Column(name = "diascredito")
    private Integer diascredito;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "monto")
    private Double monto;
    @Size(max = 100)
    @Column(name = "descripcion")
    private String descripcion;
    @Column(name = "fechaingreso")
    @Temporal(TemporalType.DATE)
    private Date fechaingreso;
    @Column(name = "fechaemision")
    @Temporal(TemporalType.DATE)
    private Date fechaemision;
    @Column(name = "generaiva")
    private Boolean generaiva;
    @Column(name = "genretencion")
    private Boolean genretencion;
    @Size(max = 255)
    @Column(name = "idquedan")
    private String idquedan;
    @Column(name = "fechaquedan")
    @Temporal(TemporalType.DATE)
    private Date fechaquedan;
    @Basic(optional = false)
    @NotNull
    @Column(name = "estado")
    private int estado;
    @JoinColumn(name = "idproveedor", referencedColumnName = "idproveedor", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Proveedores proveedores;

    public Facturacionxpagar() {
    }

    public Facturacionxpagar(FacturacionxpagarPK facturacionxpagarPK) {
        this.facturacionxpagarPK = facturacionxpagarPK;
    }

    public Facturacionxpagar(FacturacionxpagarPK facturacionxpagarPK, int estado) {
        this.facturacionxpagarPK = facturacionxpagarPK;
        this.estado = estado;
    }

    public Facturacionxpagar(String idfactura, int idtdocumento, int idproveedor) {
        this.facturacionxpagarPK = new FacturacionxpagarPK(idfactura, idtdocumento, idproveedor);
    }

    public FacturacionxpagarPK getFacturacionxpagarPK() {
        return facturacionxpagarPK;
    }

    public void setFacturacionxpagarPK(FacturacionxpagarPK facturacionxpagarPK) {
        this.facturacionxpagarPK = facturacionxpagarPK;
    }

    public Boolean getCredito() {
        return credito;
    }

    public void setCredito(Boolean credito) {
        this.credito = credito;
    }

    public Integer getDiascredito() {
        return diascredito;
    }

    public void setDiascredito(Integer diascredito) {
        this.diascredito = diascredito;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaingreso() {
        return fechaingreso;
    }

    public void setFechaingreso(Date fechaingreso) {
        this.fechaingreso = fechaingreso;
    }

    public Date getFechaemision() {
        return fechaemision;
    }

    public void setFechaemision(Date fechaemision) {
        this.fechaemision = fechaemision;
    }

    public Boolean getGeneraiva() {
        return generaiva;
    }

    public void setGeneraiva(Boolean generaiva) {
        this.generaiva = generaiva;
    }

    public Boolean getGenretencion() {
        return genretencion;
    }

    public void setGenretencion(Boolean genretencion) {
        this.genretencion = genretencion;
    }

    public String getIdquedan() {
        return idquedan;
    }

    public void setIdquedan(String idquedan) {
        this.idquedan = idquedan;
    }

    public Date getFechaquedan() {
        return fechaquedan;
    }

    public void setFechaquedan(Date fechaquedan) {
        this.fechaquedan = fechaquedan;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public Proveedores getProveedores() {
        return proveedores;
    }

    public void setProveedores(Proveedores proveedores) {
        this.proveedores = proveedores;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (facturacionxpagarPK != null ? facturacionxpagarPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Facturacionxpagar)) {
            return false;
        }
        Facturacionxpagar other = (Facturacionxpagar) object;
        if ((this.facturacionxpagarPK == null && other.facturacionxpagarPK != null) || (this.facturacionxpagarPK != null && !this.facturacionxpagarPK.equals(other.facturacionxpagarPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Facturacionxpagar[ facturacionxpagarPK=" + facturacionxpagarPK + " ]";
    }
    
}
