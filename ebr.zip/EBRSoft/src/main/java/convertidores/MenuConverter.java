/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package convertidores;


import entidades.Menu;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import org.primefaces.component.picklist.PickList;
import org.primefaces.model.DualListModel;

/**
 *
 * @author java
 */
@FacesConverter("menuConverter")
public class MenuConverter implements Converter {

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        Object menu = null;

        if (component instanceof PickList) {
            Object dualList = ((PickList) component).getValue();
            DualListModel dl = (DualListModel) dualList;
            for (Object obj : dl.getSource()) {
                String id = "" + ((Menu) obj).getIdMenu();
                if (value.equals(id)) {
                    menu = obj;
                    break;
                }
            }
            if (menu == null) {
                for (Object obj : dl.getTarget()) {
                    String id = "" + ((Menu) obj).getIdMenu();
                    if (value.equals(id)) {
                        menu = obj;
                        break;
                    }
                }
            }

        }

        return menu;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
       String str = "";
    if (value instanceof Menu) {
        str = "" + ((Menu) value).getIdMenu();
    }
    return str;
    }

}
