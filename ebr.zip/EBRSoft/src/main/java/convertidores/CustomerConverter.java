/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package convertidores;

import entidades.Clientes;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;
import modelo.ClientesFacade;

/**
 *
 * @author cc90930
 */
@FacesConverter("customerConverter")
public class CustomerConverter implements Converter {
    
    @Inject
    ClientesFacade clienteFacade;

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        return clienteFacade.find(value);
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        return ((Clientes) value).getNombres();
    }
    
}
