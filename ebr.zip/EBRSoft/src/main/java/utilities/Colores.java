/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilities;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Carlos
 */

public class Colores{

    private String nombreColor;
    private String idColor;
    
    private List<Colores> listaColores;

    public Colores() {
    }

    public Colores(String nombreColor, String idColor) {
        this.nombreColor = nombreColor;
        this.idColor = idColor;
    }

    public void generarColores(){
        this.listaColores=new ArrayList<>();
        this.listaColores.add(new Colores("Verde","greenyellow"));
        this.listaColores.add(new Colores("Amarillo","yellow"));
        this.listaColores.add(new Colores("Rojo","red"));
        this.listaColores.add(new Colores("Azul","blue"));
        
        
    }
    
    
    public String getNombreColor() {
        return nombreColor;
    }

    public void setNombreColor(String nombreColor) {
        this.nombreColor = nombreColor;
    }

    public String getIdColor() {
        return idColor;
    }

    public void setIdColor(String idColor) {
        this.idColor = idColor;
    }

    public List<Colores> getListaColores() {
        return listaColores;
    }

    public void setListaColores(List<Colores> listaColores) {
        this.listaColores = listaColores;
    }
    
    
    
}
