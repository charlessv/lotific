/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Eventos;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

/**
 *
 * @author Carlos
 */
@Stateless
public class EventosFacade extends AbstractFacade<Eventos> {

    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EventosFacade() {
        super(Eventos.class);
    }

    public Eventos buscarEventoporNombre(String nombre) {
        try {
            Query query = em.createQuery("Select e from Eventos e where e.nombre=?1");
            query.setParameter(1, nombre);

            return (Eventos) query.getSingleResult();

        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }

    }

    public List<Eventos> buscarEventosEstado(int idEstado) {
        Query query = em.createQuery("Select e from Eventos e where e.estado=?1");
        query.setParameter(1, idEstado);

        return (List<Eventos>) query.getResultList();
    }

    public String obtenerNombreEvento(int idEvento) {
        try {
            Query query = em.createQuery("Select e.nombre from Eventos e where e.idEvento=?1");
            query.setParameter(1, idEvento);

            return (String) query.getSingleResult();
        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }

    }

    public List<Eventos> buscarEventosRangoFecha(Date fechaInicial, Date fechaFinal) {
        Query query = em.createQuery("Select e from Eventos e "
                + "where (e.fechainicio>=?1 and e.fechafin<=?2) "
                + "or (e.fechamontajeinicio>=?1 and e.fechamontajefin<=?2)"
                + "and e.estado=1 order by e.idEvento");

        query.setParameter(1, fechaInicial, TemporalType.DATE);
        query.setParameter(2, fechaFinal, TemporalType.DATE);

        return (List<Eventos>) query.getResultList();
    }

    public Eventos buscaEventoporId(int idevento) {
        try {
            Query query = em.createQuery("Select e  from Eventos e where e.idEvento=?1");
            query.setParameter(1, idevento);

            return (Eventos) query.getSingleResult();

        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }

    }

    public String buscarEventoporId(int idevento) {
        try {
            Query query = em.createQuery("Select e.nombre from Eventos e where e.idEvento=?1");
            query.setParameter(1, idevento);

            return query.getSingleResult().toString();

        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }
    }

}
