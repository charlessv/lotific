/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Tarifario;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Carlos
 */
@Stateless
public class TarifarioFacade extends AbstractFacade<Tarifario> {

    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TarifarioFacade() {
        super(Tarifario.class);
    }

    public int calcularId() {
        Query query = em.createQuery("SELECT coalesce(MAX(t.tarifarioPK.idTarifa)+1,1)"
                + "FROM Tarifario t");

        return Integer.parseInt(query.getSingleResult().toString());
    }
    
    public List<Tarifario> listarTarifas(){
        try{
            Query query=em.createQuery("select t from Tarifario t "
                    + "order by t.tarifarioPK.idCategoria,t.tarifarioPK.idProducto");
            
            return query.getResultList();
        }catch(Exception ex){
            return null;
        }
    }

    public Tarifario obtenerTarifaByProducto(int idCategoria, int idProducto) {
        try {
            Query query = em.createQuery("Select t from Tarifario t"
                    + " where t.tarifarioPK.idCategoria=?1"
                    + " and t.tarifarioPK.idProducto=?2");

            query.setParameter(1, idCategoria);
            query.setParameter(2, idProducto);

            return (Tarifario) query.getSingleResult();

        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }
    }
}
