/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Cotizaciones;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Carlos
 */
@Stateless
public class CotizacionesFacade extends AbstractFacade<Cotizaciones> {

    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CotizacionesFacade() {
        super(Cotizaciones.class);
    }

    public List<Cotizaciones> cotizacionesPorEvento(int idEvento) {
        Query query = em.createQuery("Select c from Cotizaciones c where c.idEvento.idEvento=?1");
        query.setParameter(1, idEvento);

        return (List<Cotizaciones>) query.getResultList();
    }

    public List<Cotizaciones> cotizacionesPorEstado(int idEstado) {
        Query query = em.createQuery("Select c from Cotizaciones c where c.estado=?1");
        query.setParameter(1, idEstado);

        return (List<Cotizaciones>) query.getResultList();
    }

    public String contarCotisxEventoId(int idevento) {
        try {
            Query query = em.createQuery("SELECT count(e) FROM Cotizaciones e where e.idEvento=?1");
            query.setParameter(1, idevento);

            return query.getSingleResult().toString();

        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }
    }

    public int validarCotizacionesxEvento(int idevento) {
        try {
            Query query = em.createQuery("SELECT count(e) FROM Cotizaciones e where "
                    + "e.idEvento.idEvento=?1");
            query.setParameter(1, idevento);

            return Integer.parseInt(query.getSingleResult().toString());

        } catch (NonUniqueResultException | NoResultException ex) {
            return 0;
        }

    }

    public int calcularId() {
        try {
            Query query = em.createQuery("SELECT MAX(c.idCotizacion)+1"
                    + " FROM Cotizaciones c");
            return Integer.parseInt(query.getSingleResult().toString());

        } catch (Exception ex) {
            return 1;
        }

    }

}
