/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Menu;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Carlos
 */
@Stateless
public class MenuFacade extends AbstractFacade<Menu> {
    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MenuFacade() {
        super(Menu.class);
    }
    
    public List<Menu> obtenerMenusAsociadosByRol(int idRol){
        try{
            Query query=em.createQuery("Select m from Menu m " 
                    +"where m.idMenu in "
                    + "(Select mr.idMenu from Menurol mr where mr.idRol=?1)");
            
          query.setParameter(1, idRol);
          return (List<Menu>) query.getResultList();
        }catch(Exception ex){
          return null;  
        }
    }
    
    public List<Menu> obtenerMenusNoAsociadosByRol(int idRol){
        try{
            Query query=em.createQuery("Select m from Menu m " 
                    +"where m.idMenu not in "
                    + "(Select mr.idMenu from Menurol mr where mr.idRol=?1)");
            
          query.setParameter(1, idRol);
          return (List<Menu>) query.getResultList();
        }catch(Exception ex){
          return null;  
        }
    }
    
}
