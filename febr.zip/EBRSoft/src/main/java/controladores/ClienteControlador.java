/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Auxdetparam;
import entidades.Clientes;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Named;
import modelo.AuxdetparamFacade;
import modelo.ClientesFacade;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Carlos
 */
@ManagedBean
@SessionScoped
public class ClienteControlador {

    Clientes cliente;
    List<Clientes> listaClientes;
    List<Clientes> listaClientesFiltrada;
    List<Auxdetparam> listaDias;
    Date FechaHoy;

    @EJB
    ClientesFacade clientesFacade;
    @EJB
    AuxdetparamFacade auxDetParamFacade;

    @PostConstruct
    public void init() {
        FechaHoy = new Date();
        cliente = new Clientes();
        cliente.setIdCliente(0);
        cliente.setFechacreacion(FechaHoy);
        cliente.setNombres("");
        cliente.setApellidos("");
        listaClientes = new ArrayList<>();
        listaClientes = cargarClientes();
        listaDias = new ArrayList<>();
        listaDias = cargarDias();

    }


    public List<Clientes> cargarClientes() {
        listaClientes = clientesFacade.findAll();
        return listaClientes;
    }

    public void crearCliente() {
        try {
            clientesFacade.edit(cliente);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Cliente Creado"));
            this.cargarClientes();
            RequestContext.getCurrentInstance().update("frmClientes:tblClientes");
            RequestContext.getCurrentInstance().execute("PF('dlgAddCliente').hide()");
            this.cliente = new Clientes();
            this.cliente.setIdCliente(0);
         //   this.cliente.setFechacreacion(FechaHoy);
            this.cliente.setNombres("");
            this.cliente.setApellidos("");

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "Cliente No Creado " + ex.getMessage()));
        }

    }

    public void eliminarCliente(Clientes idcliente) {
        try {
            clientesFacade.remove(idcliente);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Cliente Eliminado"));
            this.cargarClientes();
            RequestContext.getCurrentInstance().update("frmClientes:tblClientes");
            RequestContext.getCurrentInstance().execute("PF('dlgAddCliente').hide()");
            this.cliente = new Clientes();
            this.cliente.setIdCliente(0);
           // this.cliente.setFechacreacion(FechaHoy);
            this.cliente.setNombres("");
            this.cliente.setApellidos("");
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "Cliente No Eliminado"));
        }
    }

    public void actualizarCliente() {
        try {
            clientesFacade.edit(cliente);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Cliente Actualizado"));
            this.cargarClientes();
            RequestContext.getCurrentInstance().update("frmClientes:tblClientes");
            RequestContext.getCurrentInstance().execute("PF('dlgEditCliente').hide()");
            this.cliente = new Clientes();
            this.cliente.setIdCliente(0);
           // this.cliente.setFechacreacion(FechaHoy);
            this.cliente.setNombres("");
            this.cliente.setApellidos("");
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "Cliente No Actualizado"));
        }
    }

    public String buscarClienteporid(int idCliente) {
        String nombreCompleto = "";
        this.cliente = clientesFacade.buscarClienteporid(idCliente);
        if (this.cliente != null) {

            if (cliente.getNombres().equals("")) {
                nombreCompleto = this.cliente.getRazonsocial();
            } else {
                nombreCompleto = this.cliente.getNombres();
            }
        } else {
            nombreCompleto = "";
        }
        return nombreCompleto;

    }
    
    public List<Clientes> consultaClientes(String query){
        List<Clientes> listaCustomerFiltrada=new ArrayList<>();
        
        for(Clientes cliente: this.listaClientes){
            if (cliente.getNombres().toLowerCase().contains(query)
                    ||cliente.getNombres().toUpperCase().contains(query)){
                listaCustomerFiltrada.add(cliente);
            }
        }
        
        return listaCustomerFiltrada;
    }

    public ClienteControlador() {
    }

    public List<Auxdetparam> cargarDias() {
        listaDias = auxDetParamFacade.catalogoFiltrado(6); //Lista Colores
        return listaDias;
    }

    public List<SelectItem> ListarDias() {
        List<SelectItem> lstDias = new ArrayList<>();
        for (Auxdetparam dia : listaDias) {
            lstDias.add(new SelectItem(dia.getAuxdetparamPK().getCodigo(), dia.getAuxdetparamPK().getDescripcion()));
        }
        return lstDias;
    }

    public String BuscarDiaxID(int idCodigo) {
        String nombreDia = "";
        nombreDia = auxDetParamFacade.getDescripcionByID(6, idCodigo);
        return nombreDia;
    }
    
    
    public List<Auxdetparam> getListaDias() {
        return listaDias;
    }

    public void setListaDias(List<Auxdetparam> listaDias) {
        this.listaDias = listaDias;
    }

    public Clientes getCliente() {
        return cliente;
    }

    public void setCliente(Clientes cliente) {
        this.cliente = cliente;
    }

    public List<Clientes> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(List<Clientes> listaClientes) {
        this.listaClientes = listaClientes;
    }

    public List<Clientes> getListaClientesFiltrada() {
        return listaClientesFiltrada;
    }

    public void setListaClientesFiltrada(List<Clientes> listaClientesFiltrada) {
        this.listaClientesFiltrada = listaClientesFiltrada;
    }
}
