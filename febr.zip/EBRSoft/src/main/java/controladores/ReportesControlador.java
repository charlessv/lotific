/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Auxdetparam;
import entidades.Cotizaciones;
import entidades.Eventos;
import entidades.Facturacion;
import entidades.Facturacionxpagar;
import entidades.Tarifario;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import modelo.AuxdetparamFacade;
import modelo.CotizacionesFacade;
import modelo.EventosFacade;
import modelo.FacturacionFacade;
import modelo.FacturacionxpagarFacade;
import modelo.TarifarioFacade;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

/**
 *
 * @author Carlos
 */
@ManagedBean
@SessionScoped
public class ReportesControlador {

    @EJB
    EventosFacade eventoFacade;
    @EJB
    TarifarioFacade tarifaFacade;
    @EJB
    CotizacionesFacade cotizacionFacade;
    @EJB
    FacturacionFacade facturacionFacade;
    @EJB
    FacturacionxpagarFacade facturacionxPagarFacade;
    @EJB
    AuxdetparamFacade parametrizacionFacade;

    private Date fechaInicial;
    private Date fechaFinal;

    private String rutaReporte;
    private String nombreReporte;
    private String rutaSubReporte;

    private DateFormat formatoFecha;
    Map parametros;
    private JRBeanCollectionDataSource reporteDataSource;
    private JasperPrint jasperPrint;

    private Cotizaciones cotizacion;
    private Facturacion cuentaxcobrar;
    private Auxdetparam tipoReporteC;
    private Auxdetparam tipoReporteP;

    private List<Eventos> listaEventos;
    private List<Tarifario> listaTarifas;
    private List<Cotizaciones> listaCotizaciones;
    private List<Facturacion> listaCuentasxCobrar;
    private List<Facturacionxpagar> listaCuentasxPagar;
    private List<Auxdetparam> listaReportesC;
    private List<Auxdetparam> listaReportesP;

    @ManagedProperty("#{seguridadControlador}")
    private SeguridadControlador seguridadControlador;

    private StreamedContent archivoPDF = null;

    private int idReporteCuentasxCobrar;
    private int idReporteCuentasxPagar;

    private boolean showRTarifas;
    private boolean showRAgenda;

    private boolean showPnlFechasReporte;

    /**
     * Creates a new instance of ReportesControlador
     */
    
    @PostConstruct
    public void init() {
        this.parametros = new HashMap();
        this.fechaInicial = new Date();
        this.fechaFinal = new Date();

        this.cotizacion = new Cotizaciones();
        this.tipoReporteC = new Auxdetparam();
        this.tipoReporteP = new Auxdetparam();

        this.reporteDataSource = null;

        this.showRAgenda = false;
        this.showRTarifas = false;

        this.showPnlFechasReporte = false;
        this.idReporteCuentasxCobrar = 0;
        this.idReporteCuentasxPagar = 0;

        this.listaReportesC = new ArrayList<>();
        this.listaReportesC = cargarReportesC();

        this.listaReportesP = new ArrayList<>();
        this.listaReportesP = cargarReportesP();
        
        this.listaCotizaciones=new ArrayList<>();

    }

    public ReportesControlador() {

    }

    public void reportePdf() throws JRException, IOException {

        HttpServletResponse httpServletResponse = (HttpServletResponse) FacesContext.getCurrentInstance()
                .getExternalContext().getResponse();
        httpServletResponse.addHeader("Content-disposition", "inline;filename="
                + nombreReporte + ".pdf");

        httpServletResponse.setContentType("application/pdf");
        
        try (ServletOutputStream servletOutputStream
                = httpServletResponse.getOutputStream()) {
            JasperExportManager.exportReportToPdfStream(jasperPrint,
                    servletOutputStream);

        }

        httpServletResponse = (HttpServletResponse) FacesContext.getCurrentInstance()
                .getExternalContext().getResponse();
        httpServletResponse.setContentType("application/pdf");

        FacesContext.getCurrentInstance().responseComplete();

    }

    public void pdfReport() throws JRException, IOException {
        this.archivoPDF = new DefaultStreamedContent();
        try (ByteArrayOutputStream servletOutputStream = new ByteArrayOutputStream()) {
            //httpServletResponse.setContentType("application/pdf");
            JasperExportManager.exportReportToPdfStream(jasperPrint, servletOutputStream);
            servletOutputStream.flush();
            servletOutputStream.close();
            try (InputStream reportStream = new ByteArrayInputStream(servletOutputStream.toByteArray())) {
                archivoPDF
                        = new DefaultStreamedContent(reportStream, "application/pdf", this.nombreReporte);
                //reportStream.reset();
                FacesContext.getCurrentInstance().getViewRoot().getViewMap().clear();
            }
        }
    }

    public void reporteExcel() throws IOException, JRException {

        HttpServletResponse httpServletResponse = (HttpServletResponse) FacesContext.getCurrentInstance()
                .getExternalContext().getResponse();
        httpServletResponse.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        httpServletResponse.addHeader("Content-disposition", "inline; filename=" + nombreReporte + ".xls");
        ServletOutputStream servletOutputStream = httpServletResponse.getOutputStream();
        JRXlsxExporter docxExporter = new JRXlsxExporter();
        docxExporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
        docxExporter.setParameter(JRExporterParameter.OUTPUT_STREAM, servletOutputStream);

        docxExporter.exportReport();
        FacesContext.getCurrentInstance().responseComplete();

    }

    public String imprimirAgenda() {
        try {
            String fechaAgenda;

            this.nombreReporte = "Agenda";
            if (this.fechaInicial.equals(this.fechaFinal)) {
                formatoFecha = new SimpleDateFormat("EEE, d MMM yyyy");
                fechaAgenda = formatoFecha.format(fechaFinal);
            } else {
                formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
                fechaAgenda = "DESDE :" + formatoFecha.format(fechaInicial) + " HASTA :" + formatoFecha.format(fechaFinal);
            }

            rutaReporte = FacesContext.getCurrentInstance()
                    .getExternalContext().getRealPath("/reportes/agenda/" + nombreReporte + ".jasper");

            this.rutaSubReporte = FacesContext.getCurrentInstance()
                    .getExternalContext().getRealPath("/reportes/agenda/");//Se Asigna Ruta para SubReportes

            this.parametros.put("SUBREPORT_DIR", this.rutaSubReporte);
            this.parametros.put("REPORT_LOGO", FacesContext.getCurrentInstance()
                    .getExternalContext().getRealPath("/resources/imgs/logo.png"));
            this.parametros.put("fechaAgenda", fechaAgenda);
            

            this.listaEventos = eventoFacade.buscarEventosRangoFecha(fechaInicial, fechaFinal);
            if (this.listaEventos.size() > 0) {
                reporteDataSource = new JRBeanCollectionDataSource(this.listaEventos);

                jasperPrint = JasperFillManager.fillReport(rutaReporte, parametros, reporteDataSource);

                //reportePdf();
                pdfReport();//
                this.parametros = new HashMap();
                this.fechaInicial = new Date();
                this.fechaFinal = new Date();
                return "/reportes";
            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Reporte", "No Existen Actividades para la Fecha"));
                return "";
            }
        } catch (JRException | IOException ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Reporte No Generado" + ex.getMessage()));

            return "";
        }
    }

    public String imprimirTarifas(int idFormato) {
        try {
            this.nombreReporte = "Tarifas";

            this.rutaSubReporte = FacesContext.getCurrentInstance()
                    .getExternalContext().getRealPath("/reportes/tarifario/");//Se Asigna Ruta para SubReportes

            this.parametros.put("login", seguridadControlador.getUsuarioActivo());
            this.parametros.put("REPORT_LOGO", FacesContext.getCurrentInstance()
                    .getExternalContext().getRealPath("/resources/imgs/logo.png"));
            this.parametros.put("SUBREPORT_DIR", this.rutaSubReporte);

            this.listaTarifas = this.cargarTarifas();
            if (this.listaTarifas.size() > 0) {
                reporteDataSource = new JRBeanCollectionDataSource(this.listaTarifas);
                rutaReporte = FacesContext.getCurrentInstance()
                        .getExternalContext().getRealPath("/reportes/tarifario/" + nombreReporte + ".jasper");

                jasperPrint = JasperFillManager.fillReport(rutaReporte, parametros, reporteDataSource);

                this.pdfReport();
                this.parametros = new HashMap();
                return "/reportes";
            } else {
                RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "Reporte", "No Existen Tarifas"));
                return null;
            }
        } catch (JRException | IOException ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Reporte No Generado" + ex.getMessage()));
            return null;
        }
    }

    public String imprimirCotizacion(Cotizaciones idCotizacion) throws IOException, JRException {
        // try {
        this.cotizacion = new Cotizaciones();
        this.nombreReporte = "Cotizacion";

        rutaReporte = FacesContext.getCurrentInstance()
                .getExternalContext().getRealPath("/reportes/cotizacion/" + nombreReporte + ".jasper");

        this.rutaSubReporte = FacesContext.getCurrentInstance()
                .getExternalContext().getRealPath("/reportes/cotizacion/");//Se Asigna Ruta para SubReportes

        this.parametros.put("SUBREPORT_DIR", this.rutaSubReporte);
        this.parametros.put("REPORT_LOGO", FacesContext.getCurrentInstance()
                .getExternalContext().getRealPath("/resources/imgs/logo.png"));
        this.parametros.put("REPORT_BG", FacesContext.getCurrentInstance()
                .getExternalContext().getRealPath("/resources/imgs/Fondo.png"));
        
        this.cotizacion = cotizacionFacade.find(idCotizacion.getIdCotizacion());
        if (this.cotizacion != null) {
            this.parametros.put("NUM_COTIZACION", this.cotizacion.getIdCotizacion());
            reporteDataSource = new JRBeanCollectionDataSource(java.util.Collections.singleton(this.cotizacion));

            jasperPrint = JasperFillManager.fillReport(rutaReporte, parametros, reporteDataSource );
            //reportePdf();
            this.pdfReport();
            this.parametros = new HashMap();
            return "/reportes";

        } else {
            RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "Reporte", "No Se obtuvo Cotización"));
            return "";
        }
        /* } catch (JRException | IOException ex) {
         FacesContext.getCurrentInstance()
         .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Reporte No Generado" + ex.getMessage()));

         return null;
         }*/
    }

    public String generarReporteCuentas(int tipoReporte) {
        try {

            String reporte = "";

            switch (tipoReporte) {
                case 1:
                    if (tipoReporteC.getAuxdetparamPK().getCodigo() == 0) {
                        FacesContext.getCurrentInstance()
                                .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Error :", "Debe Seleccionar un Reporte"));
                        return null;
                    }
                    reporte = generarCuentasxCobrar();
                    break;
                case 2:
                    if (tipoReporteP.getAuxdetparamPK().getCodigo() == 0) {
                        FacesContext.getCurrentInstance()
                                .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Error :", "Debe Seleccionar un Reporte"));
                        return null;
                    }
                    reporte = generarCuentasxPagar();
                      
                    break;
            }

            return reporte;

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al obtener Reporte" + ex.getMessage()));
            return "";
        }

    }

    public String generarCuentasxCobrar() {
        try {
            String fechaReporte;
            
            this.nombreReporte = tipoReporteC.getValaux();

            rutaSubReporte = FacesContext.getCurrentInstance()
                    .getExternalContext().getRealPath("/reportes/cuentas/cobrar/");
            this.parametros.put("login", seguridadControlador.getUsuarioActivo());
            this.parametros.put("REPORT_LOGO", FacesContext.getCurrentInstance()
                    .getExternalContext().getRealPath("/resources/imgs/logo.png"));
            this.parametros.put("SUBREPORT_DIR", this.rutaSubReporte);
            
            switch (this.tipoReporteC.getAuxdetparamPK().getCodigo()){
                case 1:
                    this.listaCuentasxCobrar = facturacionFacade.listarComprobantes();
                    break;
                default:
                    formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
                    fechaReporte = "DESDE :" + formatoFecha.format(fechaInicial) + 
                            " HASTA :" + formatoFecha.format(fechaFinal);
                    this.parametros.put("REPORT_RANGO", fechaReporte);
                    this.listaCuentasxCobrar = facturacionFacade.
                            listarComprobantesRangoFecha('C',this.fechaInicial,this.fechaFinal);
                    break;
                    
            }
            if (!this.listaCuentasxCobrar.isEmpty()) {
                reporteDataSource = new JRBeanCollectionDataSource(listaCuentasxCobrar);
                rutaReporte = FacesContext.getCurrentInstance()
                        .getExternalContext().getRealPath("/reportes/cuentas/cobrar/" + nombreReporte + ".jasper");
                jasperPrint = JasperFillManager.fillReport(rutaReporte, parametros, reporteDataSource);

                //reportePdf();
                this.pdfReport();

                this.parametros = new HashMap();
                return "/reportes";
            } else {
                RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "Reporte :", "No existen Cuentas Pendientes"));
                return "";
            }
        } catch (JRException | IOException ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Reporte No Generado" + ex.getMessage()));
            return "";

        }
    }
    
    public String generarCuentasxPagar() {
        try {
            this.nombreReporte = tipoReporteP.getValaux();

            rutaSubReporte = FacesContext.getCurrentInstance()
                    .getExternalContext().getRealPath("/reportes/cuentas/pagar/");
            this.parametros.put("login", seguridadControlador.getUsuarioActivo());
            this.parametros.put("REPORT_LOGO", FacesContext.getCurrentInstance()
                    .getExternalContext().getRealPath("/resources/imgs/logo.png"));
            this.parametros.put("SUBREPORT_DIR", this.rutaSubReporte);

            this.listaCuentasxPagar = facturacionxPagarFacade.listarComprobantes();

            if (!this.listaCuentasxPagar.isEmpty()) {
                reporteDataSource = new JRBeanCollectionDataSource(listaCuentasxPagar);
                rutaReporte = FacesContext.getCurrentInstance()
                        .getExternalContext().getRealPath("/reportes/cuentas/pagar/" + nombreReporte + ".jasper");
                jasperPrint = JasperFillManager.fillReport(rutaReporte, parametros, reporteDataSource);

                //reportePdf();
                this.pdfReport();

                this.parametros = new HashMap();
                return "/reportes";
            } else {
                RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "Reporte :", "No existen Cuentas Pendientes"));
                return "";
            }
            
        } catch (JRException | IOException ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Reporte No Generado" + ex.getMessage()));
            return "";

        }
    }
    
    

    public void imprimirReporte(int formato) {
        try {
            switch (formato) {
                case 0:
                    reportePdf();
                    break;
                case 1:
                    reporteExcel();
                    break;
            }
        } catch (JRException | IOException ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error :", "Reporte No Generado" + ex.getMessage()));
        }
    }

    public void habilitarPanelFechasReporte(int proceso){
        //1=Cobrar 2=Pagar
        switch (proceso) {
            case 1:
                for (Auxdetparam reporte : this.listaReportesC) {
                    if (reporte.getAuxdetparamPK().getCodigo() == this.idReporteCuentasxCobrar) {
                        this.tipoReporteC = reporte;
                        break;
                    }
                }

                if (this.tipoReporteC.getAuxdetparamPK().getCodigo() > 1) {
                    this.showPnlFechasReporte = Boolean.TRUE;
                } else {
                    this.showPnlFechasReporte = Boolean.FALSE;
                }
                break;
            case 2:
                for (Auxdetparam reporte : this.listaReportesP) {
                    if (reporte.getAuxdetparamPK().getCodigo() == this.idReporteCuentasxPagar) {
                        this.tipoReporteP = reporte;
                        break;
                    }
                }

                if (this.tipoReporteP.getAuxdetparamPK().getCodigo() > 1) {
                    this.showPnlFechasReporte = Boolean.TRUE;
                } else {
                    this.showPnlFechasReporte = Boolean.FALSE;
                }
                break;
        }

    }

    public List<Eventos> cargarEventos() {
        this.listaEventos = eventoFacade.findAll();
        return this.listaEventos;
    }

    public List<Tarifario> cargarTarifas() {
        this.listaTarifas = tarifaFacade.listarTarifas();
        return this.listaTarifas;
    }

    public List<Auxdetparam> cargarReportesC() {
        this.listaReportesC = parametrizacionFacade.catalogoFiltrado(9);

        return this.listaReportesC;
    }

    public List<Auxdetparam> cargarReportesP() {
        this.listaReportesP = parametrizacionFacade.catalogoFiltrado(10);

        return this.listaReportesP;
    }

    public List<SelectItem> listaReportesDisponiblesC() {
        List<SelectItem> listadoSelectReportesC = new ArrayList<>();

        for (Auxdetparam reportes : this.listaReportesC) {
            listadoSelectReportesC
                    .add(new SelectItem(reportes.getAuxdetparamPK().getCodigo(),
                                    reportes.getAuxdetparamPK().getDescripcion()));

        }

        return listadoSelectReportesC;

    }

    public List<SelectItem> listaReportesDisponiblesP() {
        List<SelectItem> listadoSelectReportesP = new ArrayList<>();

        for (Auxdetparam reportes : this.listaReportesP) {
            listadoSelectReportesP
                    .add(new SelectItem(reportes.getAuxdetparamPK().getCodigo(),
                                    reportes.getAuxdetparamPK().getDescripcion()));

        }

        return listadoSelectReportesP;

    }

    public Date getFechaInicial() {
        return fechaInicial;
    }

    public void setFechaInicial(Date fechaInicial) {
        this.fechaInicial = fechaInicial;
    }

    public Date getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(Date fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public String getNombreReporte() {
        return nombreReporte;
    }

    public void setNombreReporte(String nombreReporte) {
        this.nombreReporte = nombreReporte;
    }

    public Map getParametros() {
        return parametros;
    }

    public void setParametros(Map parametros) {
        this.parametros = parametros;
    }

    public List<Eventos> getListaEventos() {
        return listaEventos;
    }

    public void setListaEventos(List<Eventos> listaEventos) {
        this.listaEventos = listaEventos;
    }

    public String getRutaReporte() {
        return rutaReporte;
    }

    public void setRutaReporte(String rutaReporte) {
        this.rutaReporte = rutaReporte;
    }

    public JasperPrint getJasperPrint() {
        return jasperPrint;
    }

    public void setJasperPrint(JasperPrint jasperPrint) {
        this.jasperPrint = jasperPrint;
    }

    public List<Tarifario> getListaTarifas() {
        return listaTarifas;
    }

    public void setListaTarifas(List<Tarifario> listaTarifas) {
        this.listaTarifas = listaTarifas;
    }

    public SeguridadControlador getSeguridadControlador() {
        return seguridadControlador;
    }

    public void setSeguridadControlador(SeguridadControlador seguridadControlador) {
        this.seguridadControlador = seguridadControlador;
    }

    public Cotizaciones getCotizacion() {
        return cotizacion;
    }

    public void setCotizacion(Cotizaciones cotizacion) {
        this.cotizacion = cotizacion;
    }

    public StreamedContent getArchivoPDF() {
        return archivoPDF;
    }

    public void setArchivoPDF(StreamedContent archivoPDF) {
        this.archivoPDF = archivoPDF;
    }

    public boolean isShowRTarifas() {
        return showRTarifas;
    }

    public void setShowRTarifas(boolean showRTarifas) {
        this.showRTarifas = showRTarifas;
    }

    public boolean isShowRAgenda() {
        return showRAgenda;
    }

    public void setShowRAgenda(boolean showRAgenda) {
        this.showRAgenda = showRAgenda;
    }

    public boolean isShowPnlFechasReporte() {
        return showPnlFechasReporte;
    }

    public void setShowPnlFechasReporte(boolean showPnlFechasReporte) {
        this.showPnlFechasReporte = showPnlFechasReporte;
    }

    public int getIdReporteCuentasxCobrar() {
        return idReporteCuentasxCobrar;
    }

    public void setIdReporteCuentasxCobrar(int idReporteCuentasxCobrar) {
        this.idReporteCuentasxCobrar = idReporteCuentasxCobrar;
    }

    public List<Facturacion> getListaCuentasxCobrar() {
        return listaCuentasxCobrar;
    }

    public void setListaCuentasxCobrar(List<Facturacion> listaCuentasxCobrar) {
        this.listaCuentasxCobrar = listaCuentasxCobrar;
    }

    public Facturacion getCuentaxcobrar() {
        return cuentaxcobrar;
    }

    public void setCuentaxcobrar(Facturacion cuentaxcobrar) {
        this.cuentaxcobrar = cuentaxcobrar;
    }

    public Auxdetparam getTipoReporteC() {
        return tipoReporteC;
    }

    public void setTipoReporteC(Auxdetparam tipoReporteC) {
        this.tipoReporteC = tipoReporteC;
    }

    public List<Auxdetparam> getListaReportesC() {
        return listaReportesC;
    }

    public void setListaReportesC(List<Auxdetparam> listaReportesC) {
        this.listaReportesC = listaReportesC;
    }

    public String getRutaSubReporte() {
        return rutaSubReporte;
    }

    public void setRutaSubReporte(String rutaSubReporte) {
        this.rutaSubReporte = rutaSubReporte;
    }

    public int getIdReporteCuentasxPagar() {
        return idReporteCuentasxPagar;
    }

    public void setIdReporteCuentasxPagar(int idReporteCuentasxPagar) {
        this.idReporteCuentasxPagar = idReporteCuentasxPagar;
    }

    public List<Auxdetparam> getListaReportesP() {
        return listaReportesP;
    }

    public void setListaReportesP(List<Auxdetparam> listaReportesP) {
        this.listaReportesP = listaReportesP;
    }

    public Auxdetparam getTipoReporteP() {
        return tipoReporteP;
    }

    public void setTipoReporteP(Auxdetparam tipoReporteP) {
        this.tipoReporteP = tipoReporteP;
    }

    public List<Facturacionxpagar> getListaCuentasxPagar() {
        return listaCuentasxPagar;
    }

    public void setListaCuentasxPagar(List<Facturacionxpagar> listaCuentasxPagar) {
        this.listaCuentasxPagar = listaCuentasxPagar;
    }

   
    public List<Cotizaciones> getListaCotizaciones() {
        return listaCotizaciones;
    }

    public void setListaCotizaciones(List<Cotizaciones> listaCotizaciones) {
        this.listaCotizaciones = listaCotizaciones;
    }
    
    

}
