/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Categorias;
import entidades.Productos;
import entidades.ProductosPK;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import modelo.CategoriasFacade;
import modelo.ProductosFacade;
import org.primefaces.context.RequestContext;

/**
 *
 * @author cc90930
 */
@ManagedBean
@ViewScoped
public class ProductosControlador implements Serializable {

    @EJB
    ProductosFacade productoFacade;

    @EJB
    CategoriasFacade categoriaFacade;

    private Productos producto;
    private ProductosPK productoPK;
    private Categorias categoria;

    private List<Productos> listaProductos;
    private List<Productos> listaProductosFiltrada;

    private int idCategoria;

    /**
     * Creates a new instance of ProductosControlador
     */
    @PostConstruct
    public void init() {
        producto = new Productos();
        productoPK = new ProductosPK();
        categoria = new Categorias();

        listaProductos = new ArrayList<>();
        this.listaProductos = cargarProductos();

        this.idCategoria = 0;
        productoPK.setIdCategoria(idCategoria);
        producto.setProductosPK(productoPK);

    }

    public ProductosControlador() {
    }

    public void crearProducto() {
        try {
            if (this.categoria.getIdCategoria() == 0) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error :", "Debe Seleccionar Categoria de Producto"));
            } else {
                producto.getProductosPK().setIdCategoria(categoria.getIdCategoria());
                producto.getProductosPK().setIdProducto(productoFacade.calcularId(categoria.getIdCategoria()));
                producto.setCategorias(categoria);
                productoFacade.create(producto);

                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                        "Correcto :", "Producto Creado"));

                this.cargarProductos();
                RequestContext.getCurrentInstance().update("frmProductos:tblProductos");
                RequestContext.getCurrentInstance().execute("PF('dlgAddProducto').hide()");
                this.producto = new Productos();
                this.productoPK = new ProductosPK();
                productoPK.setIdCategoria(categoria.getIdCategoria());
                producto.setProductosPK(productoPK);
            }

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Crear Producto" + ex.getMessage()));
        }

    }

    public void eliminarProducto(Productos idProducto) {
        try {
            productoFacade.remove(idProducto);

            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                    "Correcto :", "Producto Eliminado"));

            this.cargarProductos();
            RequestContext.getCurrentInstance().update("frmProductos:tblProductos");
            RequestContext.getCurrentInstance().execute("PF('dlgAddProducto').hide()");
            this.producto = new Productos();
            this.productoPK = new ProductosPK();
            this.categoria=new Categorias();
            this.idCategoria=0;
            this.categoria.setIdCategoria(idCategoria);
            productoPK.setIdCategoria(categoria.getIdCategoria());
            producto.setProductosPK(productoPK);

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Eliminar Producto" + ex.getMessage()));
        }

    }

    public void editarProducto() {
        try {
            if (this.producto.getProductosPK().getIdCategoria() == 0) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error :", "Debe Seleccionar Categoria de Producto"));
            } else {
                productoFacade.edit(producto);

                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                        "Correcto :", "Producto Actualizado"));

                this.cargarProductos();
                RequestContext.getCurrentInstance().update("frmProductos:tblProductos");
                RequestContext.getCurrentInstance().execute("PF('dlgEditProducto').hide()");
                this.producto = new Productos();
                this.productoPK = new ProductosPK();
                this.categoria=new Categorias();
                this.idCategoria=0;
                this.categoria.setIdCategoria(idCategoria);
                productoPK.setIdCategoria(categoria.getIdCategoria());
                producto.setProductosPK(productoPK);
            }

        } catch (Exception ex) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                    "Error :", "Error al Actualizar Producto" + ex.getMessage()));
        }

    }

    public List<Productos> cargarProductos() {
        this.listaProductos = productoFacade.findAll();
        return this.listaProductos;
    }

    public List<Productos> cargarPorCategoria() {

        if (this.categoria != null && this.categoria.getIdCategoria() > 0) {
            this.listaProductos = productoFacade.cargarPorCategoria(this.categoria.getIdCategoria());
        } else {
            cargarProductos();
        }
        return this.listaProductos;
    }

    public String obtenerNombre(int idCategoria, int idProducto) {

        return productoFacade.obtenerNombre(idCategoria, idProducto);

    }

    public Productos getProducto() {
        return producto;
    }

    public void setProducto(Productos producto) {
        this.producto = producto;
    }

    public Categorias getCategoria() {
        return categoria;
    }

    public void setCategoria(Categorias categoria) {
        this.categoria = categoria;
    }

    public List<Productos> getListaProductos() {
        return listaProductos;
    }

    public void setListaProductos(List<Productos> listaProductos) {
        this.listaProductos = listaProductos;
    }

    public List<Productos> getListaProductosFiltrada() {
        return listaProductosFiltrada;
    }

    public void setListaProductosFiltrada(List<Productos> listaProductosFiltrada) {
        this.listaProductosFiltrada = listaProductosFiltrada;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public ProductosPK getProductoPK() {
        return productoPK;
    }

    public void setProductoPK(ProductosPK productoPK) {
        this.productoPK = productoPK;
    }

}
