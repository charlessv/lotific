/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Clientes;
import entidades.Cotizaciones;
import entidades.Detallecotizacion;
import entidades.DetallecotizacionPK;
import entidades.Eventos;
import entidades.Productos;
import entidades.Tarifario;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import modelo.CotizacionesFacade;
import modelo.DetallecotizacionFacade;
import modelo.EventosFacade;
import modelo.ProductosFacade;
import modelo.TarifarioFacade;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;

/**
 *
 * @author Carlos
 */
@ManagedBean
@ViewScoped
public class CotizacionControlador implements Serializable {

    Productos producto;
    Eventos evento;
    Clientes cliente;
    Cotizaciones cotizacion;
    Detallecotizacion cotizacionDet;
    Tarifario tarifario;

    List<Cotizaciones> listaCotizaciones;
    List<Cotizaciones> listaCotizacionesFiltrada;
    List<Cotizaciones> listaCotizacionesXevento;

    List<Detallecotizacion> listaCotizacionesDet;
    List<Detallecotizacion> listaCotizacionesDetFiltrada;
    List<Detallecotizacion> listaCotizacionesDetNew;
    List<Detallecotizacion> listaCotizacionesDetEdit;

    private double totalevento;
    private double valorTotal;
    public double valorTotalfila;

    private Date FechaHoy;
    private Boolean isEditing;

    @EJB
    ProductosFacade productosFacade;

    @EJB
    TarifarioFacade tarifarioFacade;

    @EJB
    CotizacionesFacade cotizacionesFacade;

    @EJB
    DetallecotizacionFacade detalleCotizacionFacade;

    @EJB
    EventosFacade eventoFacade;

    @ManagedProperty("#{productosControlador}")
    private ProductosControlador productosControlador;

    @ManagedProperty("#{eventosControlador}")
    private EventosControlador eventosControlador;

    @ManagedProperty("#{clienteControlador}")
    private ClienteControlador clienteControlador;

    @ManagedProperty("#{seguridadControlador}")
    private SeguridadControlador seguridadControlador;

    @PostConstruct
    public void init() {
        totalevento = 0.00;
        evento = new Eventos();
        evento.setNombre("");
        valorTotal = 0;
        FechaHoy = new Date();
        tarifario = new Tarifario();
        cotizacion = new Cotizaciones();
        cotizacion.setIdCotizacion(0);
        cotizacion.setEstado(0);
        cotizacion.setDescuento(0d);
        cotizacionDet = new Detallecotizacion();
        cotizacion.setFechacreacion(FechaHoy);
        listaCotizaciones = new ArrayList<>();
        listaCotizaciones = cargarCotizaciones();
        //  listaCotizacionesDet = new ArrayList<>();
        //listaCotizacionesDet = cargarCotizacionesDet();
        listaCotizacionesDetNew = new ArrayList<>();
        listaCotizacionesXevento = new ArrayList<>();
        listaCotizacionesDetEdit = new ArrayList<>();

        this.isEditing = Boolean.FALSE;

    }

    public List<Cotizaciones> cargarCotizaciones() {
        listaCotizaciones = cotizacionesFacade.findAll();
        return listaCotizaciones;
    }

    public List<Detallecotizacion> cargarCotizacionesDet() {
        listaCotizacionesDet = detalleCotizacionFacade.findAll();
        return listaCotizacionesDet;
    }

    public void crearCotizacion() {

        if (this.isEditing) {
            this.editarCotizacion();
            return;
        }

        try {
            //if (this.cotizacion.getIdEvento() == null) {
            //    FacesContext.getCurrentInstance()
            //            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Debe Asignar un Evento a Cotización"));
            //    return;

            //}
            int i = 1;
            if (this.cotizacion.getIdEvento().getIdEvento() == 0) {

                eventosControlador.setEvento(cotizacion.getIdEvento());
                eventosControlador.crearEvento(i);
            } else {

                cotizacion.setUsuario(seguridadControlador.getUsuarioActivo());
                cotizacion.setIdCotizacion(cotizacionesFacade.calcularId());
                cotizacionesFacade.edit(cotizacion);
                DetallecotizacionPK detalleCotizacionPK = new DetallecotizacionPK();
                detalleCotizacionPK.setIdCotizacion(cotizacion.getIdCotizacion());
                cotizacionDet.setDetallecotizacionPK(detalleCotizacionPK);
                for (Detallecotizacion Detcot : this.listaCotizacionesDetNew) {
                    Detcot.setDetallecotizacionPK(detalleCotizacionPK);
                    Detcot.getDetallecotizacionPK().setIdDetallecotizacion(i);
                    Detcot.setCotizaciones(cotizacion);
                    detalleCotizacionFacade.edit(Detcot);
                    i++;
                }
                // eventosControlador.eventoFacade.edit(evento);
                limpiarControles();
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Cotizacion Creado"));
                this.cargarCotizaciones();

                RequestContext.getCurrentInstance().update("frmCotizacion");
            }
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Cotizacion no Creado" + ex.getMessage()));
        }

    }

    public void limpiarControles() {
        evento = new Eventos();
        cliente = new Clientes();
        FechaHoy = new Date();

        cliente.setNombres("");
        cliente.setIdCliente(0);
        evento.setNombre("");
        evento.setIdCliente(cliente);
        evento.setNombre("");
        valorTotal = 0;
        tarifario = new Tarifario();
        cotizacion = new Cotizaciones();
        cotizacion.setIdCotizacion(0);
        cotizacion.setDescuento(0d);
        cotizacionDet = new Detallecotizacion();
        cotizacion.setFechacreacion(FechaHoy);
        listaCotizaciones = new ArrayList<>();
        cotizacion.setUsuario(seguridadControlador.getUsuarioActivo());
        listaCotizaciones = cargarCotizaciones();
        listaCotizacionesDetNew = new ArrayList<>();

        this.isEditing = Boolean.FALSE;
        this.eventosControlador.limpiarControles();
        RequestContext.getCurrentInstance().update("frmCotizacion");
    }

    public void eliminarCotizacion(Cotizaciones idcotizacion) {
        try {
            cotizacionesFacade.remove(idcotizacion);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Evento Eliminado"));
            this.cargarCotizaciones();
            this.cotizacion = new Cotizaciones();
            RequestContext.getCurrentInstance().update("frmCotizaciones:tblCotizaciones");

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Evento no Eliminado"));
        }
    }

    public void editarCotizacion() {
        try {
            int i = 1;
            cotizacion.setEstado(0);
            cotizacionesFacade.edit(cotizacion);
            DetallecotizacionPK detalleCotizacionPK = new DetallecotizacionPK();
            detalleCotizacionPK.setIdCotizacion(cotizacion.getIdCotizacion());
            cotizacionDet.setDetallecotizacionPK(detalleCotizacionPK);
            detalleCotizacionFacade.EliminarDetallexId(cotizacion.getIdCotizacion());
            //  detalleCotizacionFacade.remove(cotizacionDet);
            for (Detallecotizacion Detcot : this.listaCotizacionesDetEdit) {
                Detcot.setDetallecotizacionPK(detalleCotizacionPK);
                Detcot.getDetallecotizacionPK().setIdDetallecotizacion(i);
                detalleCotizacionFacade.create(Detcot);
                i++;
            }
            //  calculatotalcotizacion(cotizacion.getIdCotizacion());
            this.evento=cotizacion.getIdEvento();
            cotizacion.getIdEvento().setCosto(CostoPorEvento(this.evento.getIdEvento()));
            
            eventosControlador.eventoFacade.edit(this.evento    );
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Cotización Actualizado"));
            this.cargarCotizaciones();
            limpiarControles();
            
            RequestContext.getCurrentInstance().update("frmCotizaciones:tblCotizaciones");
            
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Evento no Actualizado"));
        }
    }

    public void editarEstadoCotizacion(int estado) {
        try {
            String status = "";
            switch (estado) {
                case 1:
                    status = "Cotización Aprobada";
                    break;
                case 2:
                    status = "Cotizacion Rechazada";
                    break;

            }

            if (cotizacion.getEstado() == 1) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                        "Error :", "Cotización se Encuentra Aprobada"));
                return;
            } else {
                if (cotizacion.getEstado() == 2) {
                    FacesContext.getCurrentInstance()
                            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                            "Error :", "Cotización se Encuentra Rechazada"));
                    return;
                } else {
                    cotizacion.setEstado(estado);

                    cotizacionesFacade.edit(cotizacion);
                    if (estado == 1) {
                        evento.setEstado(estado);
                    } else {
                        evento.setEstado(0);
                    }
                    eventosControlador.eventoFacade.edit(evento);

                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto:", status));
                    this.cargarCotizaciones();
                    limpiarControles();
                }
            }

            RequestContext.getCurrentInstance().update("frmCotizaciones:tblCotizaciones");
            RequestContext.getCurrentInstance().execute("PF('dlgEditCotizacion').hide()");
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Cotizacion no Actualizado"));
        }
    }

    public CotizacionControlador() {
    }

    public void agregarListaNewCotDet(Productos idProductos) {
        try {
            
            if (this.isEditing){
                this.agregarListaEditCotDet(idProductos);
                return;
            }
            
            tarifario = tarifarioFacade.obtenerTarifaByProducto(idProductos.getProductosPK().getIdCategoria(), idProductos.getProductosPK().getIdProducto());
            if (tarifario != null) {
                this.listaCotizacionesDetNew.
                        add(new Detallecotizacion(new DetallecotizacionPK(0, 0), idProductos,
                                        tarifario.getPreciomax(), 1, idProductos.getCategorias()));
                calcularCostos();
                productosControlador.getListaProductos().remove(idProductos);
                RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:tblProductos");
                RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:tblDetCot");

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Producto Agregado"));

            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Correcto", "Producto No Agregado por no tener tarifa asignada"));

            }

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Producto no Adicionado"));
        }
    }

    public void removerListaNewCotDet(Detallecotizacion idDetalleCot) {
        try {
            //int i=0; PARA RESOLVER ESTE ERROR ADICIONAR IDCATEGORIA A LA TABLA DETALLECOTIZAVION
            for (Detallecotizacion dtCot : this.listaCotizacionesDetNew) {
                if (dtCot == idDetalleCot) {
                    this.listaCotizacionesDetNew.remove(dtCot);

                    break;
                }
            }
            this.calcularCostos();
            this.producto = productosFacade.obtenerProducto(idDetalleCot.getIdCategoria().getIdCategoria(),
                    idDetalleCot.getProductos().getProductosPK().getIdProducto());
            productosControlador.getListaProductos().add(this.producto);
            RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:tblProductos");
            RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:tblDetCot");
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Correcto", "Item Removido"));

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", ex.getMessage()));
        }
    }

    public void calcularCostos() {
        try {

            double totalFactura = 0;
            for (Detallecotizacion dtCot : this.listaCotizacionesDetNew) {
                double valorItem = 0;
                double valorItemxfila = 0;

                valorItem = dtCot.getCantidad() * dtCot.getPrecio();
                valorTotalfila = valorItem;
                RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:total");

                totalFactura += (valorItem);
            }
            this.valorTotal = totalFactura;
            if (this.cotizacion.getIdEvento()!=null) {
                this.cotizacion.getIdEvento().setCosto(valorTotal);
            }
            RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:totalcotizacion");
            

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", ex.getMessage()));
        }
    }

    public double calcularCostosfila(int cantidad, double precio) {
        calcularCostos();
        valorTotalfila = cantidad * precio;
        return valorTotalfila;

    }

    public String contarCotisxEventoId(int idevento) {
        return cotizacionesFacade.contarCotisxEventoId(idevento);
    }

    public void cargarCotizacionesXevento(SelectEvent eventos) {
        totalevento = 0.00;
        evento = (Eventos) eventos.getObject();
        listaCotizacionesXevento = cotizacionesFacade.cotizacionesPorEvento(evento.getIdEvento());
    }

    public double calculatotalcotizacion(int idCotizacion) {
        double total = 0.00;
        total = detalleCotizacionFacade.TotalDetalleCotizacionxId(idCotizacion);

        return total;
    }

    public void cargarDetalleCotizacion(Cotizaciones cotizaciones) {
        this.cotizacion = cotizaciones;
        this.isEditing = Boolean.TRUE;

        listaCotizacionesDetEdit = detalleCotizacionFacade.buscarDetalleCotizacionxId(cotizacion.getIdCotizacion());

        RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:taddCotizacion");
    }

    public void agregarListaEditCotDet(Productos idProductos) {
        try {
            tarifario = tarifarioFacade.obtenerTarifaByProducto(idProductos.getProductosPK().getIdCategoria(), idProductos.getProductosPK().getIdProducto());
            if (tarifario != null) {
                this.listaCotizacionesDetEdit.
                        add(new Detallecotizacion(new DetallecotizacionPK(0, this.cotizacion.getIdCotizacion()),
                                        idProductos, tarifario.getPreciomax(), 1, idProductos.getCategorias()));

                productosControlador.getListaProductos().remove(idProductos);
                calcularCostosEdit();
                RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:tblProductos");
                RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:tbleditdetcot");

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Correcto", "Producto Agregado"));

            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Correcto", "Producto No Agregado por no tener tarifa asignada"));

            }

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Producto no Adicionado" + ex.getMessage()));
        }
    }

    public void removerListaEditCotDet(Detallecotizacion idDetalleCot) {
        try {
            //int i=0; PARA RESOLVER ESTE ERROR ADICIONAR IDCATEGORIA A LA TABLA DETALLECOTIZACION
            for (Detallecotizacion dtCot : this.listaCotizacionesDetEdit) {
                if (dtCot == idDetalleCot) {
                    this.listaCotizacionesDetEdit.remove(dtCot);

                    break;
                }
            }
            this.calcularCostosEdit();
            this.producto = productosFacade.obtenerProducto(idDetalleCot.getIdCategoria().getIdCategoria(),
                    idDetalleCot.getProductos().getProductosPK().getIdProducto());
            productosControlador.getListaProductos().add(this.producto);
                RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:tblProductos");
                RequestContext.getCurrentInstance().update("frmCotizacion:acCotizacion:tbleditdetcot");
            RequestContext.getCurrentInstance().update("frmCotizacion:pnlAddCotizacion:costo");
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Correcto", "Item Removido"));

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", ex.getMessage()));
        }
    }

    public double calcularCostosEdit() {
        try {

            double totalFactura = 0;
            for (Detallecotizacion dtCot : this.listaCotizacionesDetEdit) {
                double valorItem = 0;
                double valorItemxfila = 0;

                valorItem = dtCot.getCantidad() * dtCot.getPrecio();
                valorTotalfila = valorItem;

                totalFactura += (valorItem);
            }
            this.valorTotal = totalFactura;
            return valorTotal;

        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", ex.getMessage()));
            return 0.00;
        }
    }

    public double CostoPorEvento(int idevento) {
        double totalxevento = 0.00;
        listaCotizacionesXevento = cotizacionesFacade.cotizacionesPorEvento(idevento);
        for (Cotizaciones c : listaCotizacionesXevento) {
            totalxevento += calculatotalcotizacion(c.getIdCotizacion());
        }
        return totalxevento;
    }

    public String obtenerTarifaByProducto(Productos producto) {
        String tooltip;
        tarifario = tarifarioFacade
                .obtenerTarifaByProducto(producto.getProductosPK().getIdCategoria(),
                        producto.getProductosPK().getIdProducto());

        if (tarifario != null) {
            tooltip = "- Precio Min $:"
                    + tarifario.getPreciomin()
                    + "\n- Precio Ideal $: "
                    + tarifario.getPrecioideal()
                    + "\n- Precio Max $: "
                    + tarifario.getPreciomax();
        } else {
            tooltip = "Este producto no tiene tarifa asignada";
        }

        return tooltip;
    }

    public Productos getProducto() {
        return producto;
    }

    public void setProducto(Productos producto) {
        this.producto = producto;
    }

    public Eventos getEvento() {
        return evento;
    }

    public void setEvento(Eventos evento) {
        this.evento = evento;
    }

    public Clientes getCliente() {
        return cliente;
    }

    public void setCliente(Clientes cliente) {
        this.cliente = cliente;
    }

    public Cotizaciones getCotizacion() {
        return cotizacion;
    }

    public void setCotizacion(Cotizaciones cotizacion) {
        this.cotizacion = cotizacion;
    }

    public List<Cotizaciones> getListaCotizaciones() {
        return listaCotizaciones;
    }

    public void setListaCotizaciones(List<Cotizaciones> listaCotizaciones) {
        this.listaCotizaciones = listaCotizaciones;
    }

    public List<Cotizaciones> getListaCotizacionesFiltrada() {
        return listaCotizacionesFiltrada;
    }

    public void setListaCotizacionesFiltrada(List<Cotizaciones> listaCotizacionesFiltrada) {
        this.listaCotizacionesFiltrada = listaCotizacionesFiltrada;
    }

    public List<Cotizaciones> getListaCotizacionesXevento() {
        return listaCotizacionesXevento;
    }

    public void setListaCotizacionesXevento(List<Cotizaciones> listaCotizacionesXevento) {
        this.listaCotizacionesXevento = listaCotizacionesXevento;
    }

    public Detallecotizacion getCotizacionDet() {
        return cotizacionDet;
    }

    public void setCotizacionDet(Detallecotizacion cotizacionDet) {
        this.cotizacionDet = cotizacionDet;
    }

    public double getTotalevento() {
        return totalevento;
    }

    public void setTotalevento(double totalevento) {
        this.totalevento = totalevento;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public double getValorTotalfila() {
        return valorTotalfila;
    }

    public void setValorTotalfila(double valorTotalfila) {
        this.valorTotalfila = valorTotalfila;
    }

    public List<Detallecotizacion> getListaCotizacionesDet() {
        return listaCotizacionesDet;
    }

    public void setListaCotizacionesDet(List<Detallecotizacion> listaCotizacionesDet) {
        this.listaCotizacionesDet = listaCotizacionesDet;
    }

    public List<Detallecotizacion> getListaCotizacionesDetFiltrada() {
        return listaCotizacionesDetFiltrada;
    }

    public void setListaCotizacionesDetFiltrada(List<Detallecotizacion> listaCotizacionesDetFiltrada) {
        this.listaCotizacionesDetFiltrada = listaCotizacionesDetFiltrada;
    }

    public List<Detallecotizacion> getListaCotizacionesDetNew() {
        return listaCotizacionesDetNew;
    }

    public void setListaCotizacionesDetNew(List<Detallecotizacion> listaCotizacionesDetNew) {
        this.listaCotizacionesDetNew = listaCotizacionesDetNew;
    }

    public List<Detallecotizacion> getListaCotizacionesDetEdit() {
        return listaCotizacionesDetEdit;
    }

    public void setListaCotizacionesDetEdit(List<Detallecotizacion> listaCotizacionesDetEdit) {
        this.listaCotizacionesDetEdit = listaCotizacionesDetEdit;
    }

    public Date getFechaHoy() {
        return FechaHoy;
    }

    public void setFechaHoy(Date FechaHoy) {
        this.FechaHoy = FechaHoy;
    }

    public Tarifario getTarifario() {
        return tarifario;
    }

    public void setTarifario(Tarifario tarifario) {
        this.tarifario = tarifario;
    }

    public ProductosControlador getProductosControlador() {
        return productosControlador;
    }

    public void setProductosControlador(ProductosControlador productosControlador) {
        this.productosControlador = productosControlador;
    }

    public EventosControlador getEventosControlador() {
        return eventosControlador;
    }

    public void setEventosControlador(EventosControlador eventosControlador) {
        this.eventosControlador = eventosControlador;
    }

    public ClienteControlador getClienteControlador() {
        return clienteControlador;
    }

    public void setClienteControlador(ClienteControlador clienteControlador) {
        this.clienteControlador = clienteControlador;
    }

    public SeguridadControlador getSeguridadControlador() {
        return seguridadControlador;
    }

    public void setSeguridadControlador(SeguridadControlador seguridadControlador) {
        this.seguridadControlador = seguridadControlador;
    }

    public Boolean getIsEditing() {
        return isEditing;
    }

    public void setIsEditing(Boolean isEditing) {
        this.isEditing = isEditing;
    }

}
