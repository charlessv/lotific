/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Usuarios;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Carlos
 */
@Stateless
public class UsuariosFacade extends AbstractFacade<Usuarios> {
    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UsuariosFacade() {
        super(Usuarios.class);
    }
    
    public Usuarios getUsuarioByLogin(String login) throws Exception {
        try {
            Query query = em.createQuery("Select u From Usuarios u where u.login=?1");

            query.setParameter(1, login);
            return (Usuarios) query.getSingleResult();

        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }
    }
    
    public Usuarios getLoginByIdUsuario(String login, int idUsuario){
        try {
            
            Query query = em.createQuery("Select u From Usuarios u where u.login=?1 "
                    + "and u.idUsuario!=?2");

            query.setParameter(1, login);
            query.setParameter(2, idUsuario);
            return (Usuarios) query.getSingleResult();

        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }
        
    }
    
    public int calcularId() {
       Query query = em.createQuery("SELECT coalesce(MAX(u.idUsuario)+1,1) FROM Usuarios u");

        return Integer.parseInt(query.getSingleResult().toString());
     
    }
    
}
