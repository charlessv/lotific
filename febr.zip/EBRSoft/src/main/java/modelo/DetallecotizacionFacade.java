/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Detallecotizacion;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Carlos
 */
@Stateless
public class DetallecotizacionFacade extends AbstractFacade<Detallecotizacion> {
    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DetallecotizacionFacade() {
        super(Detallecotizacion.class);
    }
    
    
    public List<Detallecotizacion> buscarDetalleCotizacionxId(int idcotizacion) {
        Query query = em.createQuery("SELECT d FROM Detallecotizacion d "
                + "WHERE d.detallecotizacionPK.idCotizacion = ?1");
        query.setParameter(1, idcotizacion);
        return query.getResultList();
    }

    public double TotalDetalleCotizacionxId(int idcotizacion) {
        try {
            Query query = em.createQuery("SELECT sum(d.cantidad*d.precio) FROM Detallecotizacion d "
                    + "WHERE d.detallecotizacionPK.idCotizacion =?1");
            query.setParameter(1, idcotizacion);
            return Double.parseDouble(query.getSingleResult().toString());
        } catch (Exception ex) {
            return Double.parseDouble("0.00");

        }
    }
    
            

    public double TotalEventoxId(int idcotizacion) {
        try {
            Query query = em.createQuery("SELECT sum(d.cantidad*d.precio) FROM Detallecotizacion d WHERE d.detallecotizacionPK.idCotizacion =?1");
            query.setParameter(1, idcotizacion);
            return Double.parseDouble(query.getSingleResult().toString());
        } catch (Exception ex) {
            return Double.parseDouble("0.00");

        }
    }

    
    public void EliminarDetallexId(int idcotizacion) {
        try {
            Query query = em.createQuery("delete  FROM Detallecotizacion d WHERE d.detallecotizacionPK.idCotizacion =?1");
            query.setParameter(1, idcotizacion);
              query.executeUpdate();
        } catch (Exception ex) {
              

        }
    }
}