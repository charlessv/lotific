/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Clientes;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Carlos
 */
@Stateless
public class ClientesFacade extends AbstractFacade<Clientes> {

    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ClientesFacade() {
        super(Clientes.class);
    }

    public Clientes buscarClienteporid(int idCliente) {
        try {
            Query query = em.createNamedQuery("Clientes.findByIdCliente");
            query.setParameter("idCliente", idCliente);
            return (Clientes) query.getSingleResult();

        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }

    }
    
    public Clientes findCustomerByName(String nombre) {
        try {
            Query query = em.createNamedQuery("Clientes.findByNombres");
            query.setParameter("nombres", nombre);
            return (Clientes) query.getSingleResult();

        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }

    }
}
