/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Roles;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Carlos
 */
@Stateless
public class RolesFacade extends AbstractFacade<Roles> {
    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public RolesFacade() {
        super(Roles.class);
    }
    
    public int calcularId() {
        try{
        Query query = em.createQuery("SELECT coalesce(MAX(r.idRol)+1,1) FROM Roles r");

        return Integer.parseInt(query.getSingleResult().toString());
        
        } catch (NonUniqueResultException | NoResultException ex) {
            return 1;
        }
    }
    
    public Roles getRolById(int idRoles){
        
     try{   
        Query query=em.createQuery("Select r from Roles r "
                + "where r.idRol=?1");
        
        query.setParameter(1, idRoles);
        
        return (Roles) query.getSingleResult();
        
      } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }   
    }
    
}
