/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Facturacionxpagar;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

/**
 *
 * @author Carlos
 */
@Stateless
public class FacturacionxpagarFacade extends AbstractFacade<Facturacionxpagar> {
    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public FacturacionxpagarFacade() {
        super(Facturacionxpagar.class);
    }
    
    public Facturacionxpagar buscarComprobante(String idComprobante, int idTipoComprobante, int idProveedor) {
        try {
            Query query = em.createQuery("select f from Facturacionxpagar f "
                    + " where  f.facturacionxpagarPK.idfactura=?1 "
                    + "and f.facturacionxpagarPK.idtdocumento=?2 "
                    + "and f.facturacionxpagarPK.idproveedor=?3");
            
            query.setParameter(1,idComprobante);
            query.setParameter(2, idTipoComprobante);
            query.setParameter(3, idProveedor);

            return (Facturacionxpagar) query.getSingleResult();
        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }
    }
   
    public List<Facturacionxpagar> comprobantes(){
        try {
            Query query = em.createQuery("select f from Facturacionxpagar f "
                    + "order by f.facturacionxpagarPK.idproveedor");
            
            return query.getResultList();
        } catch (Exception ex) {
            return null;
        }
        
    }
    
    public List<Facturacionxpagar> listarComprobantes() {
        try {
            Query query = em.createQuery("select f from Facturacionxpagar f "
                    + " where f.facturacionxpagarPK.idtdocumento!=0 "
                    + "and f.credito=true and f.estado=0 "
                    + "order by f.facturacionxpagarPK.idproveedor");
            
            return query.getResultList();
        } catch (Exception ex) {
            return null;
        }
    }
    
    public List<Facturacionxpagar> listarComprobantesRangoFecha(Date fechaInicial, Date fechaFinal) {
        try {
            Query query = em.createQuery("select f from Facturacionxpagar f "
                    + " where f.facturacionxpagarPK.idtdocumento!=0 "
                    + "and f.fechaingreso>=?1 "
                    + "and f.fechaingreso<=?2 "
                    + "and f.credito=false and f.estado=0 "
                    + "order by f.facturacionxpagarPK.idproveedor");
            
            query.setParameter(1, fechaInicial,TemporalType.DATE);
            query.setParameter(2, fechaFinal,TemporalType.DATE);
            return query.getResultList();
        } catch (Exception ex) {
            return null;
        }
    }
    
    
    public List<Facturacionxpagar> obtenerComprobantesporQuedan(String idQuedan) {
        try {
            Query query = em.createQuery("select fp from Facturacionxpagar fp "
                    + " where fp.idquedan=?1 ");
            
            query.setParameter(1, idQuedan);
            
            return query.getResultList();
        } catch (Exception ex) {
            return null;
        }
    }
    
}
