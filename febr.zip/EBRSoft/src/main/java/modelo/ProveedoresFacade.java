/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Proveedores;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Carlos
 */
@Stateless
public class ProveedoresFacade extends AbstractFacade<Proveedores> {
    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProveedoresFacade() {
        super(Proveedores.class);
    }
    
    public Proveedores buscarProveedor(String nombre) {
        try {
            Query query = em.createQuery("select p from Proveedores p where p.razonsocial=?1");
            query.setParameter(1, nombre);

            return (Proveedores) query.getSingleResult();

        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }

    }

}
