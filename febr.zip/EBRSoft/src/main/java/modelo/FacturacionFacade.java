/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import entidades.Eventos;
import entidades.Facturacion;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

/**
 *
 * @author Carlos
 */
@Stateless
public class FacturacionFacade extends AbstractFacade<Facturacion> {

    @PersistenceContext(unitName = "MediaSolutionsPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public FacturacionFacade() {
        super(Facturacion.class);
    }

    public Facturacion buscarComprobante(String idComprobante, int idTipoComprobante, int idCliente) {
        try {
            Query query = em.createQuery("select f from Facturacion f "
                    + " where  f.facturacionPK.idfactura=?1 "
                    + "and f.facturacionPK.idtdocumento=?2 "
                    + "and f.facturacionPK.idCliente=?3");
            
            query.setParameter(1,idComprobante);
            query.setParameter(2, idTipoComprobante);
            query.setParameter(3, idCliente);

            return (Facturacion) query.getSingleResult();
        } catch (NonUniqueResultException | NoResultException ex) {
            return null;
        }
    }
    
    public List<Facturacion> comprobantes(){
        try {
            Query query = em.createQuery("select f from Facturacion f "
                    + "order by f.facturacionPK.idCliente");
            
            return query.getResultList();
        } catch (Exception ex) {
            return null;
        }
        
    }
    
    public List<Facturacion> listarComprobantes() {
        try {
            Query query = em.createQuery("select f from Facturacion f "
                    + " where f.facturacionPK.idtdocumento!=0 "
                    + "and f.credito=true and f.estado=0 "
                    + "order by f.facturacionPK.idCliente");
            
            return query.getResultList();
        } catch (Exception ex) {
            return null;
        }
    }
    
    public List<Facturacion> listarComprobantesRangoFecha(char rubro, Date fechaInicial, Date fechaFinal) {
        try {
            Query query = em.createQuery("select f from Facturacion f "
                    + " where f.facturacionPK.idtdocumento!=0 "
                    + "and f.fechaingreso>=?2 "
                    + "and f.fechaingreso<=?3 "
                    + "and f.credito=true and f.estado=0 "
                    + "order by f.facturacionPK.idCliente");
            
            query.setParameter(1, rubro);
            query.setParameter(2, fechaInicial,TemporalType.DATE);
            query.setParameter(3, fechaFinal,TemporalType.DATE);
            return query.getResultList();
        } catch (Exception ex) {
            return null;
        }
    }
    
    public Double saldoxEvento(Eventos idEvento){
        try{
            Query query=em.createQuery("select sum(f.monto) from Facturacion f "
                    + " where f.idEvento.idEvento=?1");
            
           query.setParameter(1, idEvento.getIdEvento());
           
           return Double.parseDouble(query.getSingleResult().toString());
            
        }catch (NonUniqueResultException | NoResultException ex) {
            return 0d;
        }
        
    }
    
    public List<Facturacion> obtenerComprobantesporQuedan(String idQuedan) {
        try {
            Query query = em.createQuery("select f from Facturacion f "
                    + " where f.idquedan=?1 ");
            
            query.setParameter(1, idQuedan);
            
            return query.getResultList();
        } catch (Exception ex) {
            return null;
        }
    }
    
    
}
