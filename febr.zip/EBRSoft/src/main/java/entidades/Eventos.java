/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

/**
 *
 * @author Carlos
 */
@Entity
@Table(name = "eventos")
@NamedQueries({
    @NamedQuery(name = "Eventos.findAll", query = "SELECT e FROM Eventos e"),
    @NamedQuery(name = "Eventos.findByIdEvento", query = "SELECT e FROM Eventos e WHERE e.idEvento = :idEvento"),
    @NamedQuery(name = "Eventos.findByCancelado", query = "SELECT e FROM Eventos e WHERE e.cancelado = :cancelado"),
    @NamedQuery(name = "Eventos.findByCosto", query = "SELECT e FROM Eventos e WHERE e.costo = :costo"),
    @NamedQuery(name = "Eventos.findByEncargado", query = "SELECT e FROM Eventos e WHERE e.encargado = :encargado"),
    @NamedQuery(name = "Eventos.findByEstado", query = "SELECT e FROM Eventos e WHERE e.estado = :estado"),
    @NamedQuery(name = "Eventos.findByFechafin", query = "SELECT e FROM Eventos e WHERE e.fechafin = :fechafin"),
    @NamedQuery(name = "Eventos.findByFechainicio", query = "SELECT e FROM Eventos e WHERE e.fechainicio = :fechainicio"),
    @NamedQuery(name = "Eventos.findByFechamontajefin", query = "SELECT e FROM Eventos e WHERE e.fechamontajefin = :fechamontajefin"),
    @NamedQuery(name = "Eventos.findByFechamontajeinicio", query = "SELECT e FROM Eventos e WHERE e.fechamontajeinicio = :fechamontajeinicio"),
    @NamedQuery(name = "Eventos.findByHorafin", query = "SELECT e FROM Eventos e WHERE e.horafin = :horafin"),
    @NamedQuery(name = "Eventos.findByHorainicio", query = "SELECT e FROM Eventos e WHERE e.horainicio = :horainicio"),
    @NamedQuery(name = "Eventos.findByHoramontajefin", query = "SELECT e FROM Eventos e WHERE e.horamontajefin = :horamontajefin"),
    @NamedQuery(name = "Eventos.findByHoramontajeinicio", query = "SELECT e FROM Eventos e WHERE e.horamontajeinicio = :horamontajeinicio"),
    @NamedQuery(name = "Eventos.findByNombre", query = "SELECT e FROM Eventos e WHERE e.nombre = :nombre"),
    @NamedQuery(name = "Eventos.findByObservaciones", query = "SELECT e FROM Eventos e WHERE e.observaciones = :observaciones"),
    @NamedQuery(name = "Eventos.findByTransporte", query = "SELECT e FROM Eventos e WHERE e.transporte = :transporte"),
    @NamedQuery(name = "Eventos.findByLugar", query = "SELECT e FROM Eventos e WHERE e.lugar = :lugar")})
public class Eventos implements Serializable {
    @OneToMany(mappedBy = "idEvento")
    private List<Cotizaciones> cotizacionesList;
    @OneToMany(mappedBy = "idEvento")
    private List<Facturacion> facturacionList;
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_evento")
    private Integer idEvento;
    @Column(name = "cancelado")
    private Boolean cancelado;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "costo")
    private Double costo;
    @Size(max = 255)
    @Column(name = "encargado")
    private String encargado;
    @Column(name = "estado")
    private Integer estado;
    @Column(name = "fechafin")
    @Temporal(TemporalType.DATE)
    private Date fechafin;
    @Column(name = "fechainicio")
    @Temporal(TemporalType.DATE)
    private Date fechainicio;
    @Column(name = "fechamontajefin")
    @Temporal(TemporalType.DATE)
    private Date fechamontajefin;
    @Column(name = "fechamontajeinicio")
    @Temporal(TemporalType.DATE)
    private Date fechamontajeinicio;
    @Column(name = "horafin")
    @Temporal(TemporalType.TIME)
    private Date horafin;
    @Column(name = "horainicio")
    @Temporal(TemporalType.TIME)
    private Date horainicio;
    @Column(name = "horamontajefin")
    @Temporal(TemporalType.TIME)
    private Date horamontajefin;
    @Column(name = "horamontajeinicio")
    @Temporal(TemporalType.TIME)
    private Date horamontajeinicio;
    @Size(max = 255)
    @Column(name = "nombre")
    private String nombre;
    @Size(max = 255)
    @Column(name = "observaciones")
    private String observaciones;
    @Size(max = 255)
    @Column(name = "transporte")
    private String transporte;
    @Size(max = 300)
    @Column(name = "lugar")
    private String lugar;
    @JoinColumn(name = "id_cliente", referencedColumnName = "id_cliente")
    @ManyToOne
    private Clientes idCliente;

    public Eventos() {
    }

    public Eventos(Integer idEvento) {
        this.idEvento = idEvento;
    }

    public Integer getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(Integer idEvento) {
        this.idEvento = idEvento;
    }

    public Boolean getCancelado() {
        return cancelado;
    }

    public void setCancelado(Boolean cancelado) {
        this.cancelado = cancelado;
    }

    public Double getCosto() {
        return costo;
    }

    public void setCosto(Double costo) {
        this.costo = costo;
    }

    public String getEncargado() {
        return encargado;
    }

    public void setEncargado(String encargado) {
        this.encargado = encargado;
    }

    public Integer getEstado() {
        return estado;
    }

    public void setEstado(Integer estado) {
        this.estado = estado;
    }

    public Date getFechafin() {
        return fechafin;
    }

    public void setFechafin(Date fechafin) {
        this.fechafin = fechafin;
    }

    public Date getFechainicio() {
        return fechainicio;
    }

    public void setFechainicio(Date fechainicio) {
        this.fechainicio = fechainicio;
    }

    public Date getFechamontajefin() {
        return fechamontajefin;
    }

    public void setFechamontajefin(Date fechamontajefin) {
        this.fechamontajefin = fechamontajefin;
    }

    public Date getFechamontajeinicio() {
        return fechamontajeinicio;
    }

    public void setFechamontajeinicio(Date fechamontajeinicio) {
        this.fechamontajeinicio = fechamontajeinicio;
    }

    public Date getHorafin() {
        return horafin;
    }

    public void setHorafin(Date horafin) {
        this.horafin = horafin;
    }

    public Date getHorainicio() {
        return horainicio;
    }

    public void setHorainicio(Date horainicio) {
        this.horainicio = horainicio;
    }

    public Date getHoramontajefin() {
        return horamontajefin;
    }

    public void setHoramontajefin(Date horamontajefin) {
        this.horamontajefin = horamontajefin;
    }

    public Date getHoramontajeinicio() {
        return horamontajeinicio;
    }

    public void setHoramontajeinicio(Date horamontajeinicio) {
        this.horamontajeinicio = horamontajeinicio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getTransporte() {
        return transporte;
    }

    public void setTransporte(String transporte) {
        this.transporte = transporte;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public Clientes getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Clientes idCliente) {
        this.idCliente = idCliente;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEvento != null ? idEvento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Eventos)) {
            return false;
        }
        Eventos other = (Eventos) object;
        if ((this.idEvento == null && other.idEvento != null) || (this.idEvento != null && !this.idEvento.equals(other.idEvento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Eventos[ idEvento=" + idEvento + " ]";
    }

    public List<Facturacion> getFacturacionList() {
        return facturacionList;
    }

    public void setFacturacionList(List<Facturacion> facturacionList) {
        this.facturacionList = facturacionList;
    }

    public List<Cotizaciones> getCotizacionesList() {
        return cotizacionesList;
    }

    public void setCotizacionesList(List<Cotizaciones> cotizacionesList) {
        this.cotizacionesList = cotizacionesList;
    }
    
}
