/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author cc90930
 */
@Embeddable
public class FacturacionPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "idfactura")
    private String idfactura;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idtdocumento")
    private int idtdocumento;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idCliente")
    private int idCliente;

    public FacturacionPK() {
    }

    public FacturacionPK(String idfactura, int idtdocumento, int idCliente) {
        this.idfactura = idfactura;
        this.idtdocumento = idtdocumento;
        this.idCliente = idCliente;
    }

    public String getIdfactura() {
        return idfactura;
    }

    public void setIdfactura(String idfactura) {
        this.idfactura = idfactura;
    }

    public int getIdtdocumento() {
        return idtdocumento;
    }

    public void setIdtdocumento(int idtdocumento) {
        this.idtdocumento = idtdocumento;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idfactura != null ? idfactura.hashCode() : 0);
        hash += (int) idtdocumento;
        hash += (int) idCliente;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FacturacionPK)) {
            return false;
        }
        FacturacionPK other = (FacturacionPK) object;
        if ((this.idfactura == null && other.idfactura != null) || (this.idfactura != null && !this.idfactura.equals(other.idfactura))) {
            return false;
        }
        if (this.idtdocumento != other.idtdocumento) {
            return false;
        }
        if (this.idCliente != other.idCliente) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.FacturacionPK[ idfactura=" + idfactura + ", idtdocumento=" + idtdocumento + ", idCliente=" + idCliente + " ]";
    }
    
}
