/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 *
 * @author Carlos
 */
@Entity
@Table(name = "auxdetparam")
@NamedQueries({
    @NamedQuery(name = "Auxdetparam.findAll", query = "SELECT a FROM Auxdetparam a"),
    @NamedQuery(name = "Auxdetparam.findByValaux", query = "SELECT a FROM Auxdetparam a WHERE a.valaux = :valaux"),
    @NamedQuery(name = "Auxdetparam.findByDescripcion", query = "SELECT a FROM Auxdetparam a WHERE a.auxdetparamPK.descripcion = :descripcion"),
    @NamedQuery(name = "Auxdetparam.findByCodigo", query = "SELECT a FROM Auxdetparam a WHERE a.auxdetparamPK.codigo = :codigo"),
    @NamedQuery(name = "Auxdetparam.findByEstado", query = "SELECT a FROM Auxdetparam a WHERE a.auxdetparamPK.estado = :estado"),
    @NamedQuery(name = "Auxdetparam.findByCatalogo", query = "SELECT a FROM Auxdetparam a WHERE a.auxdetparamPK.catalogo = :catalogo")})
public class Auxdetparam implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected AuxdetparamPK auxdetparamPK;
    @Size(max = 255)
    @Column(name = "valaux")
    private String valaux;

    public Auxdetparam() {
    }

    public Auxdetparam(AuxdetparamPK auxdetparamPK) {
        this.auxdetparamPK = auxdetparamPK;
    }

    public Auxdetparam(String descripcion, int codigo, boolean estado, int catalogo) {
        this.auxdetparamPK = new AuxdetparamPK(descripcion, codigo, estado, catalogo);
    }

    public AuxdetparamPK getAuxdetparamPK() {
        return auxdetparamPK;
    }

    public void setAuxdetparamPK(AuxdetparamPK auxdetparamPK) {
        this.auxdetparamPK = auxdetparamPK;
    }

    public String getValaux() {
        return valaux;
    }

    public void setValaux(String valaux) {
        this.valaux = valaux;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (auxdetparamPK != null ? auxdetparamPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Auxdetparam)) {
            return false;
        }
        Auxdetparam other = (Auxdetparam) object;
        if ((this.auxdetparamPK == null && other.auxdetparamPK != null) || (this.auxdetparamPK != null && !this.auxdetparamPK.equals(other.auxdetparamPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Auxdetparam[ auxdetparamPK=" + auxdetparamPK + " ]";
    }
    
}
