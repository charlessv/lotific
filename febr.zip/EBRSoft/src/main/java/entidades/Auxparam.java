/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 *
 * @author Carlos
 */
@Entity
@Table(name = "auxparam")
@NamedQueries({
    @NamedQuery(name = "Auxparam.findAll", query = "SELECT a FROM Auxparam a"),
    @NamedQuery(name = "Auxparam.findByTabla", query = "SELECT a FROM Auxparam a WHERE a.tabla = :tabla"),
    @NamedQuery(name = "Auxparam.findByEstado", query = "SELECT a FROM Auxparam a WHERE a.auxparamPK.estado = :estado"),
    @NamedQuery(name = "Auxparam.findById", query = "SELECT a FROM Auxparam a WHERE a.auxparamPK.id = :id")})
public class Auxparam implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected AuxparamPK auxparamPK;
    @Size(max = 255)
    @Column(name = "tabla")
    private String tabla;

    public Auxparam() {
    }

    public Auxparam(AuxparamPK auxparamPK) {
        this.auxparamPK = auxparamPK;
    }

    public Auxparam(boolean estado, int id) {
        this.auxparamPK = new AuxparamPK(estado, id);
    }

    public AuxparamPK getAuxparamPK() {
        return auxparamPK;
    }

    public void setAuxparamPK(AuxparamPK auxparamPK) {
        this.auxparamPK = auxparamPK;
    }

    public String getTabla() {
        return tabla;
    }

    public void setTabla(String tabla) {
        this.tabla = tabla;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (auxparamPK != null ? auxparamPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Auxparam)) {
            return false;
        }
        Auxparam other = (Auxparam) object;
        if ((this.auxparamPK == null && other.auxparamPK != null) || (this.auxparamPK != null && !this.auxparamPK.equals(other.auxparamPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Auxparam[ auxparamPK=" + auxparamPK + " ]";
    }
    
}
