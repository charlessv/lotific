/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Carlos
 */
@Embeddable
public class DetallecotizacionPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_detallecotizacion")
    private int idDetallecotizacion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_cotizacion")
    private int idCotizacion;

    public DetallecotizacionPK() {
    }

    public DetallecotizacionPK(int idDetallecotizacion, int idCotizacion) {
        this.idDetallecotizacion = idDetallecotizacion;
        this.idCotizacion = idCotizacion;
    }

    public int getIdDetallecotizacion() {
        return idDetallecotizacion;
    }

    public void setIdDetallecotizacion(int idDetallecotizacion) {
        this.idDetallecotizacion = idDetallecotizacion;
    }

    public int getIdCotizacion() {
        return idCotizacion;
    }

    public void setIdCotizacion(int idCotizacion) {
        this.idCotizacion = idCotizacion;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idDetallecotizacion;
        hash += (int) idCotizacion;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DetallecotizacionPK)) {
            return false;
        }
        DetallecotizacionPK other = (DetallecotizacionPK) object;
        if (this.idDetallecotizacion != other.idDetallecotizacion) {
            return false;
        }
        if (this.idCotizacion != other.idCotizacion) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.DetallecotizacionPK[ idDetallecotizacion=" + idDetallecotizacion + ", idCotizacion=" + idCotizacion + " ]";
    }
    
}
