/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author cc90930
 */
@Embeddable
public class FacturacionxpagarPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "idfactura")
    private String idfactura;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idtdocumento")
    private int idtdocumento;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idproveedor")
    private int idproveedor;

    public FacturacionxpagarPK() {
    }

    public FacturacionxpagarPK(String idfactura, int idtdocumento, int idproveedor) {
        this.idfactura = idfactura;
        this.idtdocumento = idtdocumento;
        this.idproveedor = idproveedor;
    }

    public String getIdfactura() {
        return idfactura;
    }

    public void setIdfactura(String idfactura) {
        this.idfactura = idfactura;
    }

    public int getIdtdocumento() {
        return idtdocumento;
    }

    public void setIdtdocumento(int idtdocumento) {
        this.idtdocumento = idtdocumento;
    }

    public int getIdproveedor() {
        return idproveedor;
    }

    public void setIdproveedor(int idproveedor) {
        this.idproveedor = idproveedor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idfactura != null ? idfactura.hashCode() : 0);
        hash += (int) idtdocumento;
        hash += (int) idproveedor;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FacturacionxpagarPK)) {
            return false;
        }
        FacturacionxpagarPK other = (FacturacionxpagarPK) object;
        if ((this.idfactura == null && other.idfactura != null) || (this.idfactura != null && !this.idfactura.equals(other.idfactura))) {
            return false;
        }
        if (this.idtdocumento != other.idtdocumento) {
            return false;
        }
        if (this.idproveedor != other.idproveedor) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.FacturacionxpagarPK[ idfactura=" + idfactura + ", idtdocumento=" + idtdocumento + ", idproveedor=" + idproveedor + " ]";
    }
    
}
