/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

/**
 *
 * @author Carlos
 */
@Entity
@Table(name = "pagos_factura")
@NamedQueries({
    @NamedQuery(name = "PagosFactura.findAll", query = "SELECT p FROM PagosFactura p"),
    @NamedQuery(name = "PagosFactura.findByIdpago", query = "SELECT p FROM PagosFactura p WHERE p.pagosFacturaPK.idpago = :idpago"),
    @NamedQuery(name = "PagosFactura.findByTipodocumento", query = "SELECT p FROM PagosFactura p WHERE p.pagosFacturaPK.tipodocumento = :tipodocumento"),
    @NamedQuery(name = "PagosFactura.findByIdfactura", query = "SELECT p FROM PagosFactura p WHERE p.pagosFacturaPK.idfactura = :idfactura"),
    @NamedQuery(name = "PagosFactura.findByTipopago", query = "SELECT p FROM PagosFactura p WHERE p.tipopago = :tipopago"),
    @NamedQuery(name = "PagosFactura.findByIdCliente", query = "SELECT p FROM PagosFactura p WHERE p.pagosFacturaPK.idCliente = :idCliente"),
    @NamedQuery(name = "PagosFactura.findByReferencia", query = "SELECT p FROM PagosFactura p WHERE p.referencia = :referencia"),
    @NamedQuery(name = "PagosFactura.findByMonto", query = "SELECT p FROM PagosFactura p WHERE p.monto = :monto"),
    @NamedQuery(name = "PagosFactura.findByFechapago", query = "SELECT p FROM PagosFactura p WHERE p.fechapago = :fechapago"),
    @NamedQuery(name = "PagosFactura.findByFecharegistropago", query = "SELECT p FROM PagosFactura p WHERE p.fecharegistropago = :fecharegistropago")})
public class PagosFactura implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PagosFacturaPK pagosFacturaPK;
    @Column(name = "tipopago")
    private Integer tipopago;
    @Size(max = 255)
    @Column(name = "referencia")
    private String referencia;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "monto")
    private Double monto;
    @Column(name = "fechapago")
    @Temporal(TemporalType.DATE)
    private Date fechapago;
    @Column(name = "fecharegistropago")
    @Temporal(TemporalType.DATE)
    private Date fecharegistropago;
    @JoinColumn(name = "idCliente", referencedColumnName = "id_cliente", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Clientes clientes;

    public PagosFactura() {
    }

    public PagosFactura(PagosFacturaPK pagosFacturaPK) {
        this.pagosFacturaPK = pagosFacturaPK;
    }

    public PagosFactura(int idpago, int tipodocumento, String idfactura, int idCliente) {
        this.pagosFacturaPK = new PagosFacturaPK(idpago, tipodocumento, idfactura, idCliente);
    }

    public PagosFacturaPK getPagosFacturaPK() {
        return pagosFacturaPK;
    }

    public void setPagosFacturaPK(PagosFacturaPK pagosFacturaPK) {
        this.pagosFacturaPK = pagosFacturaPK;
    }

    public Integer getTipopago() {
        return tipopago;
    }

    public void setTipopago(Integer tipopago) {
        this.tipopago = tipopago;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }

    public Date getFechapago() {
        return fechapago;
    }

    public void setFechapago(Date fechapago) {
        this.fechapago = fechapago;
    }

    public Date getFecharegistropago() {
        return fecharegistropago;
    }

    public void setFecharegistropago(Date fecharegistropago) {
        this.fecharegistropago = fecharegistropago;
    }

    public Clientes getClientes() {
        return clientes;
    }

    public void setClientes(Clientes clientes) {
        this.clientes = clientes;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pagosFacturaPK != null ? pagosFacturaPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PagosFactura)) {
            return false;
        }
        PagosFactura other = (PagosFactura) object;
        if ((this.pagosFacturaPK == null && other.pagosFacturaPK != null) || (this.pagosFacturaPK != null && !this.pagosFacturaPK.equals(other.pagosFacturaPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.PagosFactura[ pagosFacturaPK=" + pagosFacturaPK + " ]";
    }
    
}
