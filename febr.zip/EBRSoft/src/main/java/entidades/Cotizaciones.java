/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author cc90930
 */
@Entity
@Table(name = "cotizaciones")
@NamedQueries({
    @NamedQuery(name = "Cotizaciones.findAll", query = "SELECT c FROM Cotizaciones c"),
    @NamedQuery(name = "Cotizaciones.findByIdCotizacion", query = "SELECT c FROM Cotizaciones c WHERE c.idCotizacion = :idCotizacion"),
    @NamedQuery(name = "Cotizaciones.findByEstado", query = "SELECT c FROM Cotizaciones c WHERE c.estado = :estado"),
    @NamedQuery(name = "Cotizaciones.findByFechacreacion", query = "SELECT c FROM Cotizaciones c WHERE c.fechacreacion = :fechacreacion"),
    @NamedQuery(name = "Cotizaciones.findByUsuario", query = "SELECT c FROM Cotizaciones c WHERE c.usuario = :usuario"),
    @NamedQuery(name = "Cotizaciones.findByDescuento", query = "SELECT c FROM Cotizaciones c WHERE c.descuento = :descuento")})
public class Cotizaciones implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_cotizacion")
    private Integer idCotizacion;
    @Column(name = "estado")
    private Integer estado;
    @Column(name = "fechacreacion")
    @Temporal(TemporalType.DATE)
    private Date fechacreacion;
    @Size(max = 50)
    @Column(name = "usuario")
    private String usuario;
    @Basic(optional = false)
    @NotNull
    @Column(name = "descuento")
    private double descuento;
    @OneToMany(cascade = CascadeType.PERSIST, mappedBy = "cotizaciones",fetch = FetchType.LAZY)
    private List<Detallecotizacion> detallecotizacionList;
    @JoinColumn(name = "id_evento", referencedColumnName = "id_evento")
    @ManyToOne
    private Eventos idEvento;

    public Cotizaciones() {
    }

    public Cotizaciones(Integer idCotizacion) {
        this.idCotizacion = idCotizacion;
    }

    public Cotizaciones(Integer idCotizacion, double descuento) {
        this.idCotizacion = idCotizacion;
        this.descuento = descuento;
    }

    public Integer getIdCotizacion() {
        return idCotizacion;
    }

    public void setIdCotizacion(Integer idCotizacion) {
        this.idCotizacion = idCotizacion;
    }

    public Integer getEstado() {
        return estado;
    }

    public void setEstado(Integer estado) {
        this.estado = estado;
    }

    public Date getFechacreacion() {
        return fechacreacion;
    }

    public void setFechacreacion(Date fechacreacion) {
        this.fechacreacion = fechacreacion;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public Eventos getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(Eventos idEvento) {
        this.idEvento = idEvento;
    }

    public List<Detallecotizacion> getDetallecotizacionList() {
        return detallecotizacionList;
    }

    public void setDetallecotizacionList(List<Detallecotizacion> detallecotizacionList) {
        this.detallecotizacionList = detallecotizacionList;
    }
    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCotizacion != null ? idCotizacion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cotizaciones)) {
            return false;
        }
        Cotizaciones other = (Cotizaciones) object;
        if ((this.idCotizacion == null && other.idCotizacion != null) || (this.idCotizacion != null && !this.idCotizacion.equals(other.idCotizacion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Cotizaciones[ idCotizacion=" + idCotizacion + " ]";
    }
    
}
