/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import interfaces.InterfaceEmpresa;
import org.hibernate.Query;
import org.hibernate.Session;
import pojos.LoEmpresa;

/**
 *
 * @author Carlos
 */
public class DaoLoEmpresa implements InterfaceEmpresa {

    @Override
    public boolean register(Session session, LoEmpresa loEmpresa) throws Exception {
        session.save(loEmpresa);
        return true;
    }

    @Override
    public LoEmpresa getByNombre(Session session, String nombreEmpresa) throws Exception {
        String hql="from LoEmpresa where id.emNombre=?";
        
        Query query=session.createQuery(hql);
        
        query.setParameter(0,nombreEmpresa);
        
        LoEmpresa loEmpresa=(LoEmpresa) query.uniqueResult();
        
        return loEmpresa;
        
        
    }

    @Override
    public LoEmpresa getByCodigo(Session session, int codigoEmpresa) throws Exception {
        String hql="from LoEmpresa where id.emIdempresa=?";
        
        Query query=session.createQuery(hql);
        
        query.setParameter(0,codigoEmpresa);
        
        LoEmpresa loEmpresa=(LoEmpresa) query.uniqueResult();
        
        return loEmpresa;
    }
    
}
