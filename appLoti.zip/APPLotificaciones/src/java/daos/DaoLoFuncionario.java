/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import interfaces.InterfaceFuncionario;
import org.hibernate.Query;
import org.hibernate.Session;
import pojos.LoFuncionarios;

/**
 *
 * @author Carlos
 */
public class DaoLoFuncionario implements InterfaceFuncionario {

    @Override
    public boolean register(Session session, LoFuncionarios funcionario) throws Exception {
        session.save(funcionario);
        return true;
    }

    @Override
    public LoFuncionarios getByDocumento(Session session, String codigoDocumento, int codigoEmpresa) throws Exception {
        String hql="from LoFuncionario where id.fuEmpresa=? and fuNumdocumento=?";
        Query query=session.createQuery(hql);
        
        query.setParameter(0, codigoEmpresa);
        query.setParameter(1, codigoDocumento);
        
        LoFuncionarios loFuncionario=(LoFuncionarios) query.uniqueResult();
        
        return loFuncionario;
    }

    @Override
    public LoFuncionarios getByEmail(Session session, String email, int codigoEmpresa) throws Exception {
        String hql="from LoFuncionarios where id.fuEmpresa=? and fuEmail=?";
        
        Query query=session.createQuery(hql);
        
        query.setParameter(0, codigoEmpresa);
        query.setParameter(1, email);
        
        LoFuncionarios loFuncionario=(LoFuncionarios) query.uniqueResult();
        
        return loFuncionario;
    }

    @Override
    public LoFuncionarios getByCodigo(Session session, String codigoFuncionario, String verifCode) throws Exception {
        String hql="select f from LoFuncionarios f, LoEmpresa e "+
                   "where e.id.emIdempresa=f.id.fuEmpresa " +
                   "and e.emCodigoverificacion=? and f.id.fuIdfuncionario=?";
        
        Query query=session.createQuery(hql);
        
        query.setParameter(0,verifCode);
        query.setParameter(1,codigoFuncionario);
        
        LoFuncionarios loFuncionario=(LoFuncionarios) query.uniqueResult();
        
        return loFuncionario;

    }
    
}
