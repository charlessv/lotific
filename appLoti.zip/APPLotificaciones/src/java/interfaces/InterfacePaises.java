/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import java.util.List;
import org.hibernate.Session;
import pojos.LoPais;
import pojos.LoPaisId;

/**
 *
 * @author Carlos
 */
public interface InterfacePaises {
    public boolean register(Session session,LoPais loPais) throws Exception;
    public List<LoPais> getAll(Session session) throws Exception;
    
}
