/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import interfaces.InterfaceClientes;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import pojos.LoClientes;

/**
 *
 * @author Carlos
 */
public class DaoLoClientes implements InterfaceClientes {

    @Override
    public boolean register(Session session, LoClientes loClientes) throws Exception {
         session.save(loClientes);
         
         return true;
    }

    @Override
    public List<LoClientes> getAll(Session session,int codigoEmpresa,String estado) throws Exception {
       String hql="from LoClientes where ";
       String criterio="";
       boolean usuarioEstado=true;
        switch (estado){
            case "T"://Todos
                criterio="id.clIdempresa=?";
                break;
            default: //Filtro Estado
               criterio="id.clIdempresa=? and clEstado=?"; 
               if(estado.equals("I")){
                  usuarioEstado=false;
             }
        }
        hql=hql+criterio;
        
        Query query=session.createQuery(hql);
        query.setParameter(0,codigoEmpresa);
      
        if(!estado.equals("T")){  
          query.setParameter(1,usuarioEstado);
      }
        
              
      List<LoClientes> lstClientes=(List<LoClientes>) query.list();
      
      return lstClientes;
      
    }

    @Override
    public LoClientes getByidCliente(Session session,int codigoEmpresa, String idCliente) throws Exception {
        String hql="from LoClientes "
                + "where id.clIdempresa=? "
                + "and id.clIdcliente=?";
        Query query=session.createQuery(hql);
        
        query.setParameter(0, codigoEmpresa);
        query.setParameter(1, idCliente);
        
        
        LoClientes loCliente=(LoClientes) query.uniqueResult();
        
        return loCliente;
    }

    

    @Override
    public LoClientes getByIDsDiff(Session session,int codigoEmpresa, String idCliente, String numDocumento, String numNit) throws Exception {
      String hql="from LoClientes where id.clIdempresa=? "+
                 "and id.clIdcliente!=? " +
                 "and (clNumDocumento=? or clNit=?)";
      Query query=session.createQuery(hql);
      query.setParameter(0, codigoEmpresa);
      query.setParameter(1, idCliente);
      query.setParameter(2,numDocumento);
      query.setParameter(3,numNit);
      
      LoClientes loCliente=(LoClientes) query.uniqueResult();
      
      return loCliente;
    }

    @Override
    public LoClientes getByIDs(Session session,int codigoEmpresa, String numDocumento, String numNit) throws Exception {
        String hql="from LoClientes where id.clIdempresa=? "+
                   "and (clNumDocumento=? or clNit=?)";
      Query query=session.createQuery(hql);
      query.setParameter(0,codigoEmpresa);
      query.setParameter(1,numDocumento);
      query.setParameter(2,numNit);
      
      LoClientes loCliente=(LoClientes) query.uniqueResult();
      
      return loCliente;
    }
    
    @Override
    public boolean update(Session session, LoClientes loClientes) throws Exception {
        session.update(loClientes);
        return true;
    }

    @Override
    public boolean delete(Session session, LoClientes loClientes) throws Exception {
        session.delete(loClientes);
        return true;
    }
}
