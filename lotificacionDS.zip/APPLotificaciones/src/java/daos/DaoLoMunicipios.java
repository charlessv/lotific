/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import interfaces.InterfaceMunicipios;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import pojos.LoMunicipios;

/**
 *
 * @author Carlos
 */
public class DaoLoMunicipios implements InterfaceMunicipios {

    @Override
    public boolean register(Session session, LoMunicipios loMunicipio) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<LoMunicipios> getAllMunicipios(Session session, int idDepartamento) throws Exception {
        String hql="from LoMunicipios where id.muIddepartamento=:idDepartamento and muEstado=true";
        Query query=session.createQuery(hql);
        query.setParameter("idDepartamento",idDepartamento);
        
        List <LoMunicipios> lstMunicipios=(List<LoMunicipios>) query.list();
        
        return lstMunicipios;
    }

    
    
}
