/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import java.util.List;
import org.hibernate.Session;
import pojos.LoDepartamento;

/**
 *
 * @author Carlos
 */
public interface InterfaceDepartamentos {
    public boolean register(Session session,LoDepartamento loDepartamento) throws Exception;
    public List<LoDepartamento> getAllDepartamentos(Session session,int idPais)throws Exception;
}
