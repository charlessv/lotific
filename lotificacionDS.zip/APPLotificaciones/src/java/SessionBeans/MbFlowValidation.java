/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SessionBeans;

import HibernateUtils.HibernateUtil;
import daos.DaoLoEmpresa;
import daos.DaoLoFuncionario;
import daos.DaoLoUsuarios;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.primefaces.context.RequestContext;
import org.primefaces.model.UploadedFile;

import pojos.LoEmpresa;
import pojos.LoEmpresaId;
import pojos.LoFuncionarios;
import pojos.LoFuncionariosId;
import pojos.LoUsuarios;
import utilityclass.HtmlObjContext;

/**
 *
 * @author cc90930
 */
@ManagedBean
@SessionScoped
public class MbFlowValidation implements Serializable {

    /**
     * Creates a new instance of MbFlowValidation
     */
    DaoLoEmpresa empresaDAO;
    DaoLoFuncionario funcionarioDAO;
    DaoLoUsuarios usuarioDAO;

    private LoEmpresa empresa;
    private LoEmpresaId pkEmpresa;

    private LoFuncionarios funcionario;
    private LoFuncionariosId pkFuncionario;

    private LoUsuarios usuario;

    private Session session;
    private Transaction transaction;

    private HtmlObjContext htmlObjContext;

    private String txtrPassword;
    private int codigoEmpresa;
    private String codigoFuncionario;
    private String txtDireccion;

    private boolean enableCliente;
    private boolean enableEmpresa;
    private UploadedFile logo;

    HttpSession miSession;

    public MbFlowValidation() {
        miSession = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        miSession.setMaxInactiveInterval(5000);
    }

    @PostConstruct
    public void init() {

        this.empresa = new LoEmpresa();
        this.pkEmpresa = new LoEmpresaId();
        this.pkEmpresa.setEmNombre("");
        this.empresa.setId(this.pkEmpresa);
        this.empresa.setEmEstado(true);
        this.empresa.setEmCodigoverificacion("");

        this.funcionario = new LoFuncionarios();
        this.pkFuncionario = new LoFuncionariosId();
        this.funcionario.setId(this.pkFuncionario);
        this.funcionario.getId().setFuIdfuncionario("");
        this.funcionario.setFuEstado(true);

        this.usuario = new LoUsuarios();
        this.usuario.setUsCodigousuario("");
        this.usuario.setUsEstado(true);

        this.htmlObjContext = new HtmlObjContext();

        this.enableCliente = Boolean.FALSE;
        this.enableEmpresa = Boolean.TRUE;

    }

    public void validateSteps(int step) {

        switch (step) {
            case 0:
                this.enableCliente = Boolean.FALSE;
                this.enableEmpresa = Boolean.TRUE;
                break;
            case 1:

                try {

                    this.session = null;
                    this.transaction = null;
                    this.session = HibernateUtil.getSessionFactory().openSession();
                    this.transaction = this.session.beginTransaction();
                    this.empresaDAO = new DaoLoEmpresa();

                    if (empresaDAO.getByNombre(this.session, this.empresa.getId().getEmNombre()) != null) {
                        FacesContext.getCurrentInstance()
                                .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :",
                                                "Existe una Empresa Registrada \n con el Nombre Ingresado"));
                    }

                } catch (Exception ex) {
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Error Mientras se Valida Empresa, favor reintentar"));
                    if (this.transaction != null) {
                        this.transaction.rollback();
                    }

                } finally {
                    if (this.session != null) {
                        this.session.close();
                    }
                }

                break;
            case 2:

                if (this.empresa.getEmPais() == null) {
                    FacesContext.getCurrentInstance()
                            .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Pais es Requerido"));
                } else {
                    if (this.empresa.getEmDepartamento() == null) {
                        FacesContext.getCurrentInstance()
                                .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Departamento es Requerido"));
                    } else {
                        if (this.empresa.getEmMunicipio() == null) {
                            FacesContext.getCurrentInstance()
                                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :", "Ciudad es Requerida"));
                        } else {
                            this.enableCliente = Boolean.TRUE;
                            this.enableEmpresa = Boolean.FALSE;
                        }
                    }
                }
                break;

            case 4:

                break;
        }
        RequestContext.getCurrentInstance().update("frmFirstContact");
    }

    public void updateLogo() {
        InputStream inputStream = null;
        OutputStream outputStream = null;

        try {
            if (this.logo.getSize() <= 0) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(
                                        FacesMessage.SEVERITY_ERROR, "Error : ", "Debe Seleccionar un Archivo Valido de Imagen"));
                return;

            }
            
            if (this.logo.getSize()>2097152){
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(
                                        FacesMessage.SEVERITY_ERROR, "Error : ", "Archivo No Puede ser mayor a 2MB"));
                return;
            }
        } catch (Exception ex) {

        }
    }

    public LoEmpresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(LoEmpresa empresa) {
        this.empresa = empresa;
    }

    public LoEmpresaId getPkEmpresa() {
        return pkEmpresa;
    }

    public void setPkEmpresa(LoEmpresaId pkEmpresa) {
        this.pkEmpresa = pkEmpresa;
    }

    public LoFuncionarios getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(LoFuncionarios funcionario) {
        this.funcionario = funcionario;
    }

    public LoFuncionariosId getPkFuncionario() {
        return pkFuncionario;
    }

    public void setPkFuncionario(LoFuncionariosId pkFuncionario) {
        this.pkFuncionario = pkFuncionario;
    }

    public LoUsuarios getUsuario() {
        return usuario;
    }

    public void setUsuario(LoUsuarios usuario) {
        this.usuario = usuario;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public HtmlObjContext getHtmlObjContext() {
        return htmlObjContext;
    }

    public void setHtmlObjContext(HtmlObjContext htmlObjContext) {
        this.htmlObjContext = htmlObjContext;
    }

    public String getTxtrPassword() {
        return txtrPassword;
    }

    public void setTxtrPassword(String txtrPassword) {
        this.txtrPassword = txtrPassword;
    }

    public int getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(int codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public String getCodigoFuncionario() {
        return codigoFuncionario;
    }

    public void setCodigoFuncionario(String codigoFuncionario) {
        this.codigoFuncionario = codigoFuncionario;
    }

    public String getTxtDireccion() {
        return txtDireccion;
    }

    public void setTxtDireccion(String txtDireccion) {
        this.txtDireccion = txtDireccion;
    }

    public boolean isEnableCliente() {
        return enableCliente;
    }

    public void setEnableCliente(boolean enableCliente) {
        this.enableCliente = enableCliente;
    }

    public boolean isEnableEmpresa() {
        return enableEmpresa;
    }

    public void setEnableEmpresa(boolean enableEmpresa) {
        this.enableEmpresa = enableEmpresa;
    }

    public UploadedFile getLogo() {
        return logo;
    }

    public void setLogo(UploadedFile logo) {
        this.logo = logo;
    }

}
